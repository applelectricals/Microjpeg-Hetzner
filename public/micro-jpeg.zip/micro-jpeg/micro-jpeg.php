<?php
/**
 * Plugin Name: MicroJPEG Image Optimizer
 * Plugin URI: https://microjpeg.com/wordpress-plugin
 * Description: Automatically compress and optimize WordPress images using MicroJPEG API. Supports JPEG, PNG, WebP, AVIF, and RAW camera formats (CR2, ARW, NEF, DNG, ORF, RAF).
 * Version: 3.0.0
 * Author: MicroJPEG
 * Author URI: https://microjpeg.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: microjpeg
 * Requires at least: 5.0
 * Tested up to: 6.7
 * Requires PHP: 7.4
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('MICROJPEG_VERSION', '3.0.0');
define('MICROJPEG_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MICROJPEG_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('MICROJPEG_API_URL', 'https://microjpeg.com');

/**
 * Main Plugin Class
 */
class MicroJPEG {
    
    private static $instance = null;
    
    public static function init() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Admin hooks
        add_action('admin_menu', array($this, 'add_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // AJAX handlers
        add_action('wp_ajax_microjpeg_test_key', array($this, 'ajax_test_key'));
        add_action('wp_ajax_microjpeg_optimize', array($this, 'ajax_optimize'));
        
        // Media upload hooks - only if auto-compress enabled AND API key exists
        add_action('add_attachment', array($this, 'auto_compress'), 10, 1);
        
        // Allow RAW file uploads
        add_filter('upload_mimes', array($this, 'allow_raw_mimes'));
        add_filter('wp_check_filetype_and_ext', array($this, 'fix_raw_filetype'), 10, 5);
        
        // Media library column
        add_filter('manage_media_columns', array($this, 'add_column'));
        add_action('manage_media_custom_column', array($this, 'render_column'), 10, 2);
        
        // Activation
        register_activation_hook(__FILE__, array($this, 'activate'));
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        add_option('microjpeg_api_key', '');
        add_option('microjpeg_auto_compress', '0');
        add_option('microjpeg_quality', '85');
        add_option('microjpeg_output_format', 'keep');
        add_option('microjpeg_backup', '1');
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('microjpeg_settings', 'microjpeg_api_key', 'sanitize_text_field');
        register_setting('microjpeg_settings', 'microjpeg_auto_compress', 'sanitize_text_field');
        register_setting('microjpeg_settings', 'microjpeg_quality', 'absint');
        register_setting('microjpeg_settings', 'microjpeg_output_format', 'sanitize_text_field');
        register_setting('microjpeg_settings', 'microjpeg_backup', 'sanitize_text_field');
    }
    
    /**
     * Add admin menu
     */
    public function add_menu() {
        add_media_page(
            'MicroJPEG Settings',
            'MicroJPEG',
            'manage_options',
            'microjpeg',
            array($this, 'settings_page')
        );
    }
    
    /**
     * Enqueue admin scripts
     */
    public function enqueue_scripts($hook) {
        if ($hook === 'media_page_microjpeg' || $hook === 'upload.php') {
            wp_enqueue_style('microjpeg-admin', MICROJPEG_PLUGIN_URL . 'assets/style.css', array(), MICROJPEG_VERSION);
            wp_enqueue_script('microjpeg-admin', MICROJPEG_PLUGIN_URL . 'assets/script.js', array('jquery'), MICROJPEG_VERSION, true);
            wp_localize_script('microjpeg-admin', 'microjpeg', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('microjpeg_nonce')
            ));
        }
    }
    
    /**
     * Allow RAW file uploads
     */
    public function allow_raw_mimes($mimes) {
        // RAW camera formats
        $mimes['cr2'] = 'image/x-canon-cr2';
        $mimes['cr3'] = 'image/x-canon-cr3';
        $mimes['crw'] = 'image/x-canon-crw';
        $mimes['arw'] = 'image/x-sony-arw';
        $mimes['nef'] = 'image/x-nikon-nef';
        $mimes['nrw'] = 'image/x-nikon-nrw';
        $mimes['dng'] = 'image/x-adobe-dng';
        $mimes['orf'] = 'image/x-olympus-orf';
        $mimes['raf'] = 'image/x-fuji-raf';
        $mimes['rw2'] = 'image/x-panasonic-rw2';
        $mimes['pef'] = 'image/x-pentax-pef';
        $mimes['srw'] = 'image/x-samsung-srw';
        
        // Modern formats
        $mimes['webp'] = 'image/webp';
        $mimes['avif'] = 'image/avif';
        
        return $mimes;
    }
    
    /**
     * Fix RAW file type detection
     */
    public function fix_raw_filetype($data, $file, $filename, $mimes, $real_mime = null) {
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        $raw_mimes = array(
            'cr2' => 'image/x-canon-cr2',
            'cr3' => 'image/x-canon-cr3',
            'crw' => 'image/x-canon-crw',
            'arw' => 'image/x-sony-arw',
            'nef' => 'image/x-nikon-nef',
            'nrw' => 'image/x-nikon-nrw',
            'dng' => 'image/x-adobe-dng',
            'orf' => 'image/x-olympus-orf',
            'raf' => 'image/x-fuji-raf',
            'rw2' => 'image/x-panasonic-rw2',
            'pef' => 'image/x-pentax-pef',
            'srw' => 'image/x-samsung-srw',
        );
        
        if (isset($raw_mimes[$ext])) {
            $data['ext'] = $ext;
            $data['type'] = $raw_mimes[$ext];
        }
        
        return $data;
    }
    
    /**
     * Settings page
     */
    public function settings_page() {
        $api_key = get_option('microjpeg_api_key', '');
        $auto_compress = get_option('microjpeg_auto_compress', '0');
        $quality = get_option('microjpeg_quality', '85');
        $output_format = get_option('microjpeg_output_format', 'keep');
        $backup = get_option('microjpeg_backup', '1');
        ?>
        <div class="wrap microjpeg-wrap">
            <h1><span class="dashicons dashicons-images-alt2"></span> MicroJPEG Image Optimizer</h1>
            
            <form method="post" action="options.php">
                <?php settings_fields('microjpeg_settings'); ?>
                
                <div class="microjpeg-card">
                    <h2>API Configuration</h2>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="microjpeg_api_key">API Key</label></th>
                            <td>
                                <input type="text" 
                                       id="microjpeg_api_key" 
                                       name="microjpeg_api_key" 
                                       value="<?php echo esc_attr($api_key); ?>" 
                                       class="regular-text"
                                       placeholder="Enter your API key">
                                <button type="button" id="microjpeg-test-btn" class="button">Test API Key</button>
                                <span id="microjpeg-test-result"></span>
                                <p class="description">
                                    <a href="<?php echo esc_url(MICROJPEG_API_URL . '/api-dashboard'); ?>" target="_blank" class="button button-secondary">
                                        Get Your Free API Key
                                    </a>
                                    <br><small>200 free compressions per month. No credit card required.</small>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th>Auto-Compress</th>
                            <td>
                                <label>
                                    <input type="checkbox" 
                                           name="microjpeg_auto_compress" 
                                           value="1" 
                                           <?php checked($auto_compress, '1'); ?>>
                                    Automatically compress images when uploaded
                                </label>
                            </td>
                        </tr>
                        
                        <tr>
                            <th><label for="microjpeg_quality">Quality</label></th>
                            <td>
                                <input type="range" 
                                       id="microjpeg_quality" 
                                       name="microjpeg_quality" 
                                       min="10" max="100" 
                                       value="<?php echo esc_attr($quality); ?>">
                                <span id="quality-display"><?php echo esc_html($quality); ?>%</span>
                                <p class="description">Higher = better quality, larger file. Recommended: 80-90%</p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th><label for="microjpeg_output_format">Output Format</label></th>
                            <td>
                                <select id="microjpeg_output_format" name="microjpeg_output_format">
                                    <option value="keep" <?php selected($output_format, 'keep'); ?>>Keep Original</option>
                                    <option value="jpeg" <?php selected($output_format, 'jpeg'); ?>>JPEG</option>
                                    <option value="webp" <?php selected($output_format, 'webp'); ?>>WebP</option>
                                    <option value="avif" <?php selected($output_format, 'avif'); ?>>AVIF</option>
                                    <option value="png" <?php selected($output_format, 'png'); ?>>PNG</option>
                                </select>
                                <p class="description">RAW files (CR2, NEF, ARW) will always be converted to a web format.</p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th>Backup Originals</th>
                            <td>
                                <label>
                                    <input type="checkbox" 
                                           name="microjpeg_backup" 
                                           value="1" 
                                           <?php checked($backup, '1'); ?>>
                                    Keep backup of original files
                                </label>
                            </td>
                        </tr>
                    </table>
                    
                    <?php submit_button('Save Settings'); ?>
                </div>
            </form>
            
            <div class="microjpeg-card">
                <h2>Supported Formats</h2>
                <p><strong>Standard:</strong> JPEG, PNG, GIF, WebP, AVIF, TIFF, BMP, SVG</p>
                <p><strong>RAW Camera:</strong> CR2, CR3 (Canon), ARW (Sony), NEF (Nikon), DNG (Adobe), ORF (Olympus), RAF (Fuji), RW2 (Panasonic)</p>
            </div>
            
            <div class="microjpeg-card">
                <h2>Statistics</h2>
                <?php $this->render_stats(); ?>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render statistics
     */
    private function render_stats() {
        global $wpdb;
        
        $optimized = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_microjpeg_optimized'");
        $total_saved = $wpdb->get_var("SELECT SUM(meta_value) FROM {$wpdb->postmeta} WHERE meta_key = '_microjpeg_saved'");
        
        ?>
        <div class="microjpeg-stats">
            <div class="stat-box">
                <strong><?php echo intval($optimized); ?></strong>
                <span>Images Optimized</span>
            </div>
            <div class="stat-box">
                <strong><?php echo size_format($total_saved ?: 0); ?></strong>
                <span>Total Saved</span>
            </div>
        </div>
        <?php
    }
    
    /**
     * Add media library column
     */
    public function add_column($columns) {
        $columns['microjpeg'] = 'MicroJPEG';
        return $columns;
    }
    
    /**
     * Render media library column
     */
    public function render_column($column, $post_id) {
        if ($column !== 'microjpeg') return;
        
        $optimized = get_post_meta($post_id, '_microjpeg_optimized', true);
        
        if ($optimized) {
            $savings = get_post_meta($post_id, '_microjpeg_savings_percent', true);
            echo '<span style="color:#46b450;">✓ ' . esc_html($savings) . '% saved</span>';
        } else {
            $mime = get_post_mime_type($post_id);
            if (strpos($mime, 'image/') === 0) {
                echo '<a href="#" class="microjpeg-optimize-btn" data-id="' . esc_attr($post_id) . '">Optimize</a>';
            } else {
                echo '—';
            }
        }
    }
    
    /**
     * AJAX: Test API Key
     */
    public function ajax_test_key() {
        check_ajax_referer('microjpeg_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $api_key = sanitize_text_field($_POST['api_key'] ?? '');
        
        if (empty($api_key)) {
            wp_send_json_error('Please enter an API key');
        }
        
        // Test the API key using the WordPress validation endpoint
        $response = wp_remote_get(MICROJPEG_API_URL . '/api/wordpress/validate-key', array(
            'timeout' => 30,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Accept' => 'application/json',
            ),
            'sslverify' => true,
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error('Connection failed: ' . $response->get_error_message());
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        error_log('[MicroJPEG] API Test Response - Code: ' . $code . ', Body: ' . substr($body, 0, 200));
        
        if ($code === 200) {
            $data = json_decode($body, true);
            $tier = $data['tierName'] ?? $data['tier'] ?? 'Free';
            wp_send_json_success('API key valid! Tier: ' . $tier);
        } elseif ($code === 401) {
            wp_send_json_error('Invalid API key');
        } elseif ($code === 403) {
            wp_send_json_error('Access denied. Please check your API key.');
        } elseif ($code === 404) {
            wp_send_json_error('API endpoint not found. Please update the plugin.');
        } else {
            wp_send_json_error('API error (code: ' . $code . ')');
        }
    }
    
    /**
     * AJAX: Optimize single image
     */
    public function ajax_optimize() {
        check_ajax_referer('microjpeg_nonce', 'nonce');
        
        if (!current_user_can('upload_files')) {
            wp_send_json_error('Unauthorized');
        }
        
        $attachment_id = intval($_POST['attachment_id'] ?? 0);
        
        if (!$attachment_id) {
            wp_send_json_error('Invalid attachment');
        }
        
        $result = $this->compress_attachment($attachment_id);
        
        if (isset($result['error'])) {
            wp_send_json_error($result['error']);
        }
        
        wp_send_json_success($result);
    }
    
    /**
     * Auto-compress on upload
     */
    public function auto_compress($attachment_id) {
        // Check if auto-compress is enabled
        if (get_option('microjpeg_auto_compress', '0') !== '1') {
            return;
        }
        
        // Check if API key exists
        $api_key = get_option('microjpeg_api_key', '');
        if (empty($api_key)) {
            return;
        }
        
        // Check if already optimized
        if (get_post_meta($attachment_id, '_microjpeg_optimized', true)) {
            return;
        }
        
        // Check if it's an image
        $mime = get_post_mime_type($attachment_id);
        if (strpos($mime, 'image/') !== 0) {
            return;
        }
        
        error_log('[MicroJPEG] Auto-compressing attachment: ' . $attachment_id);
        
        $this->compress_attachment($attachment_id);
    }
    
    /**
     * Compress an attachment
     */
    private function compress_attachment($attachment_id) {
        $api_key = get_option('microjpeg_api_key', '');
        
        if (empty($api_key)) {
            return array('error' => 'API key not configured');
        }
        
        $file_path = get_attached_file($attachment_id);
        
        if (!$file_path || !file_exists($file_path)) {
            return array('error' => 'File not found');
        }
        
        $original_size = filesize($file_path);
        $filename = basename($file_path);
        $ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        
        // Get settings
        $quality = get_option('microjpeg_quality', '85');
        $output_format = get_option('microjpeg_output_format', 'keep');
        $backup = get_option('microjpeg_backup', '1');
        
        // RAW files must be converted
        $raw_formats = array('cr2', 'cr3', 'crw', 'arw', 'nef', 'nrw', 'dng', 'orf', 'raf', 'rw2', 'pef', 'srw');
        if (in_array($ext, $raw_formats) && $output_format === 'keep') {
            $output_format = 'jpeg';
        }
        
        // Backup original if enabled
        if ($backup === '1') {
            $backup_path = $file_path . '.microjpeg-backup';
            @copy($file_path, $backup_path);
        }
        
        // Build multipart request
        $boundary = wp_generate_password(24, false);
        $body = $this->build_multipart($file_path, $filename, $quality, $output_format, $boundary);
        
        if (!$body) {
            return array('error' => 'Failed to read file');
        }
        
        error_log('[MicroJPEG] Sending to API: ' . $filename . ' (' . size_format($original_size) . ')');
        
        // Send to API
        $response = wp_remote_post(MICROJPEG_API_URL . '/api/compress', array(
            'timeout' => 120,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'multipart/form-data; boundary=' . $boundary,
                'Accept' => 'application/json',
            ),
            'body' => $body,
            'sslverify' => true,
        ));
        
        if (is_wp_error($response)) {
            error_log('[MicroJPEG] API Error: ' . $response->get_error_message());
            return array('error' => 'API request failed: ' . $response->get_error_message());
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        error_log('[MicroJPEG] API Response Code: ' . $code);
        
        if ($code !== 200) {
            $error = json_decode($response_body, true);
            $msg = $error['message'] ?? $error['error'] ?? 'Unknown error (code: ' . $code . ')';
            return array('error' => $msg);
        }
        
        $data = json_decode($response_body, true);
        
        if (!$data || !isset($data['success']) || !$data['success']) {
            return array('error' => $data['message'] ?? 'Compression failed');
        }
        
        // Get compressed data
        $compressed_data = null;
        
        if (isset($data['data'])) {
            $compressed_data = base64_decode($data['data']);
        } elseif (isset($data['downloadUrl'])) {
            $download = wp_remote_get($data['downloadUrl'], array('timeout' => 60));
            if (!is_wp_error($download)) {
                $compressed_data = wp_remote_retrieve_body($download);
            }
        }
        
        if (!$compressed_data) {
            return array('error' => 'No compressed data received');
        }
        
        $compressed_size = strlen($compressed_data);
        
        // Only save if smaller
        if ($compressed_size >= $original_size) {
            return array(
                'message' => 'Image already optimized',
                'savings_percent' => 0,
            );
        }
        
        // Determine output path
        $output_path = $file_path;
        $new_ext = $data['outputFormat'] ?? $ext;
        
        if ($new_ext !== $ext) {
            $output_path = preg_replace('/\.' . preg_quote($ext, '/') . '$/', '.' . $new_ext, $file_path);
        }
        
        // Save compressed file
        if (file_put_contents($output_path, $compressed_data) === false) {
            return array('error' => 'Failed to save compressed file');
        }
        
        // Update attachment if path changed
        if ($output_path !== $file_path) {
            update_attached_file($attachment_id, $output_path);
            
            if (file_exists($file_path)) {
                @unlink($file_path);
            }
            
            // Update MIME type
            $new_mime = $this->get_mime_type($new_ext);
            wp_update_post(array(
                'ID' => $attachment_id,
                'post_mime_type' => $new_mime,
            ));
        }
        
        // Calculate savings
        $saved = $original_size - $compressed_size;
        $savings_percent = round(($saved / $original_size) * 100, 1);
        
        // Save metadata
        update_post_meta($attachment_id, '_microjpeg_optimized', '1');
        update_post_meta($attachment_id, '_microjpeg_original_size', $original_size);
        update_post_meta($attachment_id, '_microjpeg_compressed_size', $compressed_size);
        update_post_meta($attachment_id, '_microjpeg_saved', $saved);
        update_post_meta($attachment_id, '_microjpeg_savings_percent', $savings_percent);
        update_post_meta($attachment_id, '_microjpeg_date', current_time('mysql'));
        
        error_log('[MicroJPEG] Compressed successfully: ' . $savings_percent . '% saved');
        
        return array(
            'message' => 'Optimized successfully',
            'original_size' => $original_size,
            'compressed_size' => $compressed_size,
            'saved' => $saved,
            'savings_percent' => $savings_percent,
        );
    }
    
    /**
     * Build multipart form body
     */
    private function build_multipart($file_path, $filename, $quality, $output_format, $boundary) {
        $content = @file_get_contents($file_path);
        if ($content === false) {
            return null;
        }
        
        $body = '';
        
        // Quality field
        $body .= '--' . $boundary . "\r\n";
        $body .= 'Content-Disposition: form-data; name="quality"' . "\r\n\r\n";
        $body .= $quality . "\r\n";
        
        // Output format field
        $body .= '--' . $boundary . "\r\n";
        $body .= 'Content-Disposition: form-data; name="outputFormat"' . "\r\n\r\n";
        $body .= ($output_format === 'keep' ? 'keep-original' : $output_format) . "\r\n";
        
        // File field
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $mime = $this->get_mime_type($ext);
        
        $body .= '--' . $boundary . "\r\n";
        $body .= 'Content-Disposition: form-data; name="image"; filename="' . $filename . '"' . "\r\n";
        $body .= 'Content-Type: ' . $mime . "\r\n\r\n";
        $body .= $content . "\r\n";
        
        // End
        $body .= '--' . $boundary . '--' . "\r\n";
        
        return $body;
    }
    
    /**
     * Get MIME type for extension
     */
    private function get_mime_type($ext) {
        $types = array(
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
            'webp' => 'image/webp',
            'avif' => 'image/avif',
            'svg' => 'image/svg+xml',
            'tiff' => 'image/tiff',
            'tif' => 'image/tiff',
            'bmp' => 'image/bmp',
            'cr2' => 'image/x-canon-cr2',
            'cr3' => 'image/x-canon-cr3',
            'arw' => 'image/x-sony-arw',
            'nef' => 'image/x-nikon-nef',
            'dng' => 'image/x-adobe-dng',
            'orf' => 'image/x-olympus-orf',
            'raf' => 'image/x-fuji-raf',
            'rw2' => 'image/x-panasonic-rw2',
        );
        
        return $types[strtolower($ext)] ?? 'application/octet-stream';
    }
}

// Initialize
MicroJPEG::init();
