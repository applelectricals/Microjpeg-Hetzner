/**
 * MicroJPEG WordPress Plugin
 */
(function($) {
    'use strict';
    
    $(document).ready(function() {
        // Quality slider
        $('#microjpeg_quality').on('input', function() {
            $('#quality-display').text($(this).val() + '%');
        });
        
        // Test API Key
        $('#microjpeg-test-btn').on('click', function() {
            var btn = $(this);
            var result = $('#microjpeg-test-result');
            var apiKey = $('#microjpeg_api_key').val();
            
            if (!apiKey) {
                result.html('<span style="color:#dc3232;">Please enter an API key</span>');
                return;
            }
            
            btn.prop('disabled', true).text('Testing...');
            result.html('');
            
            $.ajax({
                url: microjpeg.ajax_url,
                type: 'POST',
                data: {
                    action: 'microjpeg_test_key',
                    nonce: microjpeg.nonce,
                    api_key: apiKey
                },
                success: function(response) {
                    if (response.success) {
                        result.html('<span style="color:#46b450;">✓ ' + response.data + '</span>');
                    } else {
                        result.html('<span style="color:#dc3232;">✗ ' + response.data + '</span>');
                    }
                },
                error: function() {
                    result.html('<span style="color:#dc3232;">✗ Connection error</span>');
                },
                complete: function() {
                    btn.prop('disabled', false).text('Test API Key');
                }
            });
        });
        
        // Optimize single image
        $(document).on('click', '.microjpeg-optimize-btn', function(e) {
            e.preventDefault();
            
            var link = $(this);
            var id = link.data('id');
            
            if (!id) return;
            
            link.text('Optimizing...');
            
            $.ajax({
                url: microjpeg.ajax_url,
                type: 'POST',
                data: {
                    action: 'microjpeg_optimize',
                    nonce: microjpeg.nonce,
                    attachment_id: id
                },
                success: function(response) {
                    if (response.success) {
                        link.replaceWith('<span style="color:#46b450;">✓ ' + response.data.savings_percent + '% saved</span>');
                    } else {
                        link.text('Optimize');
                        alert('Error: ' + response.data);
                    }
                },
                error: function() {
                    link.text('Optimize');
                    alert('Connection error');
                }
            });
        });
    });
})(jQuery);
