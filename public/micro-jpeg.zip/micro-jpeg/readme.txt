=== MicroJPEG Image Optimizer ===
Contributors: microjpeg
Tags: image optimization, compression, webp, avif, raw
Requires at least: 5.0
Tested up to: 6.7
Stable tag: 3.0.0
Requires PHP: 7.4
License: GPLv2 or later

Compress and optimize WordPress images using MicroJPEG API.

== Description ==

Automatically compress images when uploaded to WordPress. Supports JPEG, PNG, WebP, AVIF, and RAW camera formats.

== Installation ==

1. Upload the plugin folder to /wp-content/plugins/
2. Activate the plugin
3. Go to Media > MicroJPEG
4. Enter your API key
5. Enable auto-compress

== Changelog ==

= 3.0.0 =
* Complete rewrite
* RAW file support
* Auto-compression
