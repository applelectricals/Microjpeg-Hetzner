/**
 * MicroJPEG WordPress Plugin - Admin JavaScript
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        initQualitySlider();
        initApiKeyTest();
        initSingleOptimize();
    });

    /**
     * Quality slider
     */
    function initQualitySlider() {
        $('#micro_jpeg_quality').on('input', function() {
            $('#quality-value').text($(this).val() + '%');
        });
    }

    /**
     * API Key Test
     */
    function initApiKeyTest() {
        $('#micro-jpeg-test-key').on('click', function() {
            var $btn = $(this);
            var $result = $('#micro-jpeg-test-result');
            var apiKey = $('#micro_jpeg_api_key').val();

            if (!apiKey) {
                $result.removeClass('success').addClass('error').text('Please enter an API key first');
                return;
            }

            $btn.prop('disabled', true).text(microJpegAdmin.strings.testing);
            $result.removeClass('success error').text('');

            $.ajax({
                url: microJpegAdmin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'micro_jpeg_test_key',
                    nonce: microJpegAdmin.nonce,
                    api_key: apiKey
                },
                success: function(response) {
                    if (response.success) {
                        $result.removeClass('error').addClass('success').text('✓ ' + response.data);
                    } else {
                        $result.removeClass('success').addClass('error').text('✗ ' + response.data);
                    }
                },
                error: function() {
                    $result.removeClass('success').addClass('error').text('✗ Connection error');
                },
                complete: function() {
                    $btn.prop('disabled', false).text(microJpegAdmin.strings.testKey);
                }
            });
        });
    }

    /**
     * Single image optimization (Media Library)
     */
    function initSingleOptimize() {
        $(document).on('click', '.micro-jpeg-optimize', function(e) {
            e.preventDefault();
            
            var $link = $(this);
            var attachmentId = $link.data('id');
            
            if (!attachmentId) return;

            $link.text(microJpegAdmin.strings.optimizing);

            $.ajax({
                url: microJpegAdmin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'micro_jpeg_optimize_single',
                    nonce: microJpegAdmin.nonce,
                    attachment_id: attachmentId
                },
                success: function(response) {
                    if (response.success) {
                        $link.replaceWith('<span style="color: #46b450;">✓ ' + response.data.savings + '%</span>');
                    } else {
                        $link.text(microJpegAdmin.strings.optimize);
                        alert('Error: ' + response.data);
                    }
                },
                error: function() {
                    $link.text(microJpegAdmin.strings.optimize);
                    alert('Connection error');
                }
            });
        });
    }

})(jQuery);
