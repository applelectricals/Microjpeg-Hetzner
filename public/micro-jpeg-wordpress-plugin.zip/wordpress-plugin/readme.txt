=== MicroJPEG Image Optimizer ===
Contributors: microjpeg
Tags: image optimization, compression, webp, avif, raw, cr2, nef, arw, performance
Requires at least: 5.0
Tested up to: 6.7
Stable tag: 3.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically compress and optimize images using the MicroJPEG API. Supports JPEG, PNG, WebP, AVIF, and RAW camera formats.

== Description ==

MicroJPEG Image Optimizer automatically compresses your WordPress images using our powerful cloud-based API. Reduce file sizes by up to 80% without visible quality loss.

**Key Features:**

* **Automatic Compression** - Compress images automatically when uploaded
* **RAW File Support** - Process CR2, ARW, NEF, DNG, ORF, RAF, RW2 and more
* **Format Conversion** - Convert to WebP or AVIF for better compression
* **Bulk Optimization** - Optimize your entire media library
* **Backup Originals** - Keep original files safe
* **Quality Control** - Adjust compression level from 10-100%

**Supported Formats:**

* Standard: JPEG, PNG, WebP, AVIF, GIF, SVG, TIFF, BMP
* RAW: CR2, CR3 (Canon), ARW (Sony), NEF, NRW (Nikon), DNG (Adobe), ORF (Olympus), RAF (Fuji), RW2 (Panasonic), PEF (Pentax), SRW (Samsung)

**Free Tier:**

* 200 compressions per month
* No credit card required
* All formats supported

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/micro-jpeg/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Media → MicroJPEG to configure settings
4. Enter your API key (get free at https://microjpeg.com/api-dashboard)
5. Enable auto-compress for new uploads

== Frequently Asked Questions ==

= Where do I get an API key? =

Visit https://microjpeg.com/api-dashboard to create a free account and get your API key. You get 200 free compressions per month.

= Will the plugin slow down my site? =

No. All compression happens on MicroJPEG servers, not on your WordPress site. The only delay is during upload, which typically takes a few seconds.

= Can I upload RAW camera files? =

Yes! This plugin enables RAW file uploads in WordPress (CR2, ARW, NEF, etc.) and automatically converts them to web-friendly formats.

= What happens to my original images? =

With "Backup Originals" enabled (default), your original files are preserved with a .microjpeg-backup extension.

= Can I undo compression? =

If you have backups enabled, you can restore original files. Go to your uploads folder and look for files ending in .microjpeg-backup.

== Screenshots ==

1. Settings page
2. Media library with compression status
3. Bulk optimization

== Changelog ==

= 3.0.0 =
* Complete rewrite for reliability
* Added RAW file MIME type registration
* Improved error handling and logging
* Better WordPress integration
* Statistics dashboard

= 2.0.1 =
* Bug fixes

= 2.0.0 =
* Initial API-based release

== Upgrade Notice ==

= 3.0.0 =
Major update with improved RAW file support and reliability. Recommended for all users.
