<?php
/**
 * Plugin Name: Micro JPEG Image Optimizer
 * Plugin URI: https://microjpeg.com/wordpress-plugin
 * Description: Automatically compress and optimize images using the MicroJPEG API. Supports JPEG, PNG, WebP, AVIF, SVG, TIFF, and RAW formats (CR2, ARW, DNG, NEF, ORF, RAF, RW2).
 * Version: 3.0.0
 * Author: MicroJPEG Team
 * Author URI: https://microjpeg.com
 * License: GPL v2 or later
 * Text Domain: micro-jpeg
 * Requires at least: 5.0
 * Tested up to: 6.7
 * Requires PHP: 7.4
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('MICRO_JPEG_VERSION', '3.0.0');
define('MICRO_JPEG_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MICRO_JPEG_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('MICRO_JPEG_API_BASE', 'https://microjpeg.com/api');

/**
 * Main Plugin Class
 */
class MicroJPEG_Optimizer {
    
    private static $instance = null;
    private $api_key = null;
    private $debug = true; // Enable debug logging
    
    /**
     * Singleton instance
     */
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Initialize
        add_action('init', array($this, 'init'));
        add_action('admin_init', array($this, 'admin_init'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Enqueue scripts
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // ============================================
        // CRITICAL: Register RAW file types in WordPress
        // ============================================
        add_filter('upload_mimes', array($this, 'add_raw_mime_types'));
        add_filter('wp_check_filetype_and_ext', array($this, 'fix_raw_filetype'), 10, 5);
        
        // ============================================
        // AUTO-COMPRESS: Hook into WordPress upload process
        // ============================================
        // Use 'add_attachment' hook - fires AFTER file is uploaded and attachment created
        add_action('add_attachment', array($this, 'on_attachment_added'), 10, 1);
        
        // Alternative: Hook into wp_handle_upload (earlier in process)
        add_filter('wp_handle_upload', array($this, 'handle_upload_compression'), 10, 2);
        
        // ============================================
        // AJAX Handlers
        // ============================================
        add_action('wp_ajax_micro_jpeg_test_key', array($this, 'ajax_test_api_key'));
        add_action('wp_ajax_micro_jpeg_optimize_single', array($this, 'ajax_optimize_single'));
        add_action('wp_ajax_micro_jpeg_bulk_optimize', array($this, 'ajax_bulk_optimize'));
        add_action('wp_ajax_micro_jpeg_get_stats', array($this, 'ajax_get_stats'));
        
        // ============================================
        // Media Library Column
        // ============================================
        add_filter('manage_media_columns', array($this, 'add_media_column'));
        add_action('manage_media_custom_column', array($this, 'display_media_column'), 10, 2);
        
        // Activation/Deactivation
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Admin notices
        add_action('admin_notices', array($this, 'admin_notices'));
    }
    
    /**
     * Debug logging
     */
    private function log($message, $data = null) {
        if (!$this->debug) return;
        
        $log_message = '[MicroJPEG] ' . $message;
        if ($data !== null) {
            $log_message .= ' | Data: ' . (is_array($data) || is_object($data) ? json_encode($data) : $data);
        }
        error_log($log_message);
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        $this->api_key = get_option('micro_jpeg_api_key', '');
        load_plugin_textdomain('micro-jpeg', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        $this->log('Plugin initialized', array(
            'has_api_key' => !empty($this->api_key),
            'auto_compress' => get_option('micro_jpeg_auto_compress', 0)
        ));
    }
    
    /**
     * Register settings
     */
    public function admin_init() {
        register_setting('micro_jpeg_settings', 'micro_jpeg_api_key', array(
            'sanitize_callback' => 'sanitize_text_field'
        ));
        
        register_setting('micro_jpeg_settings', 'micro_jpeg_auto_compress', array(
            'type' => 'boolean',
            'default' => 0
        ));
        
        register_setting('micro_jpeg_settings', 'micro_jpeg_quality', array(
            'type' => 'integer',
            'default' => 85,
            'sanitize_callback' => function($val) {
                return max(10, min(100, intval($val)));
            }
        ));
        
        register_setting('micro_jpeg_settings', 'micro_jpeg_output_format', array(
            'type' => 'string',
            'default' => 'keep-original'
        ));
        
        register_setting('micro_jpeg_settings', 'micro_jpeg_backup_originals', array(
            'type' => 'boolean',
            'default' => 1
        ));
        
        register_setting('micro_jpeg_settings', 'micro_jpeg_max_width', array(
            'type' => 'integer',
            'default' => 0 // 0 = no resize
        ));
    }
    
    /**
     * ============================================
     * ADD RAW MIME TYPES TO WORDPRESS
     * ============================================
     * This is CRITICAL - WordPress blocks RAW files by default
     */
    public function add_raw_mime_types($mimes) {
        // RAW Camera Formats
        $mimes['cr2'] = 'image/x-canon-cr2';
        $mimes['cr3'] = 'image/x-canon-cr3';
        $mimes['crw'] = 'image/x-canon-crw';
        $mimes['arw'] = 'image/x-sony-arw';
        $mimes['dng'] = 'image/x-adobe-dng';
        $mimes['nef'] = 'image/x-nikon-nef';
        $mimes['nrw'] = 'image/x-nikon-nrw';
        $mimes['orf'] = 'image/x-olympus-orf';
        $mimes['raf'] = 'image/x-fuji-raf';
        $mimes['rw2'] = 'image/x-panasonic-rw2';
        $mimes['pef'] = 'image/x-pentax-pef';
        $mimes['srw'] = 'image/x-samsung-srw';
        
        // Other image formats
        $mimes['avif'] = 'image/avif';
        $mimes['webp'] = 'image/webp';
        $mimes['tiff'] = 'image/tiff';
        $mimes['tif'] = 'image/tiff';
        
        $this->log('MIME types registered', array_keys($mimes));
        
        return $mimes;
    }
    
    /**
     * Fix file type detection for RAW files
     * WordPress sometimes fails to detect RAW file types correctly
     */
    public function fix_raw_filetype($data, $file, $filename, $mimes, $real_mime = null) {
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        $raw_types = array(
            'cr2' => 'image/x-canon-cr2',
            'cr3' => 'image/x-canon-cr3',
            'crw' => 'image/x-canon-crw',
            'arw' => 'image/x-sony-arw',
            'dng' => 'image/x-adobe-dng',
            'nef' => 'image/x-nikon-nef',
            'nrw' => 'image/x-nikon-nrw',
            'orf' => 'image/x-olympus-orf',
            'raf' => 'image/x-fuji-raf',
            'rw2' => 'image/x-panasonic-rw2',
            'pef' => 'image/x-pentax-pef',
            'srw' => 'image/x-samsung-srw',
        );
        
        if (isset($raw_types[$ext])) {
            $data['ext'] = $ext;
            $data['type'] = $raw_types[$ext];
            $this->log('Fixed RAW file type', array('ext' => $ext, 'type' => $raw_types[$ext]));
        }
        
        return $data;
    }
    
    /**
     * ============================================
     * HANDLE UPLOAD COMPRESSION
     * ============================================
     * This hooks into wp_handle_upload filter
     */
    public function handle_upload_compression($upload, $context = 'upload') {
        $this->log('handle_upload_compression called', array(
            'file' => $upload['file'] ?? 'unknown',
            'type' => $upload['type'] ?? 'unknown',
            'context' => $context
        ));
        
        // Check if auto-compress is enabled
        if (!get_option('micro_jpeg_auto_compress', 0)) {
            $this->log('Auto-compress is disabled');
            return $upload;
        }
        
        // Check if API key exists
        if (empty($this->api_key)) {
            $this->log('No API key configured');
            return $upload;
        }
        
        // Check if file exists
        if (!isset($upload['file']) || !file_exists($upload['file'])) {
            $this->log('File does not exist');
            return $upload;
        }
        
        // Check if it's an image we can process
        if (!$this->is_supported_image($upload['file'])) {
            $this->log('File is not a supported image type');
            return $upload;
        }
        
        // Compress the image
        $this->log('Starting compression for: ' . basename($upload['file']));
        $result = $this->compress_image($upload['file']);
        
        if ($result && !isset($result['error'])) {
            $this->log('Compression successful', array(
                'original_size' => $result['original_size'],
                'compressed_size' => $result['compressed_size'],
                'savings' => $result['savings_percent'] . '%'
            ));
        } else {
            $this->log('Compression failed', $result);
        }
        
        return $upload;
    }
    
    /**
     * Hook when attachment is added (alternative approach)
     */
    public function on_attachment_added($attachment_id) {
        $this->log('on_attachment_added called', array('attachment_id' => $attachment_id));
        
        // Check if auto-compress is enabled
        if (!get_option('micro_jpeg_auto_compress', 0)) {
            return;
        }
        
        // Check if already processed
        if (get_post_meta($attachment_id, '_micro_jpeg_compressed', true)) {
            $this->log('Already compressed, skipping');
            return;
        }
        
        // Get file path
        $file_path = get_attached_file($attachment_id);
        if (!$file_path || !file_exists($file_path)) {
            $this->log('File not found', array('path' => $file_path));
            return;
        }
        
        // Check if it's a supported image
        if (!$this->is_supported_image($file_path)) {
            return;
        }
        
        // Compress
        $result = $this->compress_image($file_path, $attachment_id);
        
        if ($result && !isset($result['error'])) {
            // Mark as compressed
            update_post_meta($attachment_id, '_micro_jpeg_compressed', 1);
            update_post_meta($attachment_id, '_micro_jpeg_original_size', $result['original_size']);
            update_post_meta($attachment_id, '_micro_jpeg_compressed_size', $result['compressed_size']);
            update_post_meta($attachment_id, '_micro_jpeg_savings', $result['savings_percent']);
            update_post_meta($attachment_id, '_micro_jpeg_date', current_time('mysql'));
            
            $this->log('Attachment metadata updated', array('attachment_id' => $attachment_id));
        }
    }
    
    /**
     * Check if file is a supported image
     */
    private function is_supported_image($file_path) {
        $ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        
        $supported = array(
            // Standard web formats
            'jpg', 'jpeg', 'png', 'webp', 'avif', 'gif',
            // Other formats
            'svg', 'tiff', 'tif', 'bmp', 'ico',
            // RAW formats
            'cr2', 'cr3', 'crw', 'arw', 'dng', 'nef', 'nrw', 'orf', 'raf', 'rw2', 'pef', 'srw'
        );
        
        return in_array($ext, $supported);
    }
    
    /**
     * ============================================
     * CORE COMPRESSION METHOD
     * ============================================
     */
    private function compress_image($file_path, $attachment_id = null) {
        $this->log('compress_image called', array('path' => $file_path));
        
        if (empty($this->api_key)) {
            return array('error' => 'No API key configured');
        }
        
        if (!file_exists($file_path)) {
            return array('error' => 'File not found: ' . $file_path);
        }
        
        $original_size = filesize($file_path);
        $filename = basename($file_path);
        $ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        
        // Determine if this is a RAW file
        $raw_formats = array('cr2', 'cr3', 'crw', 'arw', 'dng', 'nef', 'nrw', 'orf', 'raf', 'rw2', 'pef', 'srw');
        $is_raw = in_array($ext, $raw_formats);
        
        // Get settings
        $quality = get_option('micro_jpeg_quality', 85);
        $output_format = get_option('micro_jpeg_output_format', 'keep-original');
        
        // RAW files must be converted to a web format
        if ($is_raw && $output_format === 'keep-original') {
            $output_format = 'jpeg'; // Default RAW to JPEG
        }
        
        // Backup original if enabled
        $backup_path = null;
        if (get_option('micro_jpeg_backup_originals', 1)) {
            $backup_path = $file_path . '.microjpeg-backup';
            if (!copy($file_path, $backup_path)) {
                $this->log('Failed to create backup');
            } else {
                $this->log('Backup created at: ' . $backup_path);
            }
        }
        
        // Prepare the API request
        $this->log('Preparing API request', array(
            'filename' => $filename,
            'size' => $original_size,
            'quality' => $quality,
            'output_format' => $output_format
        ));
        
        // Build multipart form data
        $boundary = wp_generate_password(24, false);
        $body = $this->build_multipart_body($file_path, $filename, $quality, $output_format, $boundary);
        
        if (!$body) {
            return array('error' => 'Failed to read file for upload');
        }
        
        // Make API request
        $api_url = MICRO_JPEG_API_BASE . '/compress';
        
        $response = wp_remote_post($api_url, array(
            'timeout' => 120,
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'multipart/form-data; boundary=' . $boundary,
                'Accept' => 'application/json',
            ),
            'body' => $body,
            'sslverify' => true,
        ));
        
        if (is_wp_error($response)) {
            $this->log('API request failed', $response->get_error_message());
            return array('error' => 'API request failed: ' . $response->get_error_message());
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        $this->log('API response', array(
            'code' => $response_code,
            'body_length' => strlen($response_body),
            'body_preview' => substr($response_body, 0, 200)
        ));
        
        // Check for errors
        if ($response_code !== 200) {
            $error_data = json_decode($response_body, true);
            $error_msg = $error_data['message'] ?? $error_data['error'] ?? 'Unknown API error (code: ' . $response_code . ')';
            return array('error' => $error_msg);
        }
        
        // Parse response
        $api_result = json_decode($response_body, true);
        
        if (!$api_result) {
            return array('error' => 'Invalid JSON response from API');
        }
        
        // Check if API returned success
        if (isset($api_result['success']) && !$api_result['success']) {
            return array('error' => $api_result['message'] ?? 'Compression failed');
        }
        
        // Get compressed image data
        $compressed_data = null;
        
        // Handle different response formats
        if (isset($api_result['data']) && is_string($api_result['data'])) {
            // Base64 encoded data
            $compressed_data = base64_decode($api_result['data']);
        } elseif (isset($api_result['downloadUrl'])) {
            // Download URL provided
            $download_response = wp_remote_get($api_result['downloadUrl'], array('timeout' => 60));
            if (!is_wp_error($download_response)) {
                $compressed_data = wp_remote_retrieve_body($download_response);
            }
        } elseif (isset($api_result['compressedData'])) {
            $compressed_data = base64_decode($api_result['compressedData']);
        }
        
        if (!$compressed_data || strlen($compressed_data) < 100) {
            $this->log('No valid compressed data in response');
            return array('error' => 'No compressed image data received');
        }
        
        $compressed_size = strlen($compressed_data);
        
        // Only replace if compressed version is smaller
        if ($compressed_size >= $original_size) {
            $this->log('Compressed file not smaller, keeping original', array(
                'original' => $original_size,
                'compressed' => $compressed_size
            ));
            
            // Clean up backup
            if ($backup_path && file_exists($backup_path)) {
                unlink($backup_path);
            }
            
            return array(
                'original_size' => $original_size,
                'compressed_size' => $original_size,
                'savings_percent' => 0,
                'skipped' => true,
                'message' => 'Image already optimized'
            );
        }
        
        // Determine new filename if format changed
        $new_file_path = $file_path;
        if ($output_format !== 'keep-original' && $output_format !== $ext) {
            $new_file_path = preg_replace('/\.[^.]+$/', '.' . $output_format, $file_path);
        }
        
        // Save compressed file
        if (file_put_contents($new_file_path, $compressed_data) === false) {
            $this->log('Failed to save compressed file');
            return array('error' => 'Failed to save compressed file');
        }
        
        // If format changed and paths are different, remove old file
        if ($new_file_path !== $file_path && file_exists($file_path)) {
            unlink($file_path);
            
            // Update attachment if we have ID
            if ($attachment_id) {
                update_attached_file($attachment_id, $new_file_path);
                
                // Update post mime type
                $new_mime = $this->get_mime_type($output_format);
                wp_update_post(array(
                    'ID' => $attachment_id,
                    'post_mime_type' => $new_mime
                ));
            }
        }
        
        $savings_percent = round((1 - $compressed_size / $original_size) * 100, 1);
        
        $this->log('Compression complete', array(
            'original' => $original_size,
            'compressed' => $compressed_size,
            'savings' => $savings_percent . '%'
        ));
        
        return array(
            'original_size' => $original_size,
            'compressed_size' => $compressed_size,
            'savings_percent' => $savings_percent,
            'new_path' => $new_file_path,
        );
    }
    
    /**
     * Build multipart form body
     */
    private function build_multipart_body($file_path, $filename, $quality, $output_format, $boundary) {
        $file_content = file_get_contents($file_path);
        if ($file_content === false) {
            return null;
        }
        
        $body = '';
        
        // Add quality
        $body .= '--' . $boundary . "\r\n";
        $body .= 'Content-Disposition: form-data; name="quality"' . "\r\n\r\n";
        $body .= $quality . "\r\n";
        
        // Add output format
        $body .= '--' . $boundary . "\r\n";
        $body .= 'Content-Disposition: form-data; name="outputFormat"' . "\r\n\r\n";
        $body .= $output_format . "\r\n";
        
        // Add file
        $mime_type = $this->get_mime_type(pathinfo($filename, PATHINFO_EXTENSION));
        $body .= '--' . $boundary . "\r\n";
        $body .= 'Content-Disposition: form-data; name="image"; filename="' . $filename . '"' . "\r\n";
        $body .= 'Content-Type: ' . $mime_type . "\r\n\r\n";
        $body .= $file_content . "\r\n";
        
        // End boundary
        $body .= '--' . $boundary . '--' . "\r\n";
        
        return $body;
    }
    
    /**
     * Get MIME type for extension
     */
    private function get_mime_type($ext) {
        $ext = strtolower($ext);
        $types = array(
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'webp' => 'image/webp',
            'avif' => 'image/avif',
            'gif' => 'image/gif',
            'svg' => 'image/svg+xml',
            'tiff' => 'image/tiff',
            'tif' => 'image/tiff',
            'bmp' => 'image/bmp',
            'ico' => 'image/x-icon',
            'cr2' => 'image/x-canon-cr2',
            'cr3' => 'image/x-canon-cr3',
            'arw' => 'image/x-sony-arw',
            'dng' => 'image/x-adobe-dng',
            'nef' => 'image/x-nikon-nef',
            'orf' => 'image/x-olympus-orf',
            'raf' => 'image/x-fuji-raf',
            'rw2' => 'image/x-panasonic-rw2',
        );
        
        return $types[$ext] ?? 'application/octet-stream';
    }
    
    /**
     * ============================================
     * ADMIN MENU
     * ============================================
     */
    public function add_admin_menu() {
        add_media_page(
            __('MicroJPEG Settings', 'micro-jpeg'),
            __('MicroJPEG', 'micro-jpeg'),
            'manage_options',
            'micro-jpeg-settings',
            array($this, 'render_settings_page')
        );
    }
    
    /**
     * Enqueue admin scripts
     */
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'micro-jpeg') === false && $hook !== 'upload.php') {
            return;
        }
        
        wp_enqueue_script(
            'micro-jpeg-admin',
            MICRO_JPEG_PLUGIN_URL . 'assets/admin.js',
            array('jquery'),
            MICRO_JPEG_VERSION,
            true
        );
        
        wp_localize_script('micro-jpeg-admin', 'microJpegAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('micro_jpeg_nonce'),
            'strings' => array(
                'testing' => __('Testing...', 'micro-jpeg'),
                'testKey' => __('Test API Key', 'micro-jpeg'),
                'optimizing' => __('Optimizing...', 'micro-jpeg'),
                'optimize' => __('Optimize', 'micro-jpeg'),
            )
        ));
        
        wp_enqueue_style(
            'micro-jpeg-admin',
            MICRO_JPEG_PLUGIN_URL . 'assets/admin.css',
            array(),
            MICRO_JPEG_VERSION
        );
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        ?>
        <div class="wrap micro-jpeg-settings">
            <h1>
                <img src="<?php echo esc_url(MICRO_JPEG_PLUGIN_URL . 'assets/logo.png'); ?>" alt="MicroJPEG" style="height: 32px; vertical-align: middle; margin-right: 10px;">
                <?php _e('MicroJPEG Image Optimizer', 'micro-jpeg'); ?>
            </h1>
            
            <div class="micro-jpeg-card">
                <h2><?php _e('API Configuration', 'micro-jpeg'); ?></h2>
                
                <form method="post" action="options.php">
                    <?php settings_fields('micro_jpeg_settings'); ?>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="micro_jpeg_api_key"><?php _e('API Key', 'micro-jpeg'); ?></label>
                            </th>
                            <td>
                                <input type="text" 
                                       id="micro_jpeg_api_key" 
                                       name="micro_jpeg_api_key" 
                                       value="<?php echo esc_attr(get_option('micro_jpeg_api_key', '')); ?>" 
                                       class="regular-text"
                                       placeholder="sk_live_xxxxxxxxxxxxxxxx">
                                <button type="button" id="micro-jpeg-test-key" class="button">
                                    <?php _e('Test API Key', 'micro-jpeg'); ?>
                                </button>
                                <span id="micro-jpeg-test-result"></span>
                                <p class="description">
                                    <?php _e("Don't have an API key?", 'micro-jpeg'); ?>
                                    <a href="https://microjpeg.com/api-dashboard" target="_blank">
                                        <?php _e('Get your free API key', 'micro-jpeg'); ?>
                                    </a>
                                    (<?php _e('200 free compressions/month', 'micro-jpeg'); ?>)
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row"><?php _e('Auto-Compress Uploads', 'micro-jpeg'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" 
                                           name="micro_jpeg_auto_compress" 
                                           value="1" 
                                           <?php checked(get_option('micro_jpeg_auto_compress', 0), 1); ?>>
                                    <?php _e('Automatically compress images when uploaded to Media Library', 'micro-jpeg'); ?>
                                </label>
                                <p class="description">
                                    <?php _e('When enabled, all new image uploads will be automatically optimized.', 'micro-jpeg'); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="micro_jpeg_quality"><?php _e('Compression Quality', 'micro-jpeg'); ?></label>
                            </th>
                            <td>
                                <input type="range" 
                                       id="micro_jpeg_quality" 
                                       name="micro_jpeg_quality" 
                                       min="10" 
                                       max="100" 
                                       value="<?php echo esc_attr(get_option('micro_jpeg_quality', 85)); ?>">
                                <span id="quality-value"><?php echo esc_html(get_option('micro_jpeg_quality', 85)); ?>%</span>
                                <p class="description">
                                    <?php _e('Higher = better quality, larger file. Recommended: 80-90% for web.', 'micro-jpeg'); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="micro_jpeg_output_format"><?php _e('Output Format', 'micro-jpeg'); ?></label>
                            </th>
                            <td>
                                <select id="micro_jpeg_output_format" name="micro_jpeg_output_format">
                                    <option value="keep-original" <?php selected(get_option('micro_jpeg_output_format', 'keep-original'), 'keep-original'); ?>>
                                        <?php _e('Keep Original Format', 'micro-jpeg'); ?>
                                    </option>
                                    <option value="jpeg" <?php selected(get_option('micro_jpeg_output_format'), 'jpeg'); ?>>JPEG</option>
                                    <option value="webp" <?php selected(get_option('micro_jpeg_output_format'), 'webp'); ?>>WebP</option>
                                    <option value="avif" <?php selected(get_option('micro_jpeg_output_format'), 'avif'); ?>>AVIF</option>
                                    <option value="png" <?php selected(get_option('micro_jpeg_output_format'), 'png'); ?>>PNG</option>
                                </select>
                                <p class="description">
                                    <?php _e('RAW files (CR2, NEF, ARW, etc.) will always be converted to a web format.', 'micro-jpeg'); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row"><?php _e('Backup Originals', 'micro-jpeg'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" 
                                           name="micro_jpeg_backup_originals" 
                                           value="1" 
                                           <?php checked(get_option('micro_jpeg_backup_originals', 1), 1); ?>>
                                    <?php _e('Keep backup of original images before compression', 'micro-jpeg'); ?>
                                </label>
                            </td>
                        </tr>
                    </table>
                    
                    <?php submit_button(); ?>
                </form>
            </div>
            
            <div class="micro-jpeg-card">
                <h2><?php _e('Compression Statistics', 'micro-jpeg'); ?></h2>
                <div id="micro-jpeg-stats">
                    <?php $this->render_stats(); ?>
                </div>
            </div>
            
            <div class="micro-jpeg-card">
                <h2><?php _e('Supported Formats', 'micro-jpeg'); ?></h2>
                <p><?php _e('Standard:', 'micro-jpeg'); ?> <strong>JPEG, PNG, WebP, AVIF, GIF, SVG, TIFF, BMP</strong></p>
                <p><?php _e('RAW Camera:', 'micro-jpeg'); ?> <strong>CR2, CR3, CRW (Canon), ARW (Sony), NEF, NRW (Nikon), DNG (Adobe), ORF (Olympus), RAF (Fuji), RW2 (Panasonic), PEF (Pentax), SRW (Samsung)</strong></p>
            </div>
        </div>
        
        <style>
            .micro-jpeg-settings { max-width: 800px; }
            .micro-jpeg-card { 
                background: #fff; 
                border: 1px solid #ccd0d4; 
                box-shadow: 0 1px 1px rgba(0,0,0,.04);
                padding: 20px; 
                margin: 20px 0; 
                border-radius: 4px;
            }
            .micro-jpeg-card h2 { margin-top: 0; border-bottom: 1px solid #eee; padding-bottom: 10px; }
            #micro-jpeg-test-result { margin-left: 10px; }
            #micro-jpeg-test-result.success { color: #46b450; }
            #micro-jpeg-test-result.error { color: #dc3232; }
            .micro-jpeg-stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; }
            .micro-jpeg-stat { 
                background: #f8f9fa; 
                padding: 15px; 
                border-radius: 4px; 
                text-align: center; 
            }
            .micro-jpeg-stat strong { display: block; font-size: 24px; color: #0073aa; }
            .micro-jpeg-stat span { color: #666; font-size: 12px; }
        </style>
        <?php
    }
    
    /**
     * Render compression statistics
     */
    private function render_stats() {
        global $wpdb;
        
        // Count optimized images
        $optimized = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_micro_jpeg_compressed' AND meta_value = '1'"
        );
        
        // Total savings
        $total_original = $wpdb->get_var(
            "SELECT SUM(meta_value) FROM {$wpdb->postmeta} WHERE meta_key = '_micro_jpeg_original_size'"
        );
        $total_compressed = $wpdb->get_var(
            "SELECT SUM(meta_value) FROM {$wpdb->postmeta} WHERE meta_key = '_micro_jpeg_compressed_size'"
        );
        
        $total_saved = $total_original ? ($total_original - $total_compressed) : 0;
        $avg_savings = $total_original ? round((1 - $total_compressed / $total_original) * 100, 1) : 0;
        
        ?>
        <div class="micro-jpeg-stats-grid">
            <div class="micro-jpeg-stat">
                <strong><?php echo esc_html($optimized ?: 0); ?></strong>
                <span><?php _e('Images Optimized', 'micro-jpeg'); ?></span>
            </div>
            <div class="micro-jpeg-stat">
                <strong><?php echo esc_html(size_format($total_saved)); ?></strong>
                <span><?php _e('Total Saved', 'micro-jpeg'); ?></span>
            </div>
            <div class="micro-jpeg-stat">
                <strong><?php echo esc_html($avg_savings); ?>%</strong>
                <span><?php _e('Avg. Savings', 'micro-jpeg'); ?></span>
            </div>
            <div class="micro-jpeg-stat">
                <strong><?php echo esc_html(size_format($total_original ?: 0)); ?></strong>
                <span><?php _e('Original Size', 'micro-jpeg'); ?></span>
            </div>
        </div>
        <?php
    }
    
    /**
     * ============================================
     * MEDIA LIBRARY COLUMN
     * ============================================
     */
    public function add_media_column($columns) {
        $columns['micro_jpeg'] = __('Compression', 'micro-jpeg');
        return $columns;
    }
    
    public function display_media_column($column_name, $attachment_id) {
        if ($column_name !== 'micro_jpeg') {
            return;
        }
        
        $file = get_attached_file($attachment_id);
        if (!$file || !$this->is_supported_image($file)) {
            echo '<span style="color: #999;">—</span>';
            return;
        }
        
        $is_compressed = get_post_meta($attachment_id, '_micro_jpeg_compressed', true);
        
        if ($is_compressed) {
            $savings = get_post_meta($attachment_id, '_micro_jpeg_savings', true);
            echo '<span style="color: #46b450;">✓ ' . esc_html($savings) . '%</span>';
        } else {
            echo '<a href="#" class="micro-jpeg-optimize" data-id="' . esc_attr($attachment_id) . '">' . 
                 __('Optimize', 'micro-jpeg') . '</a>';
        }
    }
    
    /**
     * ============================================
     * AJAX HANDLERS
     * ============================================
     */
    public function ajax_test_api_key() {
        check_ajax_referer('micro_jpeg_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'micro-jpeg'));
        }
        
        $api_key = sanitize_text_field($_POST['api_key'] ?? '');
        
        if (empty($api_key)) {
            wp_send_json_error(__('Please enter an API key', 'micro-jpeg'));
        }
        
        // Test the API key by making a simple request
        $response = wp_remote_get(MICRO_JPEG_API_BASE . '/user/tier-info', array(
            'timeout' => 15,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Accept' => 'application/json',
            )
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error(__('Connection failed: ', 'micro-jpeg') . $response->get_error_message());
        }
        
        $code = wp_remote_retrieve_response_code($response);
        
        if ($code === 200) {
            wp_send_json_success(__('API key is valid!', 'micro-jpeg'));
        } elseif ($code === 401) {
            wp_send_json_error(__('Invalid API key', 'micro-jpeg'));
        } else {
            wp_send_json_error(sprintf(__('API error (code: %d)', 'micro-jpeg'), $code));
        }
    }
    
    public function ajax_optimize_single() {
        check_ajax_referer('micro_jpeg_nonce', 'nonce');
        
        if (!current_user_can('upload_files')) {
            wp_send_json_error(__('Unauthorized', 'micro-jpeg'));
        }
        
        $attachment_id = intval($_POST['attachment_id'] ?? 0);
        
        if (!$attachment_id) {
            wp_send_json_error(__('Invalid attachment ID', 'micro-jpeg'));
        }
        
        $file = get_attached_file($attachment_id);
        if (!$file || !file_exists($file)) {
            wp_send_json_error(__('File not found', 'micro-jpeg'));
        }
        
        // Temporarily set API key
        $this->api_key = get_option('micro_jpeg_api_key', '');
        
        $result = $this->compress_image($file, $attachment_id);
        
        if (isset($result['error'])) {
            wp_send_json_error($result['error']);
        }
        
        // Save meta
        update_post_meta($attachment_id, '_micro_jpeg_compressed', 1);
        update_post_meta($attachment_id, '_micro_jpeg_original_size', $result['original_size']);
        update_post_meta($attachment_id, '_micro_jpeg_compressed_size', $result['compressed_size']);
        update_post_meta($attachment_id, '_micro_jpeg_savings', $result['savings_percent']);
        
        wp_send_json_success(array(
            'savings' => $result['savings_percent'],
            'message' => sprintf(__('Saved %s%%', 'micro-jpeg'), $result['savings_percent'])
        ));
    }
    
    public function ajax_bulk_optimize() {
        check_ajax_referer('micro_jpeg_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'micro-jpeg'));
        }
        
        // Get unoptimized images
        global $wpdb;
        
        $attachments = $wpdb->get_col(
            "SELECT p.ID FROM {$wpdb->posts} p
             LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_micro_jpeg_compressed'
             WHERE p.post_type = 'attachment' 
             AND p.post_mime_type LIKE 'image/%'
             AND (pm.meta_value IS NULL OR pm.meta_value != '1')
             LIMIT 5"
        );
        
        if (empty($attachments)) {
            wp_send_json_success(array('complete' => true, 'message' => __('All images are optimized!', 'micro-jpeg')));
        }
        
        $this->api_key = get_option('micro_jpeg_api_key', '');
        $results = array();
        
        foreach ($attachments as $attachment_id) {
            $file = get_attached_file($attachment_id);
            if ($file && file_exists($file) && $this->is_supported_image($file)) {
                $result = $this->compress_image($file, $attachment_id);
                
                if (!isset($result['error'])) {
                    update_post_meta($attachment_id, '_micro_jpeg_compressed', 1);
                    update_post_meta($attachment_id, '_micro_jpeg_original_size', $result['original_size']);
                    update_post_meta($attachment_id, '_micro_jpeg_compressed_size', $result['compressed_size']);
                    update_post_meta($attachment_id, '_micro_jpeg_savings', $result['savings_percent']);
                }
                
                $results[] = array(
                    'id' => $attachment_id,
                    'success' => !isset($result['error']),
                    'savings' => $result['savings_percent'] ?? 0
                );
            }
        }
        
        wp_send_json_success(array(
            'processed' => count($results),
            'results' => $results,
            'complete' => false
        ));
    }
    
    public function ajax_get_stats() {
        check_ajax_referer('micro_jpeg_nonce', 'nonce');
        
        ob_start();
        $this->render_stats();
        $html = ob_get_clean();
        
        wp_send_json_success(array('html' => $html));
    }
    
    /**
     * Admin notices
     */
    public function admin_notices() {
        // Check if API key is configured
        if (empty(get_option('micro_jpeg_api_key', ''))) {
            $screen = get_current_screen();
            if ($screen && strpos($screen->id, 'micro-jpeg') !== false) {
                ?>
                <div class="notice notice-warning">
                    <p>
                        <strong><?php _e('MicroJPEG:', 'micro-jpeg'); ?></strong>
                        <?php _e('Please enter your API key to start optimizing images.', 'micro-jpeg'); ?>
                        <a href="https://microjpeg.com/api-dashboard" target="_blank"><?php _e('Get your free API key', 'micro-jpeg'); ?></a>
                    </p>
                </div>
                <?php
            }
        }
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Set default options
        add_option('micro_jpeg_auto_compress', 0);
        add_option('micro_jpeg_quality', 85);
        add_option('micro_jpeg_output_format', 'keep-original');
        add_option('micro_jpeg_backup_originals', 1);
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clean up temporary files
        $upload_dir = wp_upload_dir();
        $backup_files = glob($upload_dir['basedir'] . '/**/*.microjpeg-backup');
        // Don't delete backups on deactivation - user might want them
    }
}

// Initialize plugin
MicroJPEG_Optimizer::get_instance();
