using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Moq;
using Moq.Protected;
using Xunit;

namespace MicroJpeg.Tests
{
    public class MicroJpegClientTests
    {
        [Fact]
        public void Constructor_WithNullApiKey_ThrowsArgumentNullException()
        {
            Assert.Throws<ArgumentNullException>(() => new MicroJpegClient(null!));
            Assert.Throws<ArgumentNullException>(() => new MicroJpegClient(""));
            Assert.Throws<ArgumentNullException>(() => new MicroJpegClient("   "));
        }

        [Fact]
        public void Constructor_WithValidApiKey_CreatesInstance()
        {
            using var client = new MicroJpegClient("test-api-key");
            Assert.NotNull(client);
        }

        [Fact]
        public void Constructor_WithCustomEndpoint_SetsEndpoint()
        {
            using var client = new MicroJpegClient("test-api-key", apiEndpoint: "https://custom.api.com");
            Assert.Equal("https://custom.api.com", client.ApiEndpoint);
        }

        [Fact]
        public async Task CompressAsync_WithNonExistentFile_ThrowsFileNotFoundException()
        {
            using var client = new MicroJpegClient("test-api-key");
            await Assert.ThrowsAsync<FileNotFoundException>(() => 
                client.CompressAsync("/non/existent/file.jpg"));
        }

        [Fact]
        public void CompressOptions_DefaultValues_AreCorrect()
        {
            var options = new CompressOptions();
            Assert.Equal(85, options.Quality);
            Assert.Null(options.OutputFormat);
            Assert.Null(options.ResizeWidth);
            Assert.Null(options.ResizeHeight);
            Assert.Null(options.ResizeMode);
        }

        [Fact]
        public void BackgroundRemovalOptions_DefaultValues_AreCorrect()
        {
            var options = new BackgroundRemovalOptions();
            Assert.Equal("png", options.OutputFormat);
            Assert.Equal(90, options.Quality);
        }

        [Fact]
        public void EnhanceOptions_DefaultValues_AreCorrect()
        {
            var options = new EnhanceOptions();
            Assert.Equal(2, options.Scale);
            Assert.False(options.FaceEnhance);
            Assert.Equal("png", options.OutputFormat);
            Assert.Equal(90, options.Quality);
        }

        [Fact]
        public void CompressResult_SavingsPercent_CalculatesCorrectly()
        {
            var result = new CompressResult
            {
                OriginalSize = 1000,
                CompressedSize = 350
            };
            
            Assert.Equal(65.0, result.SavingsPercent);
        }

        [Fact]
        public void CompressResult_SavingsPercent_WithZeroOriginal_ReturnsZero()
        {
            var result = new CompressResult
            {
                OriginalSize = 0,
                CompressedSize = 0
            };
            
            Assert.Equal(0, result.SavingsPercent);
        }

        [Fact]
        public void MicroJpegApiException_Properties_AreSet()
        {
            var ex = new MicroJpegApiException(429, "Too Many Requests", "limit_reached", "Monthly limit exceeded");
            
            Assert.Equal(429, ex.StatusCode);
            Assert.Equal("Too Many Requests", ex.ReasonPhrase);
            Assert.Equal("limit_reached", ex.ErrorCode);
            Assert.Equal("Monthly limit exceeded", ex.ErrorMessage);
            Assert.True(ex.IsLimitReached);
            Assert.False(ex.IsUnauthorized);
        }

        [Fact]
        public void MicroJpegApiException_IsUnauthorized_ReturnsTrueFor401()
        {
            var ex = new MicroJpegApiException(401, "Unauthorized", "invalid_key", "Invalid API key");
            
            Assert.True(ex.IsUnauthorized);
            Assert.False(ex.IsLimitReached);
        }

        [Fact]
        public void MicroJpegApiException_IsFileTooLarge_ReturnsTrueForCode()
        {
            var ex = new MicroJpegApiException(413, "Payload Too Large", "file_too_large", "File exceeds limit");
            
            Assert.True(ex.IsFileTooLarge);
        }

        [Fact]
        public void MicroJpegApiException_IsFeatureRestricted_ReturnsTrueForCodes()
        {
            var ex1 = new MicroJpegApiException(403, "Forbidden", "feature_restricted", "Requires upgrade");
            var ex2 = new MicroJpegApiException(403, "Forbidden", "format_restricted", "Format not available");
            
            Assert.True(ex1.IsFeatureRestricted);
            Assert.True(ex2.IsFeatureRestricted);
        }
    }

    public class CompressOptionsTests
    {
        [Theory]
        [InlineData(1)]
        [InlineData(50)]
        [InlineData(100)]
        public void Quality_AcceptsValidValues(int quality)
        {
            var options = new CompressOptions { Quality = quality };
            Assert.Equal(quality, options.Quality);
        }

        [Theory]
        [InlineData("jpeg")]
        [InlineData("png")]
        [InlineData("webp")]
        [InlineData("avif")]
        public void OutputFormat_AcceptsValidFormats(string format)
        {
            var options = new CompressOptions { OutputFormat = format };
            Assert.Equal(format, options.OutputFormat);
        }
    }
}
