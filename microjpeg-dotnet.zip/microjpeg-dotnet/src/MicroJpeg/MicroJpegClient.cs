using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MicroJpeg
{
    /// <summary>
    /// Client for the MicroJPEG image compression API.
    /// Supports compression, conversion, background removal, and image enhancement.
    /// </summary>
    public class MicroJpegClient : IDisposable
    {
        private readonly HttpClient _httpClient;
        private readonly bool _disposeHttpClient;
        private readonly string _apiKey;
        
        private const string DefaultApiEndpoint = "https://microjpeg.com/api/v1";
        
        /// <summary>
        /// The base URL for the MicroJPEG API
        /// </summary>
        public string ApiEndpoint { get; }

        /// <summary>
        /// Gets the number of compressions performed by this client.
        /// Updated after each successful operation.
        /// </summary>
        public int CompressionCount { get; internal set; }

        /// <summary>
        /// Creates a new MicroJpegClient instance.
        /// </summary>
        /// <param name="apiKey">Your MicroJPEG API key from https://microjpeg.com/api-dashboard</param>
        /// <param name="httpClient">Optional HttpClient instance for custom configuration</param>
        /// <param name="apiEndpoint">Optional custom API endpoint URL</param>
        public MicroJpegClient(string apiKey, HttpClient? httpClient = null, string? apiEndpoint = null)
        {
            if (string.IsNullOrWhiteSpace(apiKey))
                throw new ArgumentNullException(nameof(apiKey), "API key is required");

            _apiKey = apiKey;
            ApiEndpoint = apiEndpoint ?? DefaultApiEndpoint;

            if (httpClient != null)
            {
                _httpClient = httpClient;
                _disposeHttpClient = false;
            }
            else
            {
                _httpClient = new HttpClient();
                _disposeHttpClient = true;
            }

            // Set up authorization header
            _httpClient.DefaultRequestHeaders.Authorization = 
                new AuthenticationHeaderValue("Bearer", _apiKey);
            
            _httpClient.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
        }

        #region Compress Methods

        /// <summary>
        /// Compress an image from a file path.
        /// </summary>
        /// <param name="filePath">Path to the image file</param>
        /// <param name="options">Optional compression settings</param>
        /// <returns>Compression result containing URLs and metadata</returns>
        public async Task<CompressResponse> CompressAsync(string filePath, CompressOptions? options = null)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException("Image file not found", filePath);

            var fileBytes = await File.ReadAllBytesAsync(filePath);
            var fileName = Path.GetFileName(filePath);
            
            return await CompressAsync(fileBytes, fileName, options);
        }

        /// <summary>
        /// Compress an image from a byte array.
        /// </summary>
        /// <param name="imageData">Image data as byte array</param>
        /// <param name="fileName">Original filename (used for format detection)</param>
        /// <param name="options">Optional compression settings</param>
        /// <returns>Compression result containing URLs and metadata</returns>
        public async Task<CompressResponse> CompressAsync(byte[] imageData, string fileName, CompressOptions? options = null)
        {
            using var stream = new MemoryStream(imageData);
            return await CompressAsync(stream, fileName, options);
        }

        /// <summary>
        /// Compress an image from a stream.
        /// </summary>
        /// <param name="imageStream">Stream containing the image data</param>
        /// <param name="fileName">Original filename (used for format detection)</param>
        /// <param name="options">Optional compression settings</param>
        /// <returns>Compression result containing URLs and metadata</returns>
        public async Task<CompressResponse> CompressAsync(Stream imageStream, string fileName, CompressOptions? options = null)
        {
            options ??= new CompressOptions();

            using var content = new MultipartFormDataContent();
            
            var streamContent = new StreamContent(imageStream);
            streamContent.Headers.ContentType = new MediaTypeHeaderValue(GetMimeType(fileName));
            content.Add(streamContent, "file", fileName);
            
            // Add compression options
            var settings = new
            {
                quality = options.Quality,
                outputFormat = options.OutputFormat ?? "keep-original",
                resizeWidth = options.ResizeWidth,
                resizeHeight = options.ResizeHeight,
                resizeMode = options.ResizeMode?.ToString().ToLower()
            };
            
            content.Add(new StringContent(JsonSerializer.Serialize(settings)), "settings");

            var response = await _httpClient.PostAsync($"{ApiEndpoint}/compress", content);
            
            return await HandleResponseAsync<CompressResponse>(response);
        }

        /// <summary>
        /// Compress an image from a URL.
        /// </summary>
        /// <param name="imageUrl">URL of the image to compress</param>
        /// <param name="options">Optional compression settings</param>
        /// <returns>Compression result containing URLs and metadata</returns>
        public async Task<CompressResponse> CompressAsync(Uri imageUrl, CompressOptions? options = null)
        {
            options ??= new CompressOptions();

            var requestBody = new
            {
                url = imageUrl.ToString(),
                quality = options.Quality,
                outputFormat = options.OutputFormat ?? "keep-original",
                resizeWidth = options.ResizeWidth,
                resizeHeight = options.ResizeHeight,
                resizeMode = options.ResizeMode?.ToString().ToLower()
            };

            var json = JsonSerializer.Serialize(requestBody);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync($"{ApiEndpoint}/compress-url", content);
            
            return await HandleResponseAsync<CompressResponse>(response);
        }

        #endregion

        #region Convert Methods

        /// <summary>
        /// Convert an image to a different format.
        /// </summary>
        /// <param name="filePath">Path to the image file</param>
        /// <param name="outputFormat">Target format (jpeg, png, webp, avif)</param>
        /// <param name="quality">Quality setting 1-100 (default: 85)</param>
        /// <returns>Conversion result</returns>
        public async Task<ConvertResponse> ConvertAsync(string filePath, string outputFormat, int quality = 85)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException("Image file not found", filePath);

            var fileBytes = await File.ReadAllBytesAsync(filePath);
            var fileName = Path.GetFileName(filePath);
            
            return await ConvertAsync(fileBytes, fileName, outputFormat, quality);
        }

        /// <summary>
        /// Convert an image to a different format.
        /// </summary>
        /// <param name="imageData">Image data as byte array</param>
        /// <param name="fileName">Original filename</param>
        /// <param name="outputFormat">Target format (jpeg, png, webp, avif)</param>
        /// <param name="quality">Quality setting 1-100 (default: 85)</param>
        /// <returns>Conversion result</returns>
        public async Task<ConvertResponse> ConvertAsync(byte[] imageData, string fileName, string outputFormat, int quality = 85)
        {
            using var stream = new MemoryStream(imageData);
            return await ConvertAsync(stream, fileName, outputFormat, quality);
        }

        /// <summary>
        /// Convert an image to a different format.
        /// </summary>
        /// <param name="imageStream">Stream containing the image data</param>
        /// <param name="fileName">Original filename</param>
        /// <param name="outputFormat">Target format (jpeg, png, webp, avif)</param>
        /// <param name="quality">Quality setting 1-100 (default: 85)</param>
        /// <returns>Conversion result</returns>
        public async Task<ConvertResponse> ConvertAsync(Stream imageStream, string fileName, string outputFormat, int quality = 85)
        {
            using var content = new MultipartFormDataContent();
            
            var streamContent = new StreamContent(imageStream);
            streamContent.Headers.ContentType = new MediaTypeHeaderValue(GetMimeType(fileName));
            content.Add(streamContent, "file", fileName);
            
            var settings = new { outputFormat, quality };
            content.Add(new StringContent(JsonSerializer.Serialize(settings)), "settings");

            var response = await _httpClient.PostAsync($"{ApiEndpoint}/convert", content);
            
            return await HandleResponseAsync<ConvertResponse>(response);
        }

        #endregion

        #region Background Removal Methods

        /// <summary>
        /// Remove background from an image using AI.
        /// </summary>
        /// <param name="filePath">Path to the image file</param>
        /// <param name="options">Optional background removal settings</param>
        /// <returns>Background removal result</returns>
        public async Task<BackgroundRemovalResponse> RemoveBackgroundAsync(string filePath, BackgroundRemovalOptions? options = null)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException("Image file not found", filePath);

            var fileBytes = await File.ReadAllBytesAsync(filePath);
            var fileName = Path.GetFileName(filePath);
            
            return await RemoveBackgroundAsync(fileBytes, fileName, options);
        }

        /// <summary>
        /// Remove background from an image using AI.
        /// </summary>
        /// <param name="imageData">Image data as byte array</param>
        /// <param name="fileName">Original filename</param>
        /// <param name="options">Optional background removal settings</param>
        /// <returns>Background removal result</returns>
        public async Task<BackgroundRemovalResponse> RemoveBackgroundAsync(byte[] imageData, string fileName, BackgroundRemovalOptions? options = null)
        {
            using var stream = new MemoryStream(imageData);
            return await RemoveBackgroundAsync(stream, fileName, options);
        }

        /// <summary>
        /// Remove background from an image using AI.
        /// </summary>
        /// <param name="imageStream">Stream containing the image data</param>
        /// <param name="fileName">Original filename</param>
        /// <param name="options">Optional background removal settings</param>
        /// <returns>Background removal result</returns>
        public async Task<BackgroundRemovalResponse> RemoveBackgroundAsync(Stream imageStream, string fileName, BackgroundRemovalOptions? options = null)
        {
            options ??= new BackgroundRemovalOptions();

            using var content = new MultipartFormDataContent();
            
            var streamContent = new StreamContent(imageStream);
            streamContent.Headers.ContentType = new MediaTypeHeaderValue(GetMimeType(fileName));
            content.Add(streamContent, "file", fileName);
            
            content.Add(new StringContent(options.OutputFormat), "outputFormat");
            content.Add(new StringContent(options.Quality.ToString()), "quality");

            var response = await _httpClient.PostAsync($"{ApiEndpoint}/remove-background", content);
            
            return await HandleResponseAsync<BackgroundRemovalResponse>(response);
        }

        #endregion

        #region Image Enhancement Methods

        /// <summary>
        /// Enhance/upscale an image using AI.
        /// </summary>
        /// <param name="filePath">Path to the image file</param>
        /// <param name="options">Optional enhancement settings</param>
        /// <returns>Enhancement result</returns>
        public async Task<EnhanceResponse> EnhanceAsync(string filePath, EnhanceOptions? options = null)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException("Image file not found", filePath);

            var fileBytes = await File.ReadAllBytesAsync(filePath);
            var fileName = Path.GetFileName(filePath);
            
            return await EnhanceAsync(fileBytes, fileName, options);
        }

        /// <summary>
        /// Enhance/upscale an image using AI.
        /// </summary>
        /// <param name="imageData">Image data as byte array</param>
        /// <param name="fileName">Original filename</param>
        /// <param name="options">Optional enhancement settings</param>
        /// <returns>Enhancement result</returns>
        public async Task<EnhanceResponse> EnhanceAsync(byte[] imageData, string fileName, EnhanceOptions? options = null)
        {
            using var stream = new MemoryStream(imageData);
            return await EnhanceAsync(stream, fileName, options);
        }

        /// <summary>
        /// Enhance/upscale an image using AI.
        /// </summary>
        /// <param name="imageStream">Stream containing the image data</param>
        /// <param name="fileName">Original filename</param>
        /// <param name="options">Optional enhancement settings</param>
        /// <returns>Enhancement result</returns>
        public async Task<EnhanceResponse> EnhanceAsync(Stream imageStream, string fileName, EnhanceOptions? options = null)
        {
            options ??= new EnhanceOptions();

            using var content = new MultipartFormDataContent();
            
            var streamContent = new StreamContent(imageStream);
            streamContent.Headers.ContentType = new MediaTypeHeaderValue(GetMimeType(fileName));
            content.Add(streamContent, "file", fileName);
            
            content.Add(new StringContent(options.Scale.ToString()), "scale");
            content.Add(new StringContent(options.FaceEnhance.ToString().ToLower()), "faceEnhance");
            content.Add(new StringContent(options.OutputFormat), "outputFormat");
            content.Add(new StringContent(options.Quality.ToString()), "quality");

            var response = await _httpClient.PostAsync($"{ApiEndpoint}/enhance-image", content);
            
            return await HandleResponseAsync<EnhanceResponse>(response);
        }

        #endregion

        #region Download Methods

        /// <summary>
        /// Download compressed/processed image as byte array.
        /// </summary>
        /// <param name="downloadUrl">URL from compression/conversion result</param>
        /// <returns>Image data as byte array</returns>
        public async Task<byte[]> DownloadAsync(string downloadUrl)
        {
            var response = await _httpClient.GetAsync(downloadUrl);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsByteArrayAsync();
        }

        /// <summary>
        /// Download compressed/processed image as stream.
        /// </summary>
        /// <param name="downloadUrl">URL from compression/conversion result</param>
        /// <returns>Stream containing the image data</returns>
        public async Task<Stream> DownloadAsStreamAsync(string downloadUrl)
        {
            var response = await _httpClient.GetAsync(downloadUrl);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsStreamAsync();
        }

        /// <summary>
        /// Download and save compressed/processed image to file.
        /// </summary>
        /// <param name="downloadUrl">URL from compression/conversion result</param>
        /// <param name="outputPath">Path where the file should be saved</param>
        public async Task DownloadToFileAsync(string downloadUrl, string outputPath)
        {
            var bytes = await DownloadAsync(downloadUrl);
            await File.WriteAllBytesAsync(outputPath, bytes);
        }

        #endregion

        #region Usage/Limits

        /// <summary>
        /// Get current API usage and remaining limits.
        /// </summary>
        /// <returns>Usage information</returns>
        public async Task<UsageResponse> GetUsageAsync()
        {
            var response = await _httpClient.GetAsync($"{ApiEndpoint}/usage");
            return await HandleResponseAsync<UsageResponse>(response);
        }

        #endregion

        #region Private Helpers

        private async Task<T> HandleResponseAsync<T>(HttpResponseMessage response) where T : MicroJpegResponse
        {
            var content = await response.Content.ReadAsStringAsync();

            // Try to extract compression count from header
            if (response.Headers.TryGetValues("X-Compression-Count", out var countValues))
            {
                if (int.TryParse(countValues.FirstOrDefault(), out var count))
                {
                    CompressionCount = count;
                }
            }

            if (!response.IsSuccessStatusCode)
            {
                MicroJpegError? error = null;
                try
                {
                    error = JsonSerializer.Deserialize<MicroJpegError>(content, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });
                }
                catch { }

                throw new MicroJpegApiException(
                    (int)response.StatusCode,
                    response.ReasonPhrase ?? "Unknown error",
                    error?.Error ?? "api_error",
                    error?.Message ?? content
                );
            }

            var result = JsonSerializer.Deserialize<T>(content, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            });

            if (result == null)
                throw new MicroJpegApiException(500, "Invalid response", "parse_error", "Could not parse API response");

            result.CompressionCount = CompressionCount;
            return result;
        }

        private static string GetMimeType(string fileName)
        {
            var ext = Path.GetExtension(fileName).ToLowerInvariant();
            return ext switch
            {
                ".jpg" or ".jpeg" => "image/jpeg",
                ".png" => "image/png",
                ".webp" => "image/webp",
                ".avif" => "image/avif",
                ".gif" => "image/gif",
                ".bmp" => "image/bmp",
                ".tiff" or ".tif" => "image/tiff",
                ".svg" => "image/svg+xml",
                ".cr2" => "image/x-canon-cr2",
                ".nef" => "image/x-nikon-nef",
                ".arw" => "image/x-sony-arw",
                ".dng" => "image/x-adobe-dng",
                _ => "application/octet-stream"
            };
        }

        #endregion

        #region IDisposable

        public void Dispose()
        {
            if (_disposeHttpClient)
            {
                _httpClient?.Dispose();
            }
        }

        #endregion
    }
}
