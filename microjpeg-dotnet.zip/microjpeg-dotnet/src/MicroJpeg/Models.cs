using System;
using System.Text.Json.Serialization;

namespace MicroJpeg
{
    #region Base Classes

    /// <summary>
    /// Base class for all MicroJPEG API responses
    /// </summary>
    public abstract class MicroJpegResponse
    {
        /// <summary>
        /// Whether the operation was successful
        /// </summary>
        [JsonPropertyName("success")]
        public bool Success { get; set; }

        /// <summary>
        /// Number of compressions performed (from response header)
        /// </summary>
        [JsonIgnore]
        public int CompressionCount { get; internal set; }
    }

    /// <summary>
    /// Error response from the API
    /// </summary>
    public class MicroJpegError
    {
        [JsonPropertyName("error")]
        public string? Error { get; set; }

        [JsonPropertyName("message")]
        public string? Message { get; set; }
    }

    #endregion

    #region Compress Models

    /// <summary>
    /// Options for image compression
    /// </summary>
    public class CompressOptions
    {
        /// <summary>
        /// Compression quality (1-100). Default: 85
        /// </summary>
        public int Quality { get; set; } = 85;

        /// <summary>
        /// Output format: "jpeg", "png", "webp", "avif", or "keep-original"
        /// </summary>
        public string? OutputFormat { get; set; }

        /// <summary>
        /// Resize width in pixels (optional)
        /// </summary>
        public int? ResizeWidth { get; set; }

        /// <summary>
        /// Resize height in pixels (optional)
        /// </summary>
        public int? ResizeHeight { get; set; }

        /// <summary>
        /// Resize mode when both width and height are specified
        /// </summary>
        public ResizeMode? ResizeMode { get; set; }
    }

    /// <summary>
    /// Resize mode options
    /// </summary>
    public enum ResizeMode
    {
        /// <summary>
        /// Scale down to fit within dimensions, maintaining aspect ratio
        /// </summary>
        Fit,

        /// <summary>
        /// Scale and crop to cover dimensions
        /// </summary>
        Cover,

        /// <summary>
        /// Scale to exact width, height auto-calculated
        /// </summary>
        ScaleWidth,

        /// <summary>
        /// Scale to exact height, width auto-calculated
        /// </summary>
        ScaleHeight,

        /// <summary>
        /// Scale to thumbnail size
        /// </summary>
        Thumb
    }

    /// <summary>
    /// Response from compression operation
    /// </summary>
    public class CompressResponse : MicroJpegResponse
    {
        [JsonPropertyName("result")]
        public CompressResult? Result { get; set; }

        [JsonPropertyName("input")]
        public ImageInfo? Input { get; set; }

        [JsonPropertyName("output")]
        public ImageInfo? Output { get; set; }
    }

    /// <summary>
    /// Compression result details
    /// </summary>
    public class CompressResult
    {
        [JsonPropertyName("id")]
        public string? Id { get; set; }

        [JsonPropertyName("originalName")]
        public string? OriginalName { get; set; }

        [JsonPropertyName("originalSize")]
        public long OriginalSize { get; set; }

        [JsonPropertyName("compressedSize")]
        public long CompressedSize { get; set; }

        [JsonPropertyName("compressionRatio")]
        public double CompressionRatio { get; set; }

        [JsonPropertyName("downloadUrl")]
        public string? DownloadUrl { get; set; }

        [JsonPropertyName("originalFormat")]
        public string? OriginalFormat { get; set; }

        [JsonPropertyName("outputFormat")]
        public string? OutputFormat { get; set; }

        [JsonPropertyName("wasConverted")]
        public bool WasConverted { get; set; }

        /// <summary>
        /// Savings percentage (e.g., 65.5 means 65.5% smaller)
        /// </summary>
        public double SavingsPercent => OriginalSize > 0 
            ? Math.Round((1 - (double)CompressedSize / OriginalSize) * 100, 1) 
            : 0;
    }

    /// <summary>
    /// Image size and dimension information
    /// </summary>
    public class ImageInfo
    {
        [JsonPropertyName("size")]
        public long Size { get; set; }

        [JsonPropertyName("width")]
        public int Width { get; set; }

        [JsonPropertyName("height")]
        public int Height { get; set; }

        [JsonPropertyName("type")]
        public string? Type { get; set; }

        [JsonPropertyName("url")]
        public string? Url { get; set; }
    }

    #endregion

    #region Convert Models

    /// <summary>
    /// Response from format conversion operation
    /// </summary>
    public class ConvertResponse : MicroJpegResponse
    {
        [JsonPropertyName("result")]
        public ConvertResult? Result { get; set; }
    }

    /// <summary>
    /// Conversion result details
    /// </summary>
    public class ConvertResult
    {
        [JsonPropertyName("id")]
        public string? Id { get; set; }

        [JsonPropertyName("originalName")]
        public string? OriginalName { get; set; }

        [JsonPropertyName("originalSize")]
        public long OriginalSize { get; set; }

        [JsonPropertyName("convertedSize")]
        public long ConvertedSize { get; set; }

        [JsonPropertyName("downloadUrl")]
        public string? DownloadUrl { get; set; }

        [JsonPropertyName("originalFormat")]
        public string? OriginalFormat { get; set; }

        [JsonPropertyName("outputFormat")]
        public string? OutputFormat { get; set; }
    }

    #endregion

    #region Background Removal Models

    /// <summary>
    /// Options for background removal
    /// </summary>
    public class BackgroundRemovalOptions
    {
        /// <summary>
        /// Output format: "png", "webp", "avif", "jpg". Default: "png"
        /// </summary>
        public string OutputFormat { get; set; } = "png";

        /// <summary>
        /// Quality for lossy formats (1-100). Default: 90
        /// </summary>
        public int Quality { get; set; } = 90;
    }

    /// <summary>
    /// Response from background removal operation
    /// </summary>
    public class BackgroundRemovalResponse : MicroJpegResponse
    {
        [JsonPropertyName("result")]
        public BackgroundRemovalResult? Result { get; set; }
    }

    /// <summary>
    /// Background removal result details
    /// </summary>
    public class BackgroundRemovalResult
    {
        [JsonPropertyName("id")]
        public string? Id { get; set; }

        [JsonPropertyName("originalName")]
        public string? OriginalName { get; set; }

        [JsonPropertyName("originalSize")]
        public long OriginalSize { get; set; }

        [JsonPropertyName("processedSize")]
        public long ProcessedSize { get; set; }

        [JsonPropertyName("format")]
        public string? Format { get; set; }

        [JsonPropertyName("processingTime")]
        public double ProcessingTime { get; set; }

        [JsonPropertyName("downloadUrl")]
        public string? DownloadUrl { get; set; }
    }

    #endregion

    #region Enhancement Models

    /// <summary>
    /// Options for image enhancement/upscaling
    /// </summary>
    public class EnhanceOptions
    {
        /// <summary>
        /// Upscale factor: 2, 4, or 8. Default: 2
        /// </summary>
        public int Scale { get; set; } = 2;

        /// <summary>
        /// Whether to enhance faces. Default: false
        /// </summary>
        public bool FaceEnhance { get; set; } = false;

        /// <summary>
        /// Output format: "png", "webp", "avif", "jpg". Default: "png"
        /// </summary>
        public string OutputFormat { get; set; } = "png";

        /// <summary>
        /// Quality for lossy formats (1-100). Default: 90
        /// </summary>
        public int Quality { get; set; } = 90;
    }

    /// <summary>
    /// Response from image enhancement operation
    /// </summary>
    public class EnhanceResponse : MicroJpegResponse
    {
        [JsonPropertyName("result")]
        public EnhanceResult? Result { get; set; }
    }

    /// <summary>
    /// Enhancement result details
    /// </summary>
    public class EnhanceResult
    {
        [JsonPropertyName("id")]
        public string? Id { get; set; }

        [JsonPropertyName("originalName")]
        public string? OriginalName { get; set; }

        [JsonPropertyName("originalSize")]
        public long OriginalSize { get; set; }

        [JsonPropertyName("enhancedSize")]
        public long EnhancedSize { get; set; }

        [JsonPropertyName("downloadUrl")]
        public string? DownloadUrl { get; set; }

        [JsonPropertyName("scale")]
        public int Scale { get; set; }

        [JsonPropertyName("originalDimensions")]
        public Dimensions? OriginalDimensions { get; set; }

        [JsonPropertyName("newDimensions")]
        public Dimensions? NewDimensions { get; set; }

        [JsonPropertyName("processingTime")]
        public double ProcessingTime { get; set; }
    }

    /// <summary>
    /// Image dimensions
    /// </summary>
    public class Dimensions
    {
        [JsonPropertyName("width")]
        public int Width { get; set; }

        [JsonPropertyName("height")]
        public int Height { get; set; }
    }

    #endregion

    #region Usage Models

    /// <summary>
    /// Response from usage/limits endpoint
    /// </summary>
    public class UsageResponse : MicroJpegResponse
    {
        [JsonPropertyName("tier")]
        public string? Tier { get; set; }

        [JsonPropertyName("usage")]
        public UsageDetails? Usage { get; set; }

        [JsonPropertyName("limits")]
        public LimitsDetails? Limits { get; set; }
    }

    /// <summary>
    /// Current usage details
    /// </summary>
    public class UsageDetails
    {
        [JsonPropertyName("compressions")]
        public int Compressions { get; set; }

        [JsonPropertyName("conversions")]
        public int Conversions { get; set; }

        [JsonPropertyName("bgRemovals")]
        public int BackgroundRemovals { get; set; }

        [JsonPropertyName("enhancements")]
        public int Enhancements { get; set; }

        [JsonPropertyName("periodStart")]
        public DateTime PeriodStart { get; set; }

        [JsonPropertyName("periodEnd")]
        public DateTime PeriodEnd { get; set; }
    }

    /// <summary>
    /// Plan limits
    /// </summary>
    public class LimitsDetails
    {
        [JsonPropertyName("monthlyOperations")]
        public int MonthlyOperations { get; set; }

        [JsonPropertyName("maxFileSize")]
        public long MaxFileSize { get; set; }

        [JsonPropertyName("maxRawFileSize")]
        public long MaxRawFileSize { get; set; }

        [JsonPropertyName("bgRemovalLimit")]
        public int BackgroundRemovalLimit { get; set; }

        [JsonPropertyName("enhancementLimit")]
        public int EnhancementLimit { get; set; }
    }

    #endregion
}
