using System;

namespace MicroJpeg
{
    /// <summary>
    /// Exception thrown when the MicroJPEG API returns an error.
    /// </summary>
    public class MicroJpegApiException : Exception
    {
        /// <summary>
        /// HTTP status code from the API response
        /// </summary>
        public int StatusCode { get; }

        /// <summary>
        /// HTTP reason phrase from the API response
        /// </summary>
        public string ReasonPhrase { get; }

        /// <summary>
        /// Error code from the API (e.g., "limit_reached", "invalid_file", etc.)
        /// </summary>
        public string ErrorCode { get; }

        /// <summary>
        /// Detailed error message from the API
        /// </summary>
        public string ErrorMessage { get; }

        /// <summary>
        /// Creates a new MicroJpegApiException
        /// </summary>
        public MicroJpegApiException(int statusCode, string reasonPhrase, string errorCode, string errorMessage)
            : base($"MicroJPEG API error: {errorMessage} (HTTP {statusCode} {reasonPhrase}, Code: {errorCode})")
        {
            StatusCode = statusCode;
            ReasonPhrase = reasonPhrase;
            ErrorCode = errorCode;
            ErrorMessage = errorMessage;
        }

        /// <summary>
        /// Returns true if this error indicates the monthly limit has been reached
        /// </summary>
        public bool IsLimitReached => ErrorCode == "limit_reached";

        /// <summary>
        /// Returns true if this error indicates an invalid API key
        /// </summary>
        public bool IsUnauthorized => StatusCode == 401;

        /// <summary>
        /// Returns true if this error indicates a file size limit exceeded
        /// </summary>
        public bool IsFileTooLarge => ErrorCode == "file_too_large";

        /// <summary>
        /// Returns true if this error indicates an unsupported file format
        /// </summary>
        public bool IsUnsupportedFormat => ErrorCode == "unsupported_format";

        /// <summary>
        /// Returns true if this error indicates a feature requires upgrade
        /// </summary>
        public bool IsFeatureRestricted => ErrorCode == "feature_restricted" || ErrorCode == "format_restricted";
    }
}
