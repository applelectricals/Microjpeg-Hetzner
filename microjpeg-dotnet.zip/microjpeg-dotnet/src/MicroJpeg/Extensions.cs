using System;
using System.IO;
using System.Threading.Tasks;

namespace MicroJpeg
{
    /// <summary>
    /// Extension methods for fluent API chaining (similar to TinyPNG style)
    /// </summary>
    public static class MicroJpegExtensions
    {
        #region Task Extensions for Compress

        /// <summary>
        /// Download the compressed image as byte array.
        /// </summary>
        public static async Task<byte[]> GetImageByteDataAsync(this Task<CompressResponse> compressTask, MicroJpegClient client)
        {
            var result = await compressTask;
            if (result.Result?.DownloadUrl == null)
                throw new InvalidOperationException("No download URL available");
            
            return await client.DownloadAsync(result.Result.DownloadUrl);
        }

        /// <summary>
        /// Download the compressed image as stream.
        /// </summary>
        public static async Task<Stream> GetImageStreamDataAsync(this Task<CompressResponse> compressTask, MicroJpegClient client)
        {
            var result = await compressTask;
            if (result.Result?.DownloadUrl == null)
                throw new InvalidOperationException("No download URL available");
            
            return await client.DownloadAsStreamAsync(result.Result.DownloadUrl);
        }

        /// <summary>
        /// Download and save the compressed image to disk.
        /// </summary>
        public static async Task SaveImageToDiskAsync(this Task<CompressResponse> compressTask, MicroJpegClient client, string outputPath)
        {
            var result = await compressTask;
            if (result.Result?.DownloadUrl == null)
                throw new InvalidOperationException("No download URL available");
            
            await client.DownloadToFileAsync(result.Result.DownloadUrl, outputPath);
        }

        #endregion

        #region Task Extensions for Convert

        /// <summary>
        /// Download the converted image as byte array.
        /// </summary>
        public static async Task<byte[]> GetImageByteDataAsync(this Task<ConvertResponse> convertTask, MicroJpegClient client)
        {
            var result = await convertTask;
            if (result.Result?.DownloadUrl == null)
                throw new InvalidOperationException("No download URL available");
            
            return await client.DownloadAsync(result.Result.DownloadUrl);
        }

        /// <summary>
        /// Download the converted image as stream.
        /// </summary>
        public static async Task<Stream> GetImageStreamDataAsync(this Task<ConvertResponse> convertTask, MicroJpegClient client)
        {
            var result = await convertTask;
            if (result.Result?.DownloadUrl == null)
                throw new InvalidOperationException("No download URL available");
            
            return await client.DownloadAsStreamAsync(result.Result.DownloadUrl);
        }

        /// <summary>
        /// Download and save the converted image to disk.
        /// </summary>
        public static async Task SaveImageToDiskAsync(this Task<ConvertResponse> convertTask, MicroJpegClient client, string outputPath)
        {
            var result = await convertTask;
            if (result.Result?.DownloadUrl == null)
                throw new InvalidOperationException("No download URL available");
            
            await client.DownloadToFileAsync(result.Result.DownloadUrl, outputPath);
        }

        #endregion

        #region Task Extensions for Background Removal

        /// <summary>
        /// Download the background-removed image as byte array.
        /// </summary>
        public static async Task<byte[]> GetImageByteDataAsync(this Task<BackgroundRemovalResponse> bgRemovalTask, MicroJpegClient client)
        {
            var result = await bgRemovalTask;
            if (result.Result?.DownloadUrl == null)
                throw new InvalidOperationException("No download URL available");
            
            return await client.DownloadAsync(result.Result.DownloadUrl);
        }

        /// <summary>
        /// Download the background-removed image as stream.
        /// </summary>
        public static async Task<Stream> GetImageStreamDataAsync(this Task<BackgroundRemovalResponse> bgRemovalTask, MicroJpegClient client)
        {
            var result = await bgRemovalTask;
            if (result.Result?.DownloadUrl == null)
                throw new InvalidOperationException("No download URL available");
            
            return await client.DownloadAsStreamAsync(result.Result.DownloadUrl);
        }

        /// <summary>
        /// Download and save the background-removed image to disk.
        /// </summary>
        public static async Task SaveImageToDiskAsync(this Task<BackgroundRemovalResponse> bgRemovalTask, MicroJpegClient client, string outputPath)
        {
            var result = await bgRemovalTask;
            if (result.Result?.DownloadUrl == null)
                throw new InvalidOperationException("No download URL available");
            
            await client.DownloadToFileAsync(result.Result.DownloadUrl, outputPath);
        }

        #endregion

        #region Task Extensions for Enhancement

        /// <summary>
        /// Download the enhanced image as byte array.
        /// </summary>
        public static async Task<byte[]> GetImageByteDataAsync(this Task<EnhanceResponse> enhanceTask, MicroJpegClient client)
        {
            var result = await enhanceTask;
            if (result.Result?.DownloadUrl == null)
                throw new InvalidOperationException("No download URL available");
            
            return await client.DownloadAsync(result.Result.DownloadUrl);
        }

        /// <summary>
        /// Download the enhanced image as stream.
        /// </summary>
        public static async Task<Stream> GetImageStreamDataAsync(this Task<EnhanceResponse> enhanceTask, MicroJpegClient client)
        {
            var result = await enhanceTask;
            if (result.Result?.DownloadUrl == null)
                throw new InvalidOperationException("No download URL available");
            
            return await client.DownloadAsStreamAsync(result.Result.DownloadUrl);
        }

        /// <summary>
        /// Download and save the enhanced image to disk.
        /// </summary>
        public static async Task SaveImageToDiskAsync(this Task<EnhanceResponse> enhanceTask, MicroJpegClient client, string outputPath)
        {
            var result = await enhanceTask;
            if (result.Result?.DownloadUrl == null)
                throw new InvalidOperationException("No download URL available");
            
            await client.DownloadToFileAsync(result.Result.DownloadUrl, outputPath);
        }

        #endregion

        #region Response Extensions

        /// <summary>
        /// Download the compressed image as byte array.
        /// </summary>
        public static async Task<byte[]> GetImageByteDataAsync(this CompressResponse response, MicroJpegClient client)
        {
            if (response.Result?.DownloadUrl == null)
                throw new InvalidOperationException("No download URL available");
            
            return await client.DownloadAsync(response.Result.DownloadUrl);
        }

        /// <summary>
        /// Download the compressed image as stream.
        /// </summary>
        public static async Task<Stream> GetImageStreamDataAsync(this CompressResponse response, MicroJpegClient client)
        {
            if (response.Result?.DownloadUrl == null)
                throw new InvalidOperationException("No download URL available");
            
            return await client.DownloadAsStreamAsync(response.Result.DownloadUrl);
        }

        /// <summary>
        /// Save the compressed image to disk.
        /// </summary>
        public static async Task SaveImageToDiskAsync(this CompressResponse response, MicroJpegClient client, string outputPath)
        {
            if (response.Result?.DownloadUrl == null)
                throw new InvalidOperationException("No download URL available");
            
            await client.DownloadToFileAsync(response.Result.DownloadUrl, outputPath);
        }

        #endregion
    }
}
