<?php
/**
 * @package     MicroJpeg.Plugin
 * @subpackage  JShoppingProducts.MicroJpeg
 *
 * @copyright   Copyright (C) 2025 MicroJPEG. All rights reserved.
 * @license     GNU General Public License version 3 or later
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Log\Log;

/**
 * Installation script for MicroJPEG JoomShopping plugin
 */
class plgJshoppingproductsMicrojpegInstallerScript
{
    /**
     * Minimum PHP version required
     *
     * @var string
     */
    protected $minimumPhp = '8.0';

    /**
     * Minimum Joomla version required
     *
     * @var string
     */
    protected $minimumJoomla = '4.0';

    /**
     * Function called before extension installation/update/removal
     *
     * @param   string            $type    The type of change (install, update, discover_install, uninstall)
     * @param   InstallerAdapter  $parent  The class calling this method
     *
     * @return  boolean  True to continue, false to abort
     */
    public function preflight($type, $parent)
    {
        // Check PHP version
        if (version_compare(PHP_VERSION, $this->minimumPhp, '<')) {
            Factory::getApplication()->enqueueMessage(
                sprintf('MicroJPEG requires PHP %s or higher. You are running PHP %s.', $this->minimumPhp, PHP_VERSION),
                'error'
            );
            return false;
        }

        // Check Joomla version
        if (version_compare(JVERSION, $this->minimumJoomla, '<')) {
            Factory::getApplication()->enqueueMessage(
                sprintf('MicroJPEG requires Joomla %s or higher. You are running Joomla %s.', $this->minimumJoomla, JVERSION),
                'error'
            );
            return false;
        }

        // Check if cURL is available
        if (!function_exists('curl_init')) {
            Factory::getApplication()->enqueueMessage(
                'MicroJPEG requires the PHP cURL extension to be enabled.',
                'error'
            );
            return false;
        }

        // Check if JoomShopping is installed
        if (!file_exists(JPATH_ADMINISTRATOR . '/components/com_jshopping/jshopping.php')) {
            Factory::getApplication()->enqueueMessage(
                'MicroJPEG requires JoomShopping to be installed.',
                'error'
            );
            return false;
        }

        return true;
    }

    /**
     * Function called after extension installation/update/removal
     *
     * @param   string            $type    The type of change (install, update, discover_install, uninstall)
     * @param   InstallerAdapter  $parent  The class calling this method
     *
     * @return  boolean
     */
    public function postflight($type, $parent)
    {
        if ($type === 'install' || $type === 'discover_install') {
            $this->showInstallMessage();
        }

        if ($type === 'update') {
            $this->showUpdateMessage();
        }

        return true;
    }

    /**
     * Show installation success message
     *
     * @return  void
     */
    private function showInstallMessage()
    {
        $html = '
        <div style="background: linear-gradient(135deg, #0d9488 0%, #14b8a6 100%); padding: 30px; border-radius: 12px; color: white; margin: 20px 0;">
            <div style="display: flex; align-items: center; gap: 20px;">
                <div style="font-size: 48px;">🖼️</div>
                <div>
                    <h2 style="margin: 0 0 10px 0; font-size: 24px;">MicroJPEG Image Optimizer Installed!</h2>
                    <p style="margin: 0; opacity: 0.9;">Thank you for installing MicroJPEG for JoomShopping.</p>
                </div>
            </div>
            
            <div style="margin-top: 20px; padding: 15px; background: rgba(255,255,255,0.1); border-radius: 8px;">
                <h3 style="margin: 0 0 10px 0; font-size: 16px;">🚀 Quick Setup:</h3>
                <ol style="margin: 0; padding-left: 20px; line-height: 1.8;">
                    <li>Go to <strong>System → Plugins</strong> and enable "MicroJPEG Image Optimizer"</li>
                    <li>Get your free API key at <a href="https://microjpeg.com/api-dashboard" target="_blank" style="color: #fef3c7;">microjpeg.com/api-dashboard</a></li>
                    <li>Enter your API key in the plugin settings</li>
                    <li>Start saving products - images will be optimized automatically!</li>
                </ol>
            </div>
            
            <div style="margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                <a href="https://microjpeg.com/api-dashboard" target="_blank" 
                   style="display: inline-block; padding: 10px 20px; background: white; color: #0d9488; border-radius: 6px; text-decoration: none; font-weight: bold;">
                    Get API Key →
                </a>
                <a href="https://microjpeg.com/api-docs" target="_blank"
                   style="display: inline-block; padding: 10px 20px; background: rgba(255,255,255,0.2); color: white; border-radius: 6px; text-decoration: none;">
                    Documentation
                </a>
            </div>
        </div>';

        echo $html;
    }

    /**
     * Show update success message
     *
     * @return  void
     */
    private function showUpdateMessage()
    {
        $html = '
        <div style="background: #059669; padding: 20px; border-radius: 8px; color: white; margin: 20px 0;">
            <h3 style="margin: 0;">✅ MicroJPEG Image Optimizer Updated Successfully!</h3>
            <p style="margin: 10px 0 0 0; opacity: 0.9;">Your plugin has been updated to the latest version.</p>
        </div>';

        echo $html;
    }

    /**
     * Method to run after uninstall
     *
     * @param   InstallerAdapter  $parent  The class calling this method
     *
     * @return  boolean
     */
    public function uninstall($parent)
    {
        // Clean up log file if exists
        $logFile = JPATH_ADMINISTRATOR . '/logs/plg_jshoppingproducts_microjpeg.log.php';
        if (file_exists($logFile)) {
            @unlink($logFile);
        }

        return true;
    }
}
