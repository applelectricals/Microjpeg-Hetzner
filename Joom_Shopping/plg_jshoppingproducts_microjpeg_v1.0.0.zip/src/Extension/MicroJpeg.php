<?php
/**
 * @package     MicroJpeg.Plugin
 * @subpackage  JShoppingProducts.MicroJpeg
 *
 * @copyright   Copyright (C) 2025 MicroJPEG. All rights reserved.
 * @license     GNU General Public License version 3 or later
 */

namespace MicroJpeg\Plugin\JShoppingProducts\MicroJpeg\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\DispatcherInterface;

/**
 * MicroJPEG Image Optimizer Plugin for JoomShopping
 *
 * Automatically optimizes uploaded images (products, categories, manufacturers)
 * in admin panel of JoomShopping for Joomla using the MicroJPEG API.
 */
class MicroJpeg extends CMSPlugin
{
    /**
     * Load the language file on instantiation.
     *
     * @var    boolean
     */
    protected $autoloadLanguage = true;

    /**
     * Application object
     *
     * @var    \Joomla\CMS\Application\CMSApplication
     */
    protected $app;

    /**
     * MicroJPEG API endpoint
     *
     * @var string
     */
    private const API_ENDPOINT = 'https://microjpeg.com/api/v1';

    /**
     * Total bytes saved in current session
     *
     * @var int
     */
    private static $bytesSaved = 0;

    /**
     * Number of images compressed in current session
     *
     * @var int
     */
    private static $imagesCompressed = 0;

    /**
     * Constructor
     *
     * @param   DispatcherInterface  $dispatcher  The object to observe
     * @param   array                $config      An optional associative array of configuration settings
     */
    public function __construct(DispatcherInterface $dispatcher, array $config = [])
    {
        parent::__construct($dispatcher, $config);

        // Set up logging
        if ($this->params->get('log_errors', 1)) {
            Log::addLogger(
                ['text_file' => 'plg_jshoppingproducts_microjpeg.log.php'],
                Log::ALL,
                ['plg_microjpeg']
            );
        }
    }

    /**
     * Event triggered after saving a product
     * Hook: onAfterSaveProduct (JoomShopping)
     *
     * @param   object  $product  The product object
     *
     * @return  void
     */
    public function onAfterSaveProduct(&$product)
    {
        if (!$this->params->get('compress_products', 1)) {
            return;
        }

        $this->processProductImages($product);
    }

    /**
     * Event triggered after saving a category
     * Hook: onAfterSaveCategory (JoomShopping)
     *
     * @param   object  $category  The category object
     *
     * @return  void
     */
    public function onAfterSaveCategory(&$category)
    {
        if (!$this->params->get('compress_categories', 1)) {
            return;
        }

        $this->processCategoryImage($category);
    }

    /**
     * Event triggered after saving a manufacturer
     * Hook: onAfterSaveManufacturer (JoomShopping)
     *
     * @param   object  $manufacturer  The manufacturer object
     *
     * @return  void
     */
    public function onAfterSaveManufacturer(&$manufacturer)
    {
        if (!$this->params->get('compress_manufacturers', 1)) {
            return;
        }

        $this->processManufacturerImage($manufacturer);
    }

    /**
     * Process product images
     *
     * @param   object  $product  The product object
     *
     * @return  void
     */
    private function processProductImages($product)
    {
        // Get JoomShopping configuration
        $jshopConfig = \JSFactory::getConfig();
        $imagePath = $jshopConfig->image_product_path;

        // Process main product images
        if (!empty($product->image)) {
            $images = is_array($product->image) ? $product->image : [$product->image];
            
            foreach ($images as $image) {
                if (empty($image)) {
                    continue;
                }

                // Full size image
                if ($this->params->get('compress_full', 1)) {
                    $fullPath = $imagePath . '/full_' . $image;
                    if (file_exists($fullPath)) {
                        $this->compressImage($fullPath);
                    }
                }

                // Thumbnail
                if ($this->params->get('compress_thumbnails', 1)) {
                    $thumbPath = $imagePath . '/thumb_' . $image;
                    if (file_exists($thumbPath)) {
                        $this->compressImage($thumbPath);
                    }
                }

                // Original/main image
                $mainPath = $imagePath . '/' . $image;
                if (file_exists($mainPath)) {
                    $this->compressImage($mainPath);
                }
            }
        }

        // Show statistics message
        $this->showStatsMessage();
    }

    /**
     * Process category image
     *
     * @param   object  $category  The category object
     *
     * @return  void
     */
    private function processCategoryImage($category)
    {
        $jshopConfig = \JSFactory::getConfig();
        $imagePath = $jshopConfig->image_category_path;

        if (!empty($category->category_image)) {
            $fullPath = $imagePath . '/' . $category->category_image;
            if (file_exists($fullPath)) {
                $this->compressImage($fullPath);
            }
        }

        $this->showStatsMessage();
    }

    /**
     * Process manufacturer image
     *
     * @param   object  $manufacturer  The manufacturer object
     *
     * @return  void
     */
    private function processManufacturerImage($manufacturer)
    {
        $jshopConfig = \JSFactory::getConfig();
        $imagePath = $jshopConfig->image_manufs_path;

        if (!empty($manufacturer->manufacturer_logo)) {
            $fullPath = $imagePath . '/' . $manufacturer->manufacturer_logo;
            if (file_exists($fullPath)) {
                $this->compressImage($fullPath);
            }
        }

        $this->showStatsMessage();
    }

    /**
     * Compress a single image using the MicroJPEG API
     *
     * @param   string  $filePath  Path to the image file
     *
     * @return  bool  True on success, false on failure
     */
    private function compressImage(string $filePath): bool
    {
        $apiKey = $this->params->get('api_key');

        if (empty($apiKey)) {
            $this->logError('API key is not configured');
            return false;
        }

        if (!file_exists($filePath)) {
            $this->logError('File not found: ' . $filePath);
            return false;
        }

        // Check if file is an image
        $imageInfo = @getimagesize($filePath);
        if ($imageInfo === false) {
            $this->logError('Not a valid image file: ' . $filePath);
            return false;
        }

        $originalSize = filesize($filePath);

        try {
            // Prepare the API request
            $url = self::API_ENDPOINT . '/compress';
            
            $postData = [
                'file' => new \CURLFile($filePath, $imageInfo['mime'], basename($filePath)),
                'settings' => json_encode([
                    'quality' => (int) $this->params->get('quality', 85),
                    'outputFormat' => $this->params->get('output_format', 'keep-original'),
                ])
            ];

            // Make the API request
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $url,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $postData,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 120,
                CURLOPT_HTTPHEADER => [
                    'Authorization: Bearer ' . $apiKey,
                    'Accept: application/json',
                ],
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);

            if ($error) {
                $this->logError('cURL error: ' . $error);
                return false;
            }

            if ($httpCode !== 200) {
                $this->logError('API error (HTTP ' . $httpCode . '): ' . $response);
                return false;
            }

            $result = json_decode($response, true);

            if (!isset($result['success']) || !$result['success']) {
                $errorMsg = $result['message'] ?? $result['error'] ?? 'Unknown error';
                $this->logError('API returned error: ' . $errorMsg);
                return false;
            }

            // Download the compressed image
            if (!empty($result['result']['downloadUrl'])) {
                $compressedImage = $this->downloadImage($result['result']['downloadUrl']);
                
                if ($compressedImage !== false) {
                    // Handle format conversion
                    $outputFormat = $this->params->get('output_format', 'keep-original');
                    $newFilePath = $filePath;
                    
                    if ($outputFormat !== 'keep-original' && isset($result['result']['outputFormat'])) {
                        // Update file extension if format changed
                        $newExt = $result['result']['outputFormat'];
                        $pathInfo = pathinfo($filePath);
                        $newFilePath = $pathInfo['dirname'] . '/' . $pathInfo['filename'] . '.' . $newExt;
                        
                        // Delete old file if extension changed
                        if ($newFilePath !== $filePath && file_exists($filePath)) {
                            unlink($filePath);
                        }
                    }
                    
                    // Save the compressed image
                    if (file_put_contents($newFilePath, $compressedImage) !== false) {
                        $newSize = strlen($compressedImage);
                        $saved = $originalSize - $newSize;
                        
                        self::$bytesSaved += $saved;
                        self::$imagesCompressed++;

                        $this->logInfo(sprintf(
                            'Compressed %s: %s → %s (saved %s, %.1f%%)',
                            basename($filePath),
                            $this->formatBytes($originalSize),
                            $this->formatBytes($newSize),
                            $this->formatBytes($saved),
                            ($saved / $originalSize) * 100
                        ));

                        return true;
                    }
                }
            }

            return false;

        } catch (\Exception $e) {
            $this->logError('Exception: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Download compressed image from MicroJPEG
     *
     * @param   string  $url  Download URL
     *
     * @return  string|false  Image data or false on failure
     */
    private function downloadImage(string $url)
    {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_FOLLOWLOCATION => true,
        ]);

        $data = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 200 && $data !== false) {
            return $data;
        }

        return false;
    }

    /**
     * Show statistics message in admin
     *
     * @return  void
     */
    private function showStatsMessage()
    {
        if (!$this->params->get('show_stats', 1)) {
            return;
        }

        if (self::$imagesCompressed > 0) {
            $message = Text::sprintf(
                'PLG_JSHOPPINGPRODUCTS_MICROJPEG_STATS_MESSAGE',
                self::$imagesCompressed,
                $this->formatBytes(self::$bytesSaved)
            );

            Factory::getApplication()->enqueueMessage($message, 'success');
        }
    }

    /**
     * Format bytes to human readable string
     *
     * @param   int  $bytes  Bytes to format
     *
     * @return  string
     */
    private function formatBytes(int $bytes): string
    {
        $units = ['B', 'KB', 'MB', 'GB'];
        $factor = floor((strlen($bytes) - 1) / 3);
        
        return sprintf('%.2f %s', $bytes / pow(1024, $factor), $units[$factor]);
    }

    /**
     * Log an error message
     *
     * @param   string  $message  Error message
     *
     * @return  void
     */
    private function logError(string $message)
    {
        if ($this->params->get('log_errors', 1)) {
            Log::add($message, Log::ERROR, 'plg_microjpeg');
        }
    }

    /**
     * Log an info message
     *
     * @param   string  $message  Info message
     *
     * @return  void
     */
    private function logInfo(string $message)
    {
        if ($this->params->get('log_errors', 1)) {
            Log::add($message, Log::INFO, 'plg_microjpeg');
        }
    }

    /**
     * Get API usage statistics
     *
     * @return  array|null
     */
    public function getApiUsage(): ?array
    {
        $apiKey = $this->params->get('api_key');

        if (empty($apiKey)) {
            return null;
        }

        try {
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => self::API_ENDPOINT . '/usage',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTPHEADER => [
                    'Authorization: Bearer ' . $apiKey,
                    'Accept: application/json',
                ],
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode === 200) {
                return json_decode($response, true);
            }

        } catch (\Exception $e) {
            // Silently fail for usage check
        }

        return null;
    }
}
