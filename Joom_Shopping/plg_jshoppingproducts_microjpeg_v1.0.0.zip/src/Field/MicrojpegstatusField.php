<?php
/**
 * @package     MicroJpeg.Plugin
 * @subpackage  JShoppingProducts.MicroJpeg
 *
 * @copyright   Copyright (C) 2025 MicroJPEG. All rights reserved.
 * @license     GNU General Public License version 3 or later
 */

namespace MicroJpeg\Plugin\JShoppingProducts\MicroJpeg\Field;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormField;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\PluginHelper;

/**
 * MicroJPEG API Status Field
 * Displays current API usage and account status
 */
class MicrojpegstatusField extends FormField
{
    /**
     * The form field type.
     *
     * @var    string
     */
    protected $type = 'Microjpegstatus';

    /**
     * Method to get the field input markup.
     *
     * @return  string  The field input markup.
     */
    protected function getInput()
    {
        $plugin = PluginHelper::getPlugin('jshoppingproducts', 'microjpeg');
        $params = new \Joomla\Registry\Registry($plugin->params ?? '{}');
        $apiKey = $params->get('api_key', '');

        if (empty($apiKey)) {
            return $this->renderNoApiKey();
        }

        // Get API usage
        $usage = $this->getApiUsage($apiKey);

        if ($usage === null) {
            return $this->renderApiError();
        }

        return $this->renderUsageStats($usage);
    }

    /**
     * Render "No API Key" message
     *
     * @return  string
     */
    private function renderNoApiKey(): string
    {
        return '
        <div class="alert alert-warning">
            <strong>' . Text::_('PLG_JSHOPPINGPRODUCTS_MICROJPEG_NO_API_KEY') . '</strong><br>
            ' . Text::_('PLG_JSHOPPINGPRODUCTS_MICROJPEG_GET_API_KEY') . '
            <a href="https://microjpeg.com/api-dashboard" target="_blank" class="btn btn-sm btn-primary ms-2">
                ' . Text::_('PLG_JSHOPPINGPRODUCTS_MICROJPEG_GET_KEY_BTN') . '
            </a>
        </div>';
    }

    /**
     * Render API error message
     *
     * @return  string
     */
    private function renderApiError(): string
    {
        return '
        <div class="alert alert-danger">
            <strong>' . Text::_('PLG_JSHOPPINGPRODUCTS_MICROJPEG_API_ERROR') . '</strong><br>
            ' . Text::_('PLG_JSHOPPINGPRODUCTS_MICROJPEG_CHECK_KEY') . '
        </div>';
    }

    /**
     * Render usage statistics
     *
     * @param   array  $usage  Usage data from API
     *
     * @return  string
     */
    private function renderUsageStats(array $usage): string
    {
        $tier = $usage['tier'] ?? 'Free';
        $compressions = $usage['usage']['compressions'] ?? 0;
        $bgRemovals = $usage['usage']['bgRemovals'] ?? 0;
        $enhancements = $usage['usage']['enhancements'] ?? 0;
        $limitOps = $usage['limits']['monthlyOperations'] ?? 30;
        $limitBg = $usage['limits']['bgRemovalLimit'] ?? 10;
        $limitEnh = $usage['limits']['enhancementLimit'] ?? 10;

        $opsPercent = $limitOps > 0 ? min(100, ($compressions / $limitOps) * 100) : 0;
        $bgPercent = $limitBg > 0 ? min(100, ($bgRemovals / $limitBg) * 100) : 0;
        $enhPercent = $limitEnh > 0 ? min(100, ($enhancements / $limitEnh) * 100) : 0;

        $tierBadgeClass = $tier === 'starter' || $tier === 'Starter' ? 'bg-success' : 'bg-secondary';
        $limitDisplay = $limitOps === -1 ? 'Unlimited' : $limitOps;

        $html = '
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <strong>' . Text::_('PLG_JSHOPPINGPRODUCTS_MICROJPEG_API_STATUS') . '</strong>
                <span class="badge ' . $tierBadgeClass . '">' . ucfirst($tier) . ' Plan</span>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <label class="form-label">' . Text::_('PLG_JSHOPPINGPRODUCTS_MICROJPEG_COMPRESSIONS') . '</label>
                    <div class="progress" style="height: 25px;">
                        <div class="progress-bar bg-info" role="progressbar" style="width: ' . $opsPercent . '%">
                            ' . $compressions . ' / ' . $limitDisplay . '
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-2">
                        <small class="text-muted">' . Text::_('PLG_JSHOPPINGPRODUCTS_MICROJPEG_BG_REMOVAL') . ':</small>
                        <div class="progress" style="height: 15px;">
                            <div class="progress-bar bg-warning" style="width: ' . $bgPercent . '%">
                                ' . $bgRemovals . ' / ' . $limitBg . '
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-2">
                        <small class="text-muted">' . Text::_('PLG_JSHOPPINGPRODUCTS_MICROJPEG_ENHANCEMENT') . ':</small>
                        <div class="progress" style="height: 15px;">
                            <div class="progress-bar bg-success" style="width: ' . $enhPercent . '%">
                                ' . $enhancements . ' / ' . $limitEnh . '
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer text-muted small">
                <a href="https://microjpeg.com/pricing" target="_blank">
                    ' . Text::_('PLG_JSHOPPINGPRODUCTS_MICROJPEG_UPGRADE') . '
                </a>
            </div>
        </div>';

        return $html;
    }

    /**
     * Get API usage from MicroJPEG
     *
     * @param   string  $apiKey  API key
     *
     * @return  array|null
     */
    private function getApiUsage(string $apiKey): ?array
    {
        try {
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => 'https://microjpeg.com/api/v1/usage',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 15,
                CURLOPT_HTTPHEADER => [
                    'Authorization: Bearer ' . $apiKey,
                    'Accept: application/json',
                ],
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode === 200 && $response) {
                $data = json_decode($response, true);
                if (isset($data['success']) && $data['success']) {
                    return $data;
                }
            }

        } catch (\Exception $e) {
            // Silently fail
        }

        return null;
    }
}
