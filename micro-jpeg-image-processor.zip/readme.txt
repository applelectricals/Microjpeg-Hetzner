=== Micro JPEG - Image Compression & AI Features ===
Contributors: microjpeg
Tags: image compression, optimize images, ai background removal, image enhancement, webp, avif, raw files
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 2.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Compress images automatically with AI-powered background removal and enhancement. Support for JPEG, PNG, WebP, AVIF, and RAW formats.

== Description ==

Micro JPEG is a powerful image optimization plugin that automatically compresses your images on upload while maintaining exceptional quality. Now with AI-powered features including background removal and image enhancement.

= Key Features =

* **Automatic Compression**: Images are compressed automatically when uploaded
* **AI Background Removal**: Remove backgrounds from images with one click
* **AI Image Enhancement**: Enhance and upscale images up to 8x
* **Multiple Formats**: Support for JPEG, PNG, WebP, AVIF, SVG, and TIFF
* **RAW File Support**: Convert and optimize RAW files (CR2, CR3, NEF, ARW, DNG, ORF, RAF, RW2, PEF)
* **Bulk Optimization**: Compress multiple images at once
* **Original Backups**: Keep original files for easy restoration
* **Quality Control**: Adjust compression quality to your needs
* **Format Conversion**: Convert images to modern formats like WebP and AVIF
* **WordPress Integration**: Seamlessly integrates with WordPress media library

= AI Features =

**Background Removal**
* Remove backgrounds from product photos
* Create transparent PNGs
* Multiple output formats (PNG, JPG, WebP)
* Batch processing support

**Image Enhancement**
* AI-powered noise reduction
* Automatic color correction
* Smart sharpening
* Upscale up to 8x resolution

= Subscription Tiers =

**Free**
* 7MB regular images
* 15MB RAW files
* 200 operations/month
* 5 BG removals/month
* 3 enhancements/month
* 2x upscale

**Starter ($9/month)**
* 75MB files
* Unlimited operations
* 200 BG removals/month
* 200 enhancements/month
* 8x upscale

**Pro ($19/month)**
* 150MB files
* Unlimited operations
* 500 BG removals/month
* 500 enhancements/month
* 8x upscale

**Business ($49/month)**
* 200MB files
* Unlimited operations
* 1,000 BG removals/month
* 1,000 enhancements/month
* 8x upscale
* Priority support

= Why Choose Micro JPEG? =

* **Better Compression**: Uses advanced algorithms for superior compression
* **Faster Loading**: Reduce image file sizes by up to 70%
* **SEO Friendly**: Faster page loads improve search rankings
* **Save Bandwidth**: Reduce hosting costs with smaller file sizes
* **Easy to Use**: Set it and forget it - automatic compression
* **Safe**: Keep original files as backups

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/micro-jpeg` directory, or install through WordPress plugins screen
2. Activate the plugin through 'Plugins' screen in WordPress
3. Go to Micro JPEG > Settings to configure your API key
4. Get your API key from https://microjpeg.com
5. Configure compression settings to your preference
6. Done! Images will now be compressed automatically on upload

== Frequently Asked Questions ==

= Do I need an API key? =

Yes, you need a free API key from https://microjpeg.com to use this plugin.

= Will this work with existing images? =

Yes! Use the Bulk Compress feature to optimize images that were uploaded before installing the plugin.

= Can I restore original images? =

Yes, if you have "Keep Originals" enabled in settings, you can restore any compressed image to its original version.

= What image formats are supported? =

Regular images: JPEG, PNG, WebP, AVIF, SVG, TIFF
RAW formats: CR2, CR3, NEF, ARW, DNG, ORF, RAF, RW2, PEF

= How much can I save? =

Typically 40-70% reduction in file size while maintaining visual quality. Results vary by image type and content.

= Does this work with page builders? =

Yes! The plugin works with all page builders including Elementor, Beaver Builder, Divi, and WPBakery.

= Are there any file size limits? =

Limits depend on your subscription tier:
* Free: 7MB regular, 15MB RAW
* Starter: 75MB
* Pro: 150MB
* Business: 200MB

= How does AI background removal work? =

Our AI analyzes the image and intelligently separates the foreground from the background, creating a clean transparent background.

= Can I upscale images? =

Yes! With AI enhancement, you can upscale images up to 8x their original resolution (depending on your plan).

== Screenshots ==

1. Dashboard showing compression statistics
2. Settings page with compression options
3. Bulk compress interface
4. AI features in media library
5. Before and after comparison
6. Subscription plans

== Changelog ==

= 2.2.0 =
* Added AI Background Removal feature
* Added AI Image Enhancement with upscaling
* Added tier-based limits for AI features
* Improved bulk processing performance
* Enhanced media library integration
* Updated subscription management

= 2.1.0 =
* Added RAW file support
* Added format conversion options
* Improved compression algorithm
* Better error handling
* UI improvements

= 2.0.0 =
* Major update with new dashboard
* Added bulk compression
* Added subscription management
* Improved API integration
* Performance optimizations

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 2.2.0 =
Major update with AI features! Get AI-powered background removal and image enhancement.

== Additional Info ==

For support, visit https://microjpeg.com/support
View documentation at https://microjpeg.com/docs
API documentation at https://microjpeg.com/api-docs

Privacy: This plugin sends images to Micro JPEG's secure servers for processing. No images are stored permanently on our servers. See our privacy policy at https://microjpeg.com/privacy