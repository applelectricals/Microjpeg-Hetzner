<?php
/**
 * Settings Class
 *
 * @package MicroJPEG
 */

if (!defined('ABSPATH')) {
    exit;
}

class Micro_JPEG_Settings {
    
    private $api;
    
    public function __construct($api) {
        $this->api = $api;
    }
    
    /**
     * Initialize hooks
     */
    public function init() {
        add_action('admin_menu', array($this, 'add_menu_pages'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
    }
    
    /**
     * Add admin menu pages
     */
    public function add_menu_pages() {
        add_menu_page(
            'MicroJPEG',
            'MicroJPEG',
            'manage_options',
            'micro-jpeg',
            array($this, 'render_dashboard'),
            'dashicons-images-alt2',
            65
        );
        
        add_submenu_page(
            'micro-jpeg',
            'Settings',
            'Settings',
            'manage_options',
            'micro-jpeg-settings',
            array($this, 'render_settings')
        );
        
        add_submenu_page(
            'micro-jpeg',
            'Bulk Compress',
            'Bulk Compress',
            'manage_options',
            'micro-jpeg-bulk',
            array($this, 'render_bulk_compress')
        );
        
        add_submenu_page(
            'micro-jpeg',
            'Subscription',
            'Subscription',
            'manage_options',
            'micro-jpeg-subscription',
            array($this, 'render_subscription')
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('micro_jpeg_settings', 'micro_jpeg_api_key');
        register_setting('micro_jpeg_settings', 'micro_jpeg_auto_compress');
        register_setting('micro_jpeg_settings', 'micro_jpeg_quality');
        register_setting('micro_jpeg_settings', 'micro_jpeg_backup_originals');
        register_setting('micro_jpeg_settings', 'micro_jpeg_subscription_tier');
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueue_assets($hook) {
        if (strpos($hook, 'micro-jpeg') === false) {
            return;
        }
        
        wp_enqueue_style(
            'micro-jpeg-admin',
            MICRO_JPEG_URL . 'assets/css/admin.css',
            array(),
            MICRO_JPEG_VERSION
        );
        
        wp_enqueue_script(
            'micro-jpeg-admin',
            MICRO_JPEG_URL . 'assets/js/admin.js',
            array('jquery'),
            MICRO_JPEG_VERSION,
            true
        );
        
        wp_localize_script('micro-jpeg-admin', 'microJpegData', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('micro_jpeg_nonce')
        ));
    }
    
    /**
     * Render dashboard page
     */
    public function render_dashboard() {
        $stats = $this->get_statistics();
        $subscription = $this->get_subscription_tier();
        $limits = $this->get_subscription_limits($subscription);
        
        include MICRO_JPEG_PATH . 'admin/dashboard.php';
    }
    
    /**
     * Render settings page
     */
    public function render_settings() {
        include MICRO_JPEG_PATH . 'admin/settings.php';
    }
    
    /**
     * Render bulk compress page
     */
    public function render_bulk_compress() {
        include MICRO_JPEG_PATH . 'admin/bulk-compress.php';
    }
    
    /**
     * Render subscription page
     */
    public function render_subscription() {
        $subscription = $this->get_subscription_tier();
        $limits = $this->get_subscription_limits($subscription);
        $plans = $this->get_subscription_plans();
        
        include MICRO_JPEG_PATH . 'admin/subscription.php';
    }
    
    /**
     * Get subscription tier
     */
    public function get_subscription_tier() {
        return get_option('micro_jpeg_subscription_tier', 'free');
    }
    
    /**
     * Get subscription limits based on tier
     */
    public function get_subscription_limits($tier) {
        $limits = array(
            'free' => array(
                'name' => 'Free',
                'regular_images' => '7MB',
                'raw_files' => '15MB',
                'operations' => '200/month',
                'price' => '$0'
            ),
            'starter' => array(
                'name' => 'Starter',
                'regular_images' => '75MB',
                'raw_files' => '75MB',
                'operations' => 'Unlimited',
                'price' => '$9/month'
            ),
            'pro' => array(
                'name' => 'Pro',
                'regular_images' => '150MB',
                'raw_files' => '150MB',
                'operations' => 'Unlimited',
                'price' => '$19/month'
            ),
            'business' => array(
                'name' => 'Business',
                'regular_images' => '200MB',
                'raw_files' => '200MB',
                'operations' => 'Unlimited',
                'price' => '$49/month'
            )
        );
        
        return isset($limits[$tier]) ? $limits[$tier] : $limits['free'];
    }
    
    /**
     * Get all subscription plans
     */
    public function get_subscription_plans() {
        return array(
            'free' => array(
                'name' => 'Free',
                'price' => 0,
                'regular_limit' => '7MB',
                'raw_limit' => '15MB',
                'operations' => '200 operations/month',
                'features' => array(
                    'Basic compression',
                    '7MB regular images',
                    '15MB RAW files',
                    '200 operations per month'
                )
            ),
            'starter' => array(
                'name' => 'Starter',
                'price' => 9,
                'regular_limit' => '75MB',
                'raw_limit' => '75MB',
                'operations' => 'Unlimited operations',
                'features' => array(
                    'All Free features',
                    '75MB regular images',
                    '75MB RAW files',
                    'Unlimited operations',
                    'Priority support'
                )
            ),
            'pro' => array(
                'name' => 'Pro',
                'price' => 19,
                'regular_limit' => '150MB',
                'raw_limit' => '150MB',
                'operations' => 'Unlimited operations',
                'features' => array(
                    'All Starter features',
                    '150MB regular images',
                    '150MB RAW files',
                    'Unlimited operations',
                    'Advanced optimization',
                    'Bulk processing'
                ),
                'popular' => true
            ),
            'business' => array(
                'name' => 'Business',
                'price' => 49,
                'regular_limit' => '200MB',
                'raw_limit' => '200MB',
                'operations' => 'Unlimited operations',
                'features' => array(
                    'All Pro features',
                    '200MB regular images',
                    '200MB RAW files',
                    'Unlimited operations',
                    'API access',
                    'Custom integration',
                    'Dedicated support'
                )
            )
        );
    }
    
    /**
     * Get statistics
     */
    public function get_statistics() {
        global $wpdb;
        
        $compressed_images = $wpdb->get_var("
            SELECT COUNT(*) FROM {$wpdb->postmeta} 
            WHERE meta_key = '_micro_jpeg_compressed' AND meta_value = 'yes'
        ");
        
        $total_savings = $wpdb->get_var("
            SELECT SUM(meta_value) FROM {$wpdb->postmeta} 
            WHERE meta_key = '_micro_jpeg_savings'
        ");
        
        $current_month = date('Y-m');
        $operations_count = get_option('micro_jpeg_operations_' . $current_month, 0);
        
        return array(
            'compressed_images' => (int)$compressed_images,
            'total_savings' => $this->format_bytes((int)$total_savings),
            'operations_count' => (int)$operations_count,
            'operations_limit' => $this->get_operations_limit()
        );
    }
    
    /**
     * Get operations limit for current tier
     */
    private function get_operations_limit() {
        $tier = $this->get_subscription_tier();
        return $tier === 'free' ? 200 : 'Unlimited';
    }
    
    /**
     * Format bytes to human readable format
     */
    private function format_bytes($bytes) {
        if ($bytes < 1024) {
            return $bytes . ' B';
        } elseif ($bytes < 1048576) {
            return round($bytes / 1024, 2) . ' KB';
        } elseif ($bytes < 1073741824) {
            return round($bytes / 1048576, 2) . ' MB';
        } else {
            return round($bytes / 1073741824, 2) . ' GB';
        }
    }
    
    /**
     * Validate API key
     */
    public function validate_api_key($api_key) {
        return $this->api->validate_api_key($api_key);
    }
    
    /**
     * Update subscription tier
     */
    public function update_subscription($tier) {
        $valid_tiers = array('free', 'starter', 'pro', 'business');
        
        if (!in_array($tier, $valid_tiers)) {
            return false;
        }
        
        update_option('micro_jpeg_subscription_tier', $tier);
        return true;
    }
    
    /**
     * Get current usage for the month
     */
    public function get_current_usage() {
        $current_month = date('Y-m');
        $operations = get_option('micro_jpeg_operations_' . $current_month, 0);
        $tier = $this->get_subscription_tier();
        $limit = $tier === 'free' ? 200 : 'unlimited';
        
        return array(
            'operations' => $operations,
            'limit' => $limit,
            'percentage' => $tier === 'free' ? round(($operations / 200) * 100, 2) : 0
        );
    }
}