<?php
/**
 * Image Compressor Class
 * Handles image compression operations
 *
 * @package MicroJPEG
 */

if (!defined('ABSPATH')) {
    exit;
}

class Micro_JPEG_Compressor {
    
    private $api;
    private $settings;
    
    public function __construct() {
        $this->api = new Micro_JPEG_API();
        $this->settings = get_option('micro_jpeg_settings', array());
    }
    
    /**
     * Initialize hooks
     */
    public function init() {
        add_filter('wp_handle_upload', array($this, 'handle_upload'), 10, 2);
        add_action('add_attachment', array($this, 'process_new_attachment'));
    }
    
    /**
     * Handle image upload
     */
    public function handle_upload($upload, $context) {
        if ($context !== 'upload') {
            return $upload;
        }
        
        // Check if auto-compress is enabled
        if (empty($this->settings['auto_compress'])) {
            return $upload;
        }
        
        // Check if it's an image
        if (!$this->is_image($upload['file'])) {
            return $upload;
        }
        
        // Compress the image
        $this->compress_image($upload['file']);
        
        return $upload;
    }
    
    /**
     * Process new attachment
     */
    public function process_new_attachment($attachment_id) {
        $file = get_attached_file($attachment_id);
        
        if (!$this->is_image($file)) {
            return;
        }
        
        // Check if already compressed
        if (get_post_meta($attachment_id, '_micro_jpeg_compressed', true)) {
            return;
        }
        
        $result = $this->compress_image($file);
        
        if (!is_wp_error($result)) {
            update_post_meta($attachment_id, '_micro_jpeg_compressed', 'yes');
            update_post_meta($attachment_id, '_micro_jpeg_original_size', $result['original_size']);
            update_post_meta($attachment_id, '_micro_jpeg_compressed_size', $result['compressed_size']);
            update_post_meta($attachment_id, '_micro_jpeg_savings', $result['savings']);
            update_post_meta($attachment_id, '_micro_jpeg_savings_percent', $result['savings_percent']);
            update_post_meta($attachment_id, '_micro_jpeg_compressed_date', current_time('mysql'));
        }
    }
    
    /**
     * Compress single image
     */
    public function compress_image($file_path) {
        if (!file_exists($file_path)) {
            return new WP_Error('file_not_found', __('File not found', 'micro-jpeg'));
        }
        
        // Get original size
        $original_size = filesize($file_path);
        
        // Create backup if enabled
        if (!empty($this->settings['keep_originals'])) {
            $this->create_backup($file_path);
        }
        
        // Get compression settings
        $quality = !empty($this->settings['quality']) ? intval($this->settings['quality']) : 85;
        $output_format = !empty($this->settings['output_format']) ? $this->settings['output_format'] : 'keep-original';
        
        // Call API to compress
        $result = $this->api->compress_image($file_path, $quality, $output_format);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        // Decode and save compressed image
        if (!empty($result['data'])) {
            $image_data = base64_decode($result['data']);
            file_put_contents($file_path, $image_data);
        }
        
        $compressed_size = filesize($file_path);
        $savings = $original_size - $compressed_size;
        $savings_percent = ($savings / $original_size) * 100;
        
        return array(
            'success' => true,
            'original_size' => $original_size,
            'compressed_size' => $compressed_size,
            'savings' => $savings,
            'savings_percent' => round($savings_percent, 2),
            'output_format' => $result['output_format']
        );
    }
    
    /**
     * Check if file is an image
     */
    private function is_image($file_path) {
        $mime_type = mime_content_type($file_path);
        $allowed_types = array(
            'image/jpeg',
            'image/jpg',
            'image/png',
            'image/webp',
            'image/avif',
            'image/svg+xml',
            'image/tiff'
        );
        
        return in_array($mime_type, $allowed_types);
    }
    
    /**
     * Check if file is RAW format
     */
    private function is_raw_file($file_path) {
        $raw_extensions = array('cr2', 'cr3', 'nef', 'arw', 'dng', 'orf', 'rw2', 'pef', 'raf');
        $extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        return in_array($extension, $raw_extensions);
    }
    
    /**
     * Create backup of original file
     */
    private function create_backup($file_path) {
        $upload_dir = wp_upload_dir();
        $backup_dir = $upload_dir['basedir'] . '/micro-jpeg-backups';
        
        if (!file_exists($backup_dir)) {
            wp_mkdir_p($backup_dir);
            
            // Add .htaccess for security
            $htaccess = $backup_dir . '/.htaccess';
            if (!file_exists($htaccess)) {
                file_put_contents($htaccess, "deny from all\n");
            }
        }
        
        $backup_path = $backup_dir . '/' . basename($file_path);
        
        // Don't overwrite existing backup
        if (file_exists($backup_path)) {
            return;
        }
        
        copy($file_path, $backup_path);
    }
    
    /**
     * Restore original image
     */
    public function restore_original($attachment_id) {
        $file_path = get_attached_file($attachment_id);
        $upload_dir = wp_upload_dir();
        $backup_path = $upload_dir['basedir'] . '/micro-jpeg-backups/' . basename($file_path);
        
        if (!file_exists($backup_path)) {
            return new WP_Error('backup_not_found', __('Backup file not found', 'micro-jpeg'));
        }
        
        // Restore backup
        copy($backup_path, $file_path);
        
        // Remove compression metadata
        delete_post_meta($attachment_id, '_micro_jpeg_compressed');
        delete_post_meta($attachment_id, '_micro_jpeg_original_size');
        delete_post_meta($attachment_id, '_micro_jpeg_compressed_size');
        delete_post_meta($attachment_id, '_micro_jpeg_savings');
        delete_post_meta($attachment_id, '_micro_jpeg_savings_percent');
        delete_post_meta($attachment_id, '_micro_jpeg_compressed_date');
        
        // Regenerate thumbnails
        if (function_exists('wp_generate_attachment_metadata')) {
            $metadata = wp_generate_attachment_metadata($attachment_id, $file_path);
            wp_update_attachment_metadata($attachment_id, $metadata);
        }
        
        return array('success' => true);
    }
    
    /**
     * Get compression statistics
     */
    public function get_stats() {
        global $wpdb;
        
        $total_compressed = $wpdb->get_var("
            SELECT COUNT(*) FROM {$wpdb->postmeta} 
            WHERE meta_key = '_micro_jpeg_compressed' AND meta_value = 'yes'
        ");
        
        $total_savings = $wpdb->get_var("
            SELECT SUM(meta_value) FROM {$wpdb->postmeta} 
            WHERE meta_key = '_micro_jpeg_savings'
        ");
        
        $avg_savings_percent = $wpdb->get_var("
            SELECT AVG(meta_value) FROM {$wpdb->postmeta} 
            WHERE meta_key = '_micro_jpeg_savings_percent'
        ");
        
        return array(
            'total_compressed' => (int)$total_compressed,
            'total_savings' => (int)$total_savings,
            'avg_savings_percent' => round((float)$avg_savings_percent, 2)
        );
    }
}