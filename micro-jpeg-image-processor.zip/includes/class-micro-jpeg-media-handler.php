<?php
/**
 * Media Handler Class
 * Handles WordPress media library integration
 *
 * @package MicroJPEG
 */

if (!defined('ABSPATH')) {
    exit;
}

class Micro_JPEG_Media_Handler {
    
    private $compressor;
    
    public function __construct() {
        $this->compressor = new Micro_JPEG_Compressor();
    }
    
    /**
     * Initialize hooks
     */
    public function init() {
        // Add compression info to media library
        add_filter('attachment_fields_to_edit', array($this, 'add_compression_fields'), 10, 2);
        
        // Add column to media library list
        add_filter('manage_media_columns', array($this, 'add_compression_column'));
        add_action('manage_media_custom_column', array($this, 'display_compression_column'), 10, 2);
        
        // Add action buttons
        add_filter('media_row_actions', array($this, 'add_media_actions'), 10, 2);
        
        // Add bulk actions
        add_filter('bulk_actions-upload', array($this, 'add_bulk_actions'));
        add_filter('handle_bulk_actions-upload', array($this, 'handle_bulk_actions'), 10, 3);
        
        // Admin notices for bulk actions
        add_action('admin_notices', array($this, 'bulk_action_notices'));
    }
    
    /**
     * Add compression fields to attachment editor
     */
    public function add_compression_fields($form_fields, $post) {
        $compressed = get_post_meta($post->ID, '_micro_jpeg_compressed', true);
        
        if ($compressed === 'yes') {
            $original_size = get_post_meta($post->ID, '_micro_jpeg_original_size', true);
            $compressed_size = get_post_meta($post->ID, '_micro_jpeg_compressed_size', true);
            $savings_percent = get_post_meta($post->ID, '_micro_jpeg_savings_percent', true);
            $compressed_date = get_post_meta($post->ID, '_micro_jpeg_compressed_date', true);
            
            $form_fields['micro_jpeg_info'] = array(
                'label' => __('Compression Info', 'micro-jpeg'),
                'input' => 'html',
                'html' => sprintf(
                    '<div class="micro-jpeg-info">
                        <p><strong>%s:</strong> %s</p>
                        <p><strong>%s:</strong> %s</p>
                        <p><strong>%s:</strong> %s%%</p>
                        <p><strong>%s:</strong> %s</p>
                        <p><a href="#" class="button micro-jpeg-restore" data-id="%d">%s</a></p>
                    </div>',
                    __('Original Size', 'micro-jpeg'),
                    size_format($original_size, 2),
                    __('Compressed Size', 'micro-jpeg'),
                    size_format($compressed_size, 2),
                    __('Savings', 'micro-jpeg'),
                    round($savings_percent, 2),
                    __('Compressed On', 'micro-jpeg'),
                    date_i18n(get_option('date_format'), strtotime($compressed_date)),
                    $post->ID,
                    __('Restore Original', 'micro-jpeg')
                )
            );
        } else {
            $form_fields['micro_jpeg_info'] = array(
                'label' => __('Compression', 'micro-jpeg'),
                'input' => 'html',
                'html' => sprintf(
                    '<p><a href="#" class="button micro-jpeg-compress-now" data-id="%d">%s</a></p>',
                    $post->ID,
                    __('Compress Now', 'micro-jpeg')
                )
            );
        }
        
        return $form_fields;
    }
    
    /**
     * Add compression column to media library
     */
    public function add_compression_column($columns) {
        $columns['micro_jpeg'] = __('Compression', 'micro-jpeg');
        return $columns;
    }
    
    /**
     * Display compression column content
     */
    public function display_compression_column($column_name, $attachment_id) {
        if ($column_name !== 'micro_jpeg') {
            return;
        }
        
        $compressed = get_post_meta($attachment_id, '_micro_jpeg_compressed', true);
        
        if ($compressed === 'yes') {
            $savings_percent = get_post_meta($attachment_id, '_micro_jpeg_savings_percent', true);
            echo '<span class="micro-jpeg-compressed" style="color: #00a32a; font-weight: 600;">✓ ' . 
                 round($savings_percent, 1) . '% saved</span>';
        } else {
            echo '<span style="color: #646970;">—</span>';
        }
    }
    
    /**
     * Add action buttons to media row
     */
    public function add_media_actions($actions, $post) {
        if (strpos($post->post_mime_type, 'image') !== false) {
            $compressed = get_post_meta($post->ID, '_micro_jpeg_compressed', true);
            
            if ($compressed === 'yes') {
                $actions['restore'] = sprintf(
                    '<a href="#" class="micro-jpeg-restore" data-id="%d">%s</a>',
                    $post->ID,
                    __('Restore Original', 'micro-jpeg')
                );
            } else {
                $actions['compress'] = sprintf(
                    '<a href="#" class="micro-jpeg-compress-now" data-id="%d">%s</a>',
                    $post->ID,
                    __('Compress', 'micro-jpeg')
                );
            }
        }
        
        return $actions;
    }
    
    /**
     * Add bulk actions
     */
    public function add_bulk_actions($bulk_actions) {
        $bulk_actions['micro_jpeg_compress'] = __('Compress Images', 'micro-jpeg');
        $bulk_actions['micro_jpeg_restore'] = __('Restore Originals', 'micro-jpeg');
        return $bulk_actions;
    }
    
    /**
     * Handle bulk actions
     */
    public function handle_bulk_actions($redirect_to, $action, $post_ids) {
        if ($action === 'micro_jpeg_compress') {
            $bulk_processor = new Micro_JPEG_Bulk_Processor();
            $results = $bulk_processor->bulk_compress($post_ids);
            
            $redirect_to = add_query_arg(array(
                'micro_jpeg_compressed' => $results['success'],
                'micro_jpeg_failed' => $results['failed'],
                'micro_jpeg_skipped' => $results['skipped']
            ), $redirect_to);
            
        } elseif ($action === 'micro_jpeg_restore') {
            $restored = 0;
            foreach ($post_ids as $post_id) {
                $result = $this->compressor->restore_original($post_id);
                if (!is_wp_error($result)) {
                    $restored++;
                }
            }
            
            $redirect_to = add_query_arg('micro_jpeg_restored', $restored, $redirect_to);
        }
        
        return $redirect_to;
    }
    
    /**
     * Display bulk action notices
     */
    public function bulk_action_notices() {
        if (!empty($_GET['micro_jpeg_compressed'])) {
            $count = intval($_GET['micro_jpeg_compressed']);
            $failed = isset($_GET['micro_jpeg_failed']) ? intval($_GET['micro_jpeg_failed']) : 0;
            $skipped = isset($_GET['micro_jpeg_skipped']) ? intval($_GET['micro_jpeg_skipped']) : 0;
            
            printf(
                '<div class="notice notice-success is-dismissible"><p>%s</p></div>',
                sprintf(
                    __('Compressed: %d, Failed: %d, Skipped: %d', 'micro-jpeg'),
                    $count,
                    $failed,
                    $skipped
                )
            );
        }
        
        if (!empty($_GET['micro_jpeg_restored'])) {
            $count = intval($_GET['micro_jpeg_restored']);
            printf(
                '<div class="notice notice-success is-dismissible"><p>%s</p></div>',
                sprintf(__('%d image(s) restored to original.', 'micro-jpeg'), $count)
            );
        }
    }
}