<?php
/**
 * Bulk Processor Class
 * Handles bulk compression of existing images
 */

class Micro_JPEG_Bulk_Processor {
    
    private $compressor;
    
    public function __construct() {
        $this->compressor = new Micro_JPEG_Compressor();
        
        // Add bulk optimization page
        add_action('admin_menu', array($this, 'add_bulk_page'));
        
        // AJAX handlers
        add_action('wp_ajax_micro_jpeg_get_uncompressed', array($this, 'ajax_get_uncompressed'));
        add_action('wp_ajax_micro_jpeg_bulk_compress', array($this, 'ajax_bulk_compress'));
    }
    
    /**
     * Add bulk optimization page
     */
    public function add_bulk_page() {
        add_media_page(
            __('Bulk Optimize Images', 'micro-jpeg'),
            __('Bulk Optimize', 'micro-jpeg'),
            'manage_options',
            'micro-jpeg-bulk',
            array($this, 'render_bulk_page')
        );
    }
    
    /**
     * Render bulk optimization page
     */
    public function render_bulk_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        
        ?>
        <div class="wrap micro-jpeg-bulk">
            <h1><?php _e('Bulk Optimize Images', 'micro-jpeg'); ?></h1>
            
            <div class="micro-jpeg-bulk-info">
                <p class="description">
                    <?php _e('Compress all uncompressed images in your media library. This process will run in the background.', 'micro-jpeg'); ?>
                </p>
            </div>
            
            <div class="micro-jpeg-bulk-stats">
                <div class="stat-box">
                    <div class="stat-label"><?php _e('Total Images', 'micro-jpeg'); ?></div>
                    <div class="stat-value" id="total-images">—</div>
                </div>
                <div class="stat-box">
                    <div class="stat-label"><?php _e('Uncompressed', 'micro-jpeg'); ?></div>
                    <div class="stat-value" id="uncompressed-images">—</div>
                </div>
                <div class="stat-box">
                    <div class="stat-label"><?php _e('Compressed', 'micro-jpeg'); ?></div>
                    <div class="stat-value" id="compressed-images">—</div>
                </div>
            </div>
            
            <div class="micro-jpeg-bulk-controls">
                <button type="button" id="start-bulk-compression" class="button button-primary button-hero">
                    <?php _e('Start Bulk Compression', 'micro-jpeg'); ?>
                </button>
                <button type="button" id="stop-bulk-compression" class="button button-hero" style="display:none;">
                    <?php _e('Stop', 'micro-jpeg'); ?>
                </button>
            </div>
            
            <div class="micro-jpeg-progress" style="display:none;">
                <div class="progress-bar-container">
                    <div class="progress-bar" id="compression-progress">
                        <span class="progress-text">0%</span>
                    </div>
                </div>
                <div class="progress-info">
                    <span id="current-progress">0</span> / <span id="total-progress">0</span> images processed
                </div>
            </div>
            
            <div class="micro-jpeg-results" style="display:none;">
                <h2><?php _e('Compression Results', 'micro-jpeg'); ?></h2>
                <div id="compression-log"></div>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            var processing = false;
            var stopRequested = false;
            var currentIndex = 0;
            var attachmentIds = [];
            
            // Load initial stats
            loadStats();
            
            function loadStats() {
                $.post(ajaxurl, {
                    action: 'micro_jpeg_get_uncompressed',
                    nonce: microJpegAdmin.nonce
                }, function(response) {
                    if (response.success) {
                        $('#total-images').text(response.data.total);
                        $('#uncompressed-images').text(response.data.uncompressed);
                        $('#compressed-images').text(response.data.compressed);
                        attachmentIds = response.data.attachment_ids;
                    }
                });
            }
            
            $('#start-bulk-compression').on('click', function() {
                if (attachmentIds.length === 0) {
                    alert('<?php _e('No uncompressed images found', 'micro-jpeg'); ?>');
                    return;
                }
                
                processing = true;
                stopRequested = false;
                currentIndex = 0;
                
                $(this).hide();
                $('#stop-bulk-compression').show();
                $('.micro-jpeg-progress').show();
                $('.micro-jpeg-results').show();
                $('#compression-log').empty();
                
                processNext();
            });
            
            $('#stop-bulk-compression').on('click', function() {
                stopRequested = true;
                $(this).prop('disabled', true).text('<?php _e('Stopping...', 'micro-jpeg'); ?>');
            });
            
            function processNext() {
                if (stopRequested || currentIndex >= attachmentIds.length) {
                    finishProcessing();
                    return;
                }
                
                var attachmentId = attachmentIds[currentIndex];
                
                $.post(ajaxurl, {
                    action: 'micro_jpeg_bulk_compress',
                    nonce: microJpegAdmin.nonce,
                    attachment_id: attachmentId
                }, function(response) {
                    currentIndex++;
                    updateProgress();
                    
                    if (response.success) {
                        logResult(attachmentId, 'success', response.data.message);
                    } else {
                        logResult(attachmentId, 'error', response.data.message || '<?php _e('Unknown error', 'micro-jpeg'); ?>');
                    }
                    
                    // Continue processing
                    if (processing && !stopRequested) {
                        setTimeout(processNext, 500);
                    } else {
                        finishProcessing();
                    }
                }).fail(function() {
                    logResult(attachmentId, 'error', '<?php _e('Network error', 'micro-jpeg'); ?>');
                    currentIndex++;
                    updateProgress();
                    
                    if (processing && !stopRequested) {
                        setTimeout(processNext, 500);
                    } else {
                        finishProcessing();
                    }
                });
            }
            
            function updateProgress() {
                var percent = Math.round((currentIndex / attachmentIds.length) * 100);
                $('#compression-progress').css('width', percent + '%');
                $('#compression-progress .progress-text').text(percent + '%');
                $('#current-progress').text(currentIndex);
                $('#total-progress').text(attachmentIds.length);
            }
            
            function logResult(attachmentId, status, message) {
                var statusClass = status === 'success' ? 'success' : 'error';
                var statusText = status === 'success' ? '✓' : '✗';
                var $log = $('<div class="log-entry ' + statusClass + '">')
                    .html('<span class="status">' + statusText + '</span> <span class="message">ID ' + attachmentId + ': ' + message + '</span>');
                $('#compression-log').prepend($log);
            }
            
            function finishProcessing() {
                processing = false;
                $('#start-bulk-compression').show().text('<?php _e('Start Again', 'micro-jpeg'); ?>');
                $('#stop-bulk-compression').hide().prop('disabled', false).text('<?php _e('Stop', 'micro-jpeg'); ?>');
                
                // Reload stats
                loadStats();
                
                if (stopRequested) {
                    alert('<?php _e('Bulk compression stopped', 'micro-jpeg'); ?>');
                } else {
                    alert('<?php _e('Bulk compression completed!', 'micro-jpeg'); ?>');
                }
            }
        });
        </script>
        <?php
    }
    
    /**
     * AJAX: Get uncompressed images
     */
    public function ajax_get_uncompressed() {
        check_ajax_referer('micro_jpeg_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'micro-jpeg')));
        }
        
        global $wpdb;
        
        // Get all image attachments
        $all_images = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} 
            WHERE post_type = 'attachment' 
            AND post_mime_type LIKE 'image/%'"
        );
        
        // Get compressed images
        $compressed_images = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} 
            WHERE meta_key = '_micro_jpeg_compressed' 
            AND meta_value = '1'"
        );
        
        // Get uncompressed attachment IDs
        $uncompressed_ids = $wpdb->get_col(
            "SELECT p.ID FROM {$wpdb->posts} p 
            LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id 
                AND pm.meta_key = '_micro_jpeg_compressed'
            WHERE p.post_type = 'attachment' 
            AND p.post_mime_type LIKE 'image/%'
            AND (pm.meta_value IS NULL OR pm.meta_value != '1')
            ORDER BY p.ID ASC"
        );
        
        wp_send_json_success(array(
            'total' => intval($all_images),
            'compressed' => intval($compressed_images),
            'uncompressed' => count($uncompressed_ids),
            'attachment_ids' => array_map('intval', $uncompressed_ids),
        ));
    }
    
    /**
     * AJAX: Compress single image in bulk process
     */
    public function ajax_bulk_compress() {
        check_ajax_referer('micro_jpeg_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'micro-jpeg')));
        }
        
        $attachment_id = !empty($_POST['attachment_id']) ? intval($_POST['attachment_id']) : 0;
        
        if (!$attachment_id) {
            wp_send_json_error(array('message' => __('Invalid attachment ID', 'micro-jpeg')));
        }
        
        $result = $this->compressor->compress_attachment($attachment_id);
        
        if (is_wp_error($result) || is_wp_error($result['main'])) {
            $error = is_wp_error($result) ? $result : $result['main'];
            wp_send_json_error(array('message' => $error->get_error_message()));
        }
        
        $stats = $this->compressor->get_compression_stats($attachment_id);
        
        wp_send_json_success(array(
            'message' => sprintf(
                __('Compressed successfully. Saved %s%%', 'micro-jpeg'),
                $stats['savings_percent']
            ),
        ));
    }
}