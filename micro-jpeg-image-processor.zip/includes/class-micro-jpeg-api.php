<?php
/**
 * API Communication Class
 * Handles all API requests to Micro JPEG backend
 */

class Micro_JPEG_API {
    
    private $api_base_url;
    private $api_key;
    
    public function __construct() {
        $this->api_base_url = defined('MICRO_JPEG_API_BASE_URL') ? MICRO_JPEG_API_BASE_URL : 'https://microjpeg.com/api';
        
        $settings = get_option('micro_jpeg_settings');
        $this->api_key = !empty($settings['api_key']) ? $settings['api_key'] : '';
    }
    
    /**
     * Validate API key
     */
    public function validate_api_key($api_key = null) {
        $key = $api_key ?? $this->api_key;
        
        if (empty($key)) {
            return array(
                'valid' => false,
                'message' => __('API key is required', 'micro-jpeg')
            );
        }
        
        $response = wp_remote_get(
            $this->api_base_url . '/wordpress/validate-key',
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $key,
                    'Content-Type' => 'application/json',
                ),
                'timeout' => 30,
            )
        );
        
        if (is_wp_error($response)) {
            return array(
                'valid' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        $code = wp_remote_retrieve_response_code($response);
        
        if ($code === 200 && !empty($body['success'])) {
            return array(
                'valid' => true,
                'tier' => $body['tier'] ?? 'free',
                'message' => __('API key is valid', 'micro-jpeg')
            );
        }
        
        return array(
            'valid' => false,
            'message' => $body['message'] ?? __('Invalid API key', 'micro-jpeg')
        );
    }
    
    /**
     * Compress image via API
     */
    public function compress_image($file_path, $quality = 85, $output_format = 'keep-original') {
        if (empty($this->api_key)) {
            return new WP_Error('no_api_key', __('API key not configured', 'micro-jpeg'));
        }
        
        if (!file_exists($file_path)) {
            return new WP_Error('file_not_found', __('File not found', 'micro-jpeg'));
        }
        
        // Prepare file for upload
        $boundary = wp_generate_password(24, false);
        $file_contents = file_get_contents($file_path);
        $filename = basename($file_path);
        
        // Build multipart body
        $body = '';
        
        // Add image file
        $body .= "--{$boundary}\r\n";
        $body .= "Content-Disposition: form-data; name=\"image\"; filename=\"{$filename}\"\r\n";
        $body .= "Content-Type: " . mime_content_type($file_path) . "\r\n\r\n";
        $body .= $file_contents . "\r\n";
        
        // Add quality parameter
        $body .= "--{$boundary}\r\n";
        $body .= "Content-Disposition: form-data; name=\"quality\"\r\n\r\n";
        $body .= $quality . "\r\n";
        
        // Add output format parameter
        $body .= "--{$boundary}\r\n";
        $body .= "Content-Disposition: form-data; name=\"outputFormat\"\r\n\r\n";
        $body .= $output_format . "\r\n";
        
        $body .= "--{$boundary}--\r\n";
        
        // Make API request
        $response = wp_remote_post(
            $this->api_base_url . '/compress',
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $this->api_key,
                    'Content-Type' => 'multipart/form-data; boundary=' . $boundary,
                ),
                'body' => $body,
                'timeout' => 60,
                'data_format' => 'body',
            )
        );
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($code !== 200) {
            return new WP_Error(
                'api_error',
                $body['message'] ?? __('Compression failed', 'micro-jpeg'),
                array('status' => $code)
            );
        }
        
        if (empty($body['success']) || empty($body['data'])) {
            return new WP_Error('invalid_response', __('Invalid API response', 'micro-jpeg'));
        }
        
        return array(
            'data' => $body['data'], // Base64 encoded compressed image
            'original_size' => $body['originalSize'] ?? 0,
            'compressed_size' => $body['compressedSize'] ?? 0,
            'savings_percent' => $body['savingsPercent'] ?? 0,
            'output_format' => $body['outputFormat'] ?? $output_format,
        );
    }
    
    /**
 * Remove background from image
 */
public function remove_background($file_path) {
    return $this->make_request('/api/remove-background', array(
        'file' => $file_path
    ));
}

/**
 * Enhance image with AI
 */
public function enhance_image($file_path, $options = array()) {
    return $this->make_request('/api/enhance-image', array(
        'file' => $file_path,
        'options' => $options
    ));
}

    /**
     * Get API usage statistics
     */
    public function get_usage_stats() {
        if (empty($this->api_key)) {
            return new WP_Error('no_api_key', __('API key not configured', 'micro-jpeg'));
        }
        
        $response = wp_remote_get(
            $this->api_base_url . '/usage',
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $this->api_key,
                ),
                'timeout' => 30,
            )
        );
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body;
    }
}