<?php
/**
 * AI Features Handler Class
 * Handles AI Remove Background and AI Image Enhancer
 *
 * @package MicroJPEG
 */

if (!defined('ABSPATH')) {
    exit;
}

class Micro_JPEG_AI_Features {
    
    private $api;
    private $settings;
    
    public function __construct($api, $settings) {
        $this->api = $api;
        $this->settings = $settings;
    }
    
    /**
     * Initialize hooks
     */
    public function init() {
        // Add media library action buttons
        add_filter('media_row_actions', array($this, 'add_media_actions'), 10, 2);
        
        // AJAX handlers
        add_action('wp_ajax_micro_jpeg_remove_background', array($this, 'ajax_remove_background'));
        add_action('wp_ajax_micro_jpeg_enhance_image', array($this, 'ajax_enhance_image'));
        
        // Add bulk actions
        add_filter('bulk_actions-upload', array($this, 'add_bulk_actions'));
        add_filter('handle_bulk_actions-upload', array($this, 'handle_bulk_actions'), 10, 3);
    }
    
    /**
     * Add action buttons to media library
     */
    public function add_media_actions($actions, $post) {
        if (strpos($post->post_mime_type, 'image') !== false) {
            $actions['remove_bg'] = sprintf(
                '<a href="#" class="micro-jpeg-remove-bg" data-id="%d">%s</a>',
                $post->ID,
                __('Remove Background', 'micro-jpeg')
            );
            
            $actions['enhance'] = sprintf(
                '<a href="#" class="micro-jpeg-enhance" data-id="%d">%s</a>',
                $post->ID,
                __('AI Enhance', 'micro-jpeg')
            );
        }
        
        return $actions;
    }
    
    /**
     * Add bulk actions
     */
    public function add_bulk_actions($bulk_actions) {
        $bulk_actions['micro_jpeg_remove_bg'] = __('Remove Background (AI)', 'micro-jpeg');
        $bulk_actions['micro_jpeg_enhance'] = __('Enhance Images (AI)', 'micro-jpeg');
        return $bulk_actions;
    }
    
    /**
     * Handle bulk actions
     */
    public function handle_bulk_actions($redirect_to, $action, $post_ids) {
        if ($action === 'micro_jpeg_remove_bg') {
            $count = 0;
            foreach ($post_ids as $post_id) {
                $result = $this->remove_background($post_id);
                if ($result['success']) {
                    $count++;
                }
            }
            $redirect_to = add_query_arg('bulk_removed_bg', $count, $redirect_to);
        } elseif ($action === 'micro_jpeg_enhance') {
            $count = 0;
            foreach ($post_ids as $post_id) {
                $result = $this->enhance_image($post_id);
                if ($result['success']) {
                    $count++;
                }
            }
            $redirect_to = add_query_arg('bulk_enhanced', $count, $redirect_to);
        }
        
        return $redirect_to;
    }
    
    /**
     * AJAX handler for remove background
     */
    public function ajax_remove_background() {
        check_ajax_referer('micro_jpeg_nonce', 'nonce');
        
        if (!current_user_can('upload_files')) {
            wp_send_json_error(array('message' => 'Unauthorized'));
        }
        
        $attachment_id = intval($_POST['attachment_id']);
        $format = isset($_POST['format']) ? sanitize_text_field($_POST['format']) : 'png';
        
        $result = $this->remove_background($attachment_id, $format);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    /**
     * AJAX handler for enhance image
     */
    public function ajax_enhance_image() {
        check_ajax_referer('micro_jpeg_nonce', 'nonce');
        
        if (!current_user_can('upload_files')) {
            wp_send_json_error(array('message' => 'Unauthorized'));
        }
        
        $attachment_id = intval($_POST['attachment_id']);
        $upscale = isset($_POST['upscale']) ? intval($_POST['upscale']) : 2;
        
        $result = $this->enhance_image($attachment_id, $upscale);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    /**
     * Get AI features limits based on tier
     */
    private function get_ai_limits($tier) {
        $limits = array(
            'free' => array(
                'bg_removals' => 5,
                'bg_formats' => array('png'),
                'enhancements' => 3,
                'max_upscale' => 2
            ),
            'starter' => array(
                'bg_removals' => 200,
                'bg_formats' => array('png', 'jpg', 'webp'),
                'enhancements' => 200,
                'max_upscale' => 8
            ),
            'starter-m' => array(
                'bg_removals' => 200,
                'bg_formats' => array('png', 'jpg', 'webp'),
                'enhancements' => 200,
                'max_upscale' => 8
            ),
            'starter-y' => array(
                'bg_removals' => 200,
                'bg_formats' => array('png', 'jpg', 'webp'),
                'enhancements' => 200,
                'max_upscale' => 8
            ),
            'pro' => array(
                'bg_removals' => 500,
                'bg_formats' => array('png', 'jpg', 'webp'),
                'enhancements' => 200,
                'max_upscale' => 8
            ),
            'pro-m' => array(
                'bg_removals' => 500,
                'bg_formats' => array('png', 'jpg', 'webp'),
                'enhancements' => 500,
                'max_upscale' => 8
            ),
            'pro-y' => array(
                'bg_removals' => 500,
                'bg_formats' => array('png', 'jpg', 'webp'),
                'enhancements' => 500,
                'max_upscale' => 8
            ),
            'business' => array(
                'bg_removals' => 1000,
                'bg_formats' => array('png', 'jpg', 'webp'),
                'enhancements' => 1000,
                'max_upscale' => 8
            ),
            'business-m' => array(
                'bg_removals' => 1000,
                'bg_formats' => array('png', 'jpg', 'webp'),
                'enhancements' => 1000,
                'max_upscale' => 8
            ),
            'business-y' => array(
                'bg_removals' => 1000,
                'bg_formats' => array('png', 'jpg', 'webp'),
                'enhancements' => 1000,
                'max_upscale' => 8
            ),
            'enterprise' => array(
                'bg_removals' => -1, // unlimited
                'bg_formats' => array('png', 'jpg', 'webp'),
                'enhancements' => -1, // unlimited
                'max_upscale' => 8
            )
        );
        
        return isset($limits[$tier]) ? $limits[$tier] : $limits['free'];
    }
    
    /**
     * Check BG removal limit
     */
    private function check_bg_removal_limit() {
        $tier = $this->settings->get_subscription_tier();
        $limits = $this->get_ai_limits($tier);
        
        if ($limits['bg_removals'] === -1) {
            return true; // Unlimited
        }
        
        $current_month = date('Y-m');
        $count = get_option('micro_jpeg_bg_removals_' . $current_month, 0);
        
        return $count < $limits['bg_removals'];
    }
    
    /**
     * Check enhancement limit
     */
    private function check_enhancement_limit() {
        $tier = $this->settings->get_subscription_tier();
        $limits = $this->get_ai_limits($tier);
        
        if ($limits['enhancements'] === -1) {
            return true; // Unlimited
        }
        
        $current_month = date('Y-m');
        $count = get_option('micro_jpeg_enhancements_' . $current_month, 0);
        
        return $count < $limits['enhancements'];
    }
    
    /**
     * Validate output format for tier
     */
    private function validate_format($format) {
        $tier = $this->settings->get_subscription_tier();
        $limits = $this->get_ai_limits($tier);
        
        return in_array($format, $limits['bg_formats']);
    }
    
    /**
     * Validate upscale level
     */
    private function validate_upscale($upscale) {
        $tier = $this->settings->get_subscription_tier();
        $limits = $this->get_ai_limits($tier);
        
        return $upscale <= $limits['max_upscale'];
    }
    
    /**
     * Remove background from image
     */
    public function remove_background($attachment_id, $format = 'png') {
        $file_path = get_attached_file($attachment_id);
        
        if (!file_exists($file_path)) {
            return array(
                'success' => false,
                'error' => 'File not found'
            );
        }
        
        // Check BG removal limit
        if (!$this->check_bg_removal_limit()) {
            return array(
                'success' => false,
                'error' => 'Monthly background removal limit reached. Please upgrade your plan.'
            );
        }
        
        // Validate format
        if (!$this->validate_format($format)) {
            return array(
                'success' => false,
                'error' => 'Output format not supported in your plan. Upgrade to use all formats.'
            );
        }
        
        // Create backup if enabled
        if (get_option('micro_jpeg_backup_originals', 'yes') === 'yes') {
            $this->create_backup($file_path);
        }
        
        // Call API to remove background
        $result = $this->api->remove_background($file_path, $format);
        
        if (!is_wp_error($result) && !empty($result['success'])) {
            // Update metadata
            update_post_meta($attachment_id, '_micro_jpeg_bg_removed', 'yes');
            update_post_meta($attachment_id, '_micro_jpeg_bg_removed_date', current_time('mysql'));
            update_post_meta($attachment_id, '_micro_jpeg_bg_format', $format);
            
            // Increment counter
            $current_month = date('Y-m');
            $count = get_option('micro_jpeg_bg_removals_' . $current_month, 0);
            update_option('micro_jpeg_bg_removals_' . $current_month, $count + 1);
            
            // Regenerate thumbnails
            $this->regenerate_thumbnails($attachment_id);
            
            return array(
                'success' => true,
                'message' => 'Background removed successfully',
                'attachment_id' => $attachment_id
            );
        }
        
        return array(
            'success' => false,
            'error' => is_wp_error($result) ? $result->get_error_message() : 'Failed to remove background'
        );
    }
    
    /**
     * Enhance image using AI
     */
    public function enhance_image($attachment_id, $upscale = 2) {
        $file_path = get_attached_file($attachment_id);
        
        if (!file_exists($file_path)) {
            return array(
                'success' => false,
                'error' => 'File not found'
            );
        }
        
        // Check enhancement limit
        if (!$this->check_enhancement_limit()) {
            return array(
                'success' => false,
                'error' => 'Monthly enhancement limit reached. Please upgrade your plan.'
            );
        }
        
        // Validate upscale level
        if (!$this->validate_upscale($upscale)) {
            $tier = $this->settings->get_subscription_tier();
            $limits = $this->get_ai_limits($tier);
            return array(
                'success' => false,
                'error' => "Maximum upscale for your plan is {$limits['max_upscale']}x. Please upgrade."
            );
        }
        
        // Create backup if enabled
        if (get_option('micro_jpeg_backup_originals', 'yes') === 'yes') {
            $this->create_backup($file_path);
        }
        
        // Get enhancement options
        $options = array(
            'denoise' => true,
            'sharpen' => true,
            'color_correction' => true,
            'upscale' => $upscale
        );
        
        // Call API to enhance image
        $result = $this->api->enhance_image($file_path, $options);
        
        if (!is_wp_error($result) && !empty($result['success'])) {
            // Update metadata
            update_post_meta($attachment_id, '_micro_jpeg_enhanced', 'yes');
            update_post_meta($attachment_id, '_micro_jpeg_enhanced_date', current_time('mysql'));
            update_post_meta($attachment_id, '_micro_jpeg_upscale_level', $upscale);
            
            // Increment counter
            $current_month = date('Y-m');
            $count = get_option('micro_jpeg_enhancements_' . $current_month, 0);
            update_option('micro_jpeg_enhancements_' . $current_month, $count + 1);
            
            // Regenerate thumbnails
            $this->regenerate_thumbnails($attachment_id);
            
            return array(
                'success' => true,
                'message' => 'Image enhanced successfully',
                'attachment_id' => $attachment_id,
                'upscale' => $upscale
            );
        }
        
        return array(
            'success' => false,
            'error' => is_wp_error($result) ? $result->get_error_message() : 'Failed to enhance image'
        );
    }
    
    /**
     * Create backup of original file
     */
    private function create_backup($file_path) {
        $upload_dir = wp_upload_dir();
        $backup_dir = $upload_dir['basedir'] . '/micro-jpeg-backups';
        
        if (!file_exists($backup_dir)) {
            wp_mkdir_p($backup_dir);
        }
        
        $backup_path = $backup_dir . '/' . basename($file_path);
        copy($file_path, $backup_path);
    }
    
    /**
     * Regenerate thumbnails
     */
    private function regenerate_thumbnails($attachment_id) {
        if (function_exists('wp_generate_attachment_metadata')) {
            $file = get_attached_file($attachment_id);
            $metadata = wp_generate_attachment_metadata($attachment_id, $file);
            wp_update_attachment_metadata($attachment_id, $metadata);
        }
    }
    
    /**
     * Get AI features statistics
     */
    public function get_statistics() {
        global $wpdb;
        
        $bg_removed = $wpdb->get_var("
            SELECT COUNT(*) FROM {$wpdb->postmeta} 
            WHERE meta_key = '_micro_jpeg_bg_removed' AND meta_value = 'yes'
        ");
        
        $enhanced = $wpdb->get_var("
            SELECT COUNT(*) FROM {$wpdb->postmeta} 
            WHERE meta_key = '_micro_jpeg_enhanced' AND meta_value = 'yes'
        ");
        
        $current_month = date('Y-m');
        $bg_count = get_option('micro_jpeg_bg_removals_' . $current_month, 0);
        $enhance_count = get_option('micro_jpeg_enhancements_' . $current_month, 0);
        
        return array(
            'background_removed_total' => (int)$bg_removed,
            'images_enhanced_total' => (int)$enhanced,
            'bg_removals_this_month' => (int)$bg_count,
            'enhancements_this_month' => (int)$enhance_count
        );
    }
    
    /**
     * Get current usage
     */
    public function get_current_usage() {
        $tier = $this->settings->get_subscription_tier();
        $limits = $this->get_ai_limits($tier);
        $current_month = date('Y-m');
        
        $bg_count = get_option('micro_jpeg_bg_removals_' . $current_month, 0);
        $enhance_count = get_option('micro_jpeg_enhancements_' . $current_month, 0);
        
        return array(
            'bg_removals' => array(
                'used' => $bg_count,
                'limit' => $limits['bg_removals'] === -1 ? 'Unlimited' : $limits['bg_removals'],
                'percentage' => $limits['bg_removals'] === -1 ? 0 : round(($bg_count / $limits['bg_removals']) * 100, 2)
            ),
            'enhancements' => array(
                'used' => $enhance_count,
                'limit' => $limits['enhancements'] === -1 ? 'Unlimited' : $limits['enhancements'],
                'percentage' => $limits['enhancements'] === -1 ? 0 : round(($enhance_count / $limits['enhancements']) * 100, 2)
            ),
            'formats' => $limits['bg_formats'],
            'max_upscale' => $limits['max_upscale']
        );
    }
}