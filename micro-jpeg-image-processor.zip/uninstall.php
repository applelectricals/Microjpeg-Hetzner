<?php
/**
 * Uninstall Script
 * Fired when the plugin is uninstalled
 *
 * @package MicroJPEG
 */

// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

/**
 * Delete plugin options
 */
delete_option('micro_jpeg_settings');
delete_option('micro_jpeg_subscription_tier');

// Delete all monthly operation counters
global $wpdb;
$wpdb->query(
    "DELETE FROM {$wpdb->options} 
     WHERE option_name LIKE 'micro_jpeg_operations_%' 
     OR option_name LIKE 'micro_jpeg_bg_removals_%' 
     OR option_name LIKE 'micro_jpeg_enhancements_%'"
);

/**
 * Delete post meta for all attachments
 */
$wpdb->query(
    "DELETE FROM {$wpdb->postmeta} 
     WHERE meta_key LIKE '_micro_jpeg_%'"
);

/**
 * Optional: Delete backup files
 * Uncomment if you want to delete backups on uninstall
 */
/*
$upload_dir = wp_upload_dir();
$backup_dir = $upload_dir['basedir'] . '/micro-jpeg-backups';

if (file_exists($backup_dir)) {
    // Delete all files in backup directory
    $files = glob($backup_dir . '/*');
    foreach ($files as $file) {
        if (is_file($file)) {
            unlink($file);
        }
    }
    
    // Delete .htaccess
    if (file_exists($backup_dir . '/.htaccess')) {
        unlink($backup_dir . '/.htaccess');
    }
    
    // Remove directory
    rmdir($backup_dir);
}
*/

/**
 * Clear any cached data
 */
wp_cache_flush();

/**
 * Remove scheduled events
 */
wp_clear_scheduled_hook('micro_jpeg_bulk_process');
wp_clear_scheduled_hook('micro_jpeg_process_batch');

/**
 * Optional: Remove custom database tables if you created any
 */
// $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}micro_jpeg_logs");

/**
 * Log uninstall event (optional)
 */
if (function_exists('error_log')) {
    error_log('Micro JPEG plugin uninstalled at ' . current_time('mysql'));
}