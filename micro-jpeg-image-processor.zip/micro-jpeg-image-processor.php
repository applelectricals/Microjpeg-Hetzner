<?php
/**
 * Plugin Name: Micro JPEG - Image Compression & AI Features
 * Plugin URI: https://microjpeg.com/wordpress-plugin
 * Description: Automatically compress and optimize images on upload. AI-powered background removal and image enhancement. Support for JPEG, PNG, WebP, AVIF, RAW formats (CR2, ARW, DNG, NEF, ORF, RAF, RW2).
 * Version: 2.2.0
 * Author: Micro JPEG
 * Author URI: https://microjpeg.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: micro-jpeg
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.4
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Define plugin constants
define('MICRO_JPEG_VERSION', '2.2.0');
define('MICRO_JPEG_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MICRO_JPEG_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MICRO_JPEG_PATH', plugin_dir_path(__FILE__));
define('MICRO_JPEG_URL', plugin_dir_url(__FILE__));
define('MICRO_JPEG_API_BASE_URL', 'https://api.microjpeg.com');

/**
 * Activation hook
 */
function micro_jpeg_activate() {
    // Create default settings
    $default_settings = array(
        'api_key' => '',
        'auto_compress' => true,
        'bypass_wp_compression' => true,
        'quality' => 85,
        'output_format' => 'keep-original',
        'keep_originals' => true,
        'enable_raw' => true,
        'raw_output_format' => 'jpeg',
        'raw_quality' => 90,
    );
    
    add_option('micro_jpeg_settings', $default_settings);
    add_option('micro_jpeg_subscription_tier', 'free');
    
    // Create backup directory
    $upload_dir = wp_upload_dir();
    $backup_dir = $upload_dir['basedir'] . '/micro-jpeg-backups';
    
    if (!file_exists($backup_dir)) {
        wp_mkdir_p($backup_dir);
        
        // Add .htaccess to prevent direct access
        $htaccess = $backup_dir . '/.htaccess';
        if (!file_exists($htaccess)) {
            file_put_contents($htaccess, "deny from all\n");
        }
    }
    
    // Flush rewrite rules
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'micro_jpeg_activate');

/**
 * Deactivation hook
 */
function micro_jpeg_deactivate() {
    // Clean up scheduled events
    wp_clear_scheduled_hook('micro_jpeg_bulk_process');
    wp_clear_scheduled_hook('micro_jpeg_process_batch');
    
    // Flush rewrite rules
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'micro_jpeg_deactivate');

/**
 * Load plugin text domain for translations
 */
function micro_jpeg_load_textdomain() {
    load_plugin_textdomain('micro-jpeg', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'micro_jpeg_load_textdomain');

/**
 * Include required files
 */
require_once MICRO_JPEG_PLUGIN_DIR . 'includes/class-micro-jpeg-api.php';
require_once MICRO_JPEG_PLUGIN_DIR . 'includes/class-micro-jpeg-compressor.php';
require_once MICRO_JPEG_PLUGIN_DIR . 'includes/class-micro-jpeg-settings.php';
require_once MICRO_JPEG_PLUGIN_DIR . 'includes/class-micro-jpeg-media-handler.php';
require_once MICRO_JPEG_PLUGIN_DIR . 'includes/class-micro-jpeg-bulk-processor.php';
require_once MICRO_JPEG_PLUGIN_DIR . 'includes/class-micro-jpeg-ai-features.php';

/**
 * Initialize the plugin
 */
function micro_jpeg_init() {
    // Initialize API
    $api = new Micro_JPEG_API();
    
    // Initialize settings page
    $settings = new Micro_JPEG_Settings($api);
    $settings->init();
    
    // Initialize compressor
    $compressor = new Micro_JPEG_Compressor();
    $compressor->init();
    
    // Initialize media handler
    $media_handler = new Micro_JPEG_Media_Handler();
    $media_handler->init();
    
    // Initialize bulk processor
    $bulk_processor = new Micro_JPEG_Bulk_Processor();
    $bulk_processor->init();
    
    // Initialize AI Features
    $ai_features = new Micro_JPEG_AI_Features($api, $settings);
    $ai_features->init();
}
add_action('init', 'micro_jpeg_init');

/**
 * Add settings link on plugin page
 */
function micro_jpeg_plugin_action_links($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=micro-jpeg') . '">' . __('Dashboard', 'micro-jpeg') . '</a>';
    $upgrade_link = '<a href="' . admin_url('admin.php?page=micro-jpeg-subscription') . '" style="color: #00a32a; font-weight: 600;">' . __('Upgrade', 'micro-jpeg') . '</a>';
    
    array_unshift($links, $settings_link, $upgrade_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'micro_jpeg_plugin_action_links');

/**
 * Add RAW MIME types to WordPress
 */
function micro_jpeg_add_raw_mime_types($mimes) {
    $settings = get_option('micro_jpeg_settings');
    
    if (!empty($settings['enable_raw'])) {
        $mimes['cr2'] = 'image/x-canon-cr2';
        $mimes['cr3'] = 'image/x-canon-cr3';
        $mimes['arw'] = 'image/x-sony-arw';
        $mimes['dng'] = 'image/x-adobe-dng';
        $mimes['nef'] = 'image/x-nikon-nef';
        $mimes['orf'] = 'image/x-olympus-orf';
        $mimes['raf'] = 'image/x-fuji-raf';
        $mimes['rw2'] = 'image/x-panasonic-rw2';
        $mimes['pef'] = 'image/x-pentax-pef';
    }
    
    return $mimes;
}
add_filter('upload_mimes', 'micro_jpeg_add_raw_mime_types');

/**
 * Override WordPress default JPEG quality
 */
function micro_jpeg_override_jpeg_quality($quality, $context) {
    $settings = get_option('micro_jpeg_settings');
    
    if (!empty($settings['bypass_wp_compression'])) {
        return 100; // Disable WordPress compression, we'll handle it
    }
    
    return $quality;
}
add_filter('jpeg_quality', 'micro_jpeg_override_jpeg_quality', 10, 2);
add_filter('wp_editor_set_quality', 'micro_jpeg_override_jpeg_quality');

/**
 * Admin notice for missing API key
 */
function micro_jpeg_admin_notices() {
    $settings = get_option('micro_jpeg_settings');
    
    if (empty($settings['api_key'])) {
        $screen = get_current_screen();
        
        if ($screen && !in_array($screen->id, array('toplevel_page_micro-jpeg', 'micro-jpeg_page_micro-jpeg-settings'))) {
            ?>
            <div class="notice notice-warning is-dismissible">
                <p>
                    <strong><?php _e('Micro JPEG:', 'micro-jpeg'); ?></strong>
                    <?php _e('Please configure your API key to start compressing images.', 'micro-jpeg'); ?>
                    <a href="<?php echo admin_url('admin.php?page=micro-jpeg-settings'); ?>">
                        <?php _e('Configure now', 'micro-jpeg'); ?>
                    </a>
                </p>
            </div>
            <?php
        }
    }
}
add_action('admin_notices', 'micro_jpeg_admin_notices');

/**
 * Enqueue admin scripts and styles
 */
function micro_jpeg_admin_enqueue_scripts($hook) {
    // Only load on our pages and media pages
    if (!in_array($hook, array('toplevel_page_micro-jpeg', 'micro-jpeg_page_micro-jpeg-settings', 'micro-jpeg_page_micro-jpeg-bulk', 'micro-jpeg_page_micro-jpeg-subscription', 'upload.php', 'post.php', 'post-new.php'))) {
        return;
    }
    
    wp_enqueue_style(
        'micro-jpeg-admin',
        MICRO_JPEG_PLUGIN_URL . 'admin/css/micro-jpeg-admin.css',
        array(),
        MICRO_JPEG_VERSION
    );
    
    wp_enqueue_script(
        'micro-jpeg-admin',
        MICRO_JPEG_PLUGIN_URL . 'admin/js/micro-jpeg-admin.js',
        array('jquery'),
        MICRO_JPEG_VERSION,
        true
    );
    
    // Localize script
    wp_localize_script('micro-jpeg-admin', 'microJpegData', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('micro_jpeg_nonce'),
        'strings' => array(
            'compressing' => __('Compressing...', 'micro-jpeg'),
            'compressed' => __('Compressed', 'micro-jpeg'),
            'error' => __('Error', 'micro-jpeg'),
            'confirmRestore' => __('Are you sure you want to restore the original image?', 'micro-jpeg'),
        ),
    ));
}
add_action('admin_enqueue_scripts', 'micro_jpeg_admin_enqueue_scripts');

/**
 * AJAX handler for saving settings
 */
add_action('wp_ajax_micro_jpeg_save_settings', function() {
    check_ajax_referer('micro_jpeg_nonce', 'micro_jpeg_nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Unauthorized'));
    }
    
    $settings = isset($_POST['micro_jpeg_settings']) ? $_POST['micro_jpeg_settings'] : array();
    
    // Sanitize settings
    $clean_settings = array(
        'api_key' => sanitize_text_field($settings['api_key'] ?? ''),
        'auto_compress' => !empty($settings['auto_compress']),
        'bypass_wp_compression' => !empty($settings['bypass_wp_compression']),
        'quality' => intval($settings['quality'] ?? 85),
        'output_format' => sanitize_text_field($settings['output_format'] ?? 'keep-original'),
        'keep_originals' => !empty($settings['keep_originals']),
        'enable_raw' => !empty($settings['enable_raw']),
        'raw_output_format' => sanitize_text_field($settings['raw_output_format'] ?? 'jpeg'),
        'raw_quality' => intval($settings['raw_quality'] ?? 90),
    );
    
    update_option('micro_jpeg_settings', $clean_settings);
    
    wp_send_json_success(array('message' => 'Settings saved successfully'));
});