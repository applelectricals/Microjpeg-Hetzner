<?php
/**
 * Settings Page Template
 *
 * @package MicroJPEG
 */

if (!defined('ABSPATH')) {
    exit;
}

$settings = get_option('micro_jpeg_settings', array());
$api_key = isset($settings['api_key']) ? $settings['api_key'] : '';
?>

<div class="wrap micro-jpeg-wrap">
    <h1><?php _e('Micro JPEG Settings', 'micro-jpeg'); ?></h1>
    
    <form method="post" id="micro-jpeg-settings-form" class="micro-jpeg-settings-form">
        <?php wp_nonce_field('micro_jpeg_save_settings', 'micro_jpeg_nonce'); ?>
        
        <!-- API Configuration -->
        <h2><?php _e('API Configuration', 'micro-jpeg'); ?></h2>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="api_key"><?php _e('API Key', 'micro-jpeg'); ?></label>
                </th>
                <td>
                    <input type="text" 
                           id="api_key" 
                           name="micro_jpeg_settings[api_key]" 
                           value="<?php echo esc_attr($api_key); ?>" 
                           class="regular-text" 
                           required>
                    <button type="button" id="micro-jpeg-validate-key" class="button">
                        <?php _e('Validate Key', 'micro-jpeg'); ?>
                    </button>
                    <p class="description">
                        <?php _e('Enter your Micro JPEG API key. ', 'micro-jpeg'); ?>
                        <a href="https://microjpeg.com/api-keys" target="_blank"><?php _e('Get your API key', 'micro-jpeg'); ?></a>
                    </p>
                </td>
            </tr>
        </table>
        
        <!-- Compression Settings -->
        <h2><?php _e('Compression Settings', 'micro-jpeg'); ?></h2>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="auto_compress"><?php _e('Auto Compress', 'micro-jpeg'); ?></label>
                </th>
                <td>
                    <input type="checkbox" 
                           id="auto_compress" 
                           name="micro_jpeg_settings[auto_compress]" 
                           value="1" 
                           <?php checked(!empty($settings['auto_compress'])); ?>>
                    <label for="auto_compress"><?php _e('Automatically compress images on upload', 'micro-jpeg'); ?></label>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="bypass_wp_compression"><?php _e('Bypass WordPress Compression', 'micro-jpeg'); ?></label>
                </th>
                <td>
                    <input type="checkbox" 
                           id="bypass_wp_compression" 
                           name="micro_jpeg_settings[bypass_wp_compression]" 
                           value="1" 
                           <?php checked(!empty($settings['bypass_wp_compression'])); ?>>
                    <label for="bypass_wp_compression"><?php _e('Disable WordPress default compression (Recommended)', 'micro-jpeg'); ?></label>
                    <p class="description"><?php _e('Let Micro JPEG handle all compression for better quality.', 'micro-jpeg'); ?></p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="quality"><?php _e('Quality', 'micro-jpeg'); ?></label>
                </th>
                <td>
                    <input type="number" 
                           id="quality" 
                           name="micro_jpeg_settings[quality]" 
                           value="<?php echo isset($settings['quality']) ? intval($settings['quality']) : 85; ?>" 
                           min="1" 
                           max="100" 
                           class="small-text">
                    <p class="description"><?php _e('Compression quality (1-100). Recommended: 85', 'micro-jpeg'); ?></p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="output_format"><?php _e('Output Format', 'micro-jpeg'); ?></label>
                </th>
                <td>
                    <select id="output_format" name="micro_jpeg_settings[output_format]">
                        <option value="keep-original" <?php selected(isset($settings['output_format']) ? $settings['output_format'] : '', 'keep-original'); ?>>
                            <?php _e('Keep Original Format', 'micro-jpeg'); ?>
                        </option>
                        <option value="jpeg" <?php selected(isset($settings['output_format']) ? $settings['output_format'] : '', 'jpeg'); ?>>
                            <?php _e('Convert to JPEG', 'micro-jpeg'); ?>
                        </option>
                        <option value="webp" <?php selected(isset($settings['output_format']) ? $settings['output_format'] : '', 'webp'); ?>>
                            <?php _e('Convert to WebP', 'micro-jpeg'); ?>
                        </option>
                        <option value="avif" <?php selected(isset($settings['output_format']) ? $settings['output_format'] : '', 'avif'); ?>>
                            <?php _e('Convert to AVIF', 'micro-jpeg'); ?>
                        </option>
                    </select>
                    <p class="description"><?php _e('Choose output format for compressed images.', 'micro-jpeg'); ?></p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="keep_originals"><?php _e('Keep Originals', 'micro-jpeg'); ?></label>
                </th>
                <td>
                    <input type="checkbox" 
                           id="keep_originals" 
                           name="micro_jpeg_settings[keep_originals]" 
                           value="1" 
                           <?php checked(!empty($settings['keep_originals'])); ?>>
                    <label for="keep_originals"><?php _e('Keep backup copies of original images', 'micro-jpeg'); ?></label>
                    <p class="description"><?php _e('Allows you to restore original images if needed.', 'micro-jpeg'); ?></p>
                </td>
            </tr>
        </table>
        
        <!-- RAW File Settings -->
        <h2><?php _e('RAW File Settings', 'micro-jpeg'); ?></h2>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="enable_raw"><?php _e('Enable RAW Support', 'micro-jpeg'); ?></label>
                </th>
                <td>
                    <input type="checkbox" 
                           id="enable_raw" 
                           name="micro_jpeg_settings[enable_raw]" 
                           value="1" 
                           <?php checked(!empty($settings['enable_raw'])); ?>>
                    <label for="enable_raw"><?php _e('Allow upload and conversion of RAW files (CR2, NEF, ARW, DNG, etc.)', 'micro-jpeg'); ?></label>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="raw_output_format"><?php _e('RAW Output Format', 'micro-jpeg'); ?></label>
                </th>
                <td>
                    <select id="raw_output_format" name="micro_jpeg_settings[raw_output_format]">
                        <option value="jpeg" <?php selected(isset($settings['raw_output_format']) ? $settings['raw_output_format'] : '', 'jpeg'); ?>>
                            <?php _e('JPEG', 'micro-jpeg'); ?>
                        </option>
                        <option value="png" <?php selected(isset($settings['raw_output_format']) ? $settings['raw_output_format'] : '', 'png'); ?>>
                            <?php _e('PNG', 'micro-jpeg'); ?>
                        </option>
                        <option value="webp" <?php selected(isset($settings['raw_output_format']) ? $settings['raw_output_format'] : '', 'webp'); ?>>
                            <?php _e('WebP', 'micro-jpeg'); ?>
                        </option>
                    </select>
                    <p class="description"><?php _e('Format to convert RAW files to.', 'micro-jpeg'); ?></p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="raw_quality"><?php _e('RAW Quality', 'micro-jpeg'); ?></label>
                </th>
                <td>
                    <input type="number" 
                           id="raw_quality" 
                           name="micro_jpeg_settings[raw_quality]" 
                           value="<?php echo isset($settings['raw_quality']) ? intval($settings['raw_quality']) : 90; ?>" 
                           min="1" 
                           max="100" 
                           class="small-text">
                    <p class="description"><?php _e('Quality for RAW file conversion (1-100). Recommended: 90', 'micro-jpeg'); ?></p>
                </td>
            </tr>
        </table>
        
        <!-- AI Features Settings -->
        <h2><?php _e('AI Features', 'micro-jpeg'); ?></h2>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label><?php _e('Background Removal', 'micro-jpeg'); ?></label>
                </th>
                <td>
                    <p class="description">
                        <?php _e('Remove backgrounds from images using AI. Available in Media Library.', 'micro-jpeg'); ?>
                    </p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label><?php _e('Image Enhancement', 'micro-jpeg'); ?></label>
                </th>
                <td>
                    <p class="description">
                        <?php _e('Enhance and upscale images using AI. Available in Media Library.', 'micro-jpeg'); ?>
                    </p>
                </td>
            </tr>
        </table>
        
        <p class="submit">
            <button type="submit" class="button button-primary"><?php _e('Save Changes', 'micro-jpeg'); ?></button>
        </p>
    </form>
</div>

<script>
jQuery(document).ready(function($) {
    $('#micro-jpeg-settings-form').on('submit', function(e) {
        e.preventDefault();
        
        var $form = $(this);
        var $button = $form.find('button[type="submit"]');
        
        $button.prop('disabled', true).text('<?php _e('Saving...', 'micro-jpeg'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: $form.serialize() + '&action=micro_jpeg_save_settings',
            success: function(response) {
                if (response.success) {
                    alert('<?php _e('Settings saved successfully!', 'micro-jpeg'); ?>');
                    location.reload();
                } else {
                    alert('<?php _e('Failed to save settings.', 'micro-jpeg'); ?>');
                }
            },
            error: function() {
                alert('<?php _e('An error occurred.', 'micro-jpeg'); ?>');
            },
            complete: function() {
                $button.prop('disabled', false).text('<?php _e('Save Changes', 'micro-jpeg'); ?>');
            }
        });
    });
});
</script>