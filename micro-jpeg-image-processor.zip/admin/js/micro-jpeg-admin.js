(function($) {
  'use strict';

  const MicroJPEG = {
    init: function() {
      this.bindEvents();
      this.initBulkCompress();
      this.initAIFeatures();
    },

    bindEvents: function() {
      // API Key validation
      $('#micro-jpeg-validate-key').on('click', this.validateApiKey);
      
      // Settings form
      $('#micro-jpeg-settings-form').on('submit', this.saveSettings);
      
      // Subscription upgrade
      $('.micro-jpeg-upgrade-btn').on('click', this.handleUpgrade);
    },

    validateApiKey: function(e) {
      e.preventDefault();
      
      const $button = $(this);
      const apiKey = $('#micro_jpeg_api_key').val();
      
      if (!apiKey) {
        alert('Please enter an API key');
        return;
      }
      
      $button.prop('disabled', true).text('Validating...');
      
      $.ajax({
        url: microJpegData.ajaxurl,
        type: 'POST',
        data: {
          action: 'micro_jpeg_validate_key',
          nonce: microJpegData.nonce,
          api_key: apiKey
        },
        success: function(response) {
          if (response.success) {
            alert('API Key is valid! Tier: ' + response.data.tier);
            location.reload();
          } else {
            alert('Invalid API Key: ' + response.data.message);
          }
        },
        error: function() {
          alert('Failed to validate API key');
        },
        complete: function() {
          $button.prop('disabled', false).text('Validate Key');
        }
      });
    },

    saveSettings: function(e) {
      e.preventDefault();
      
      const $form = $(this);
      const $button = $form.find('button[type="submit"]');
      
      $button.prop('disabled', true).text('Saving...');
      
      $.ajax({
        url: microJpegData.ajaxurl,
        type: 'POST',
        data: $form.serialize() + '&action=micro_jpeg_save_settings&nonce=' + microJpegData.nonce,
        success: function(response) {
          if (response.success) {
            alert('Settings saved successfully!');
          } else {
            alert('Failed to save settings');
          }
        },
        complete: function() {
          $button.prop('disabled', false).text('Save Changes');
        }
      });
    },

    initBulkCompress: function() {
      $('#micro-jpeg-bulk-compress-btn').on('click', function(e) {
        e.preventDefault();
        
        const selectedImages = $('.micro-jpeg-image-checkbox:checked').map(function() {
          return $(this).val();
        }).get();
        
        if (selectedImages.length === 0) {
          alert('Please select at least one image');
          return;
        }
        
        if (!confirm('Compress ' + selectedImages.length + ' image(s)?')) {
          return;
        }
        
        MicroJPEG.processBulkCompress(selectedImages);
      });
    },

    processBulkCompress: function(imageIds) {
      const total = imageIds.length;
      let completed = 0;
      let failed = 0;
      
      const processNext = function() {
        if (imageIds.length === 0) {
          alert('Bulk compression complete!\nSuccess: ' + completed + '\nFailed: ' + failed);
          location.reload();
          return;
        }
        
        const imageId = imageIds.shift();
        const $item = $('.micro-jpeg-image-item[data-id="' + imageId + '"]');
        
        $item.find('.micro-jpeg-image-status')
          .removeClass('pending')
          .addClass('processing')
          .text('Processing...');
        
        $.ajax({
          url: microJpegData.ajaxurl,
          type: 'POST',
          data: {
            action: 'micro_jpeg_compress_image',
            nonce: microJpegData.nonce,
            attachment_id: imageId
          },
          success: function(response) {
            if (response.success) {
              completed++;
              $item.find('.micro-jpeg-image-status')
                .removeClass('processing')
                .addClass('success')
                .text('Compressed');
            } else {
              failed++;
              $item.find('.micro-jpeg-image-status')
                .removeClass('processing')
                .addClass('error')
                .text('Failed');
            }
          },
          error: function() {
            failed++;
            $item.find('.micro-jpeg-image-status')
              .removeClass('processing')
              .addClass('error')
              .text('Error');
          },
          complete: function() {
            processNext();
          }
        });
      };
      
      processNext();
    },

    initAIFeatures: function() {
      // Remove Background
      $(document).on('click', '.micro-jpeg-remove-bg', function(e) {
        e.preventDefault();
        
        const attachmentId = $(this).data('id');
        const format = prompt('Output format (png, jpg, webp):', 'png');
        
        if (!format) return;
        
        MicroJPEG.removeBackground(attachmentId, format);
      });
      
      // Enhance Image
      $(document).on('click', '.micro-jpeg-enhance', function(e) {
        e.preventDefault();
        
        const attachmentId = $(this).data('id');
        const upscale = prompt('Upscale level (2, 4, 8):', '2');
        
        if (!upscale) return;
        
        MicroJPEG.enhanceImage(attachmentId, parseInt(upscale));
      });
    },

    removeBackground: function(attachmentId, format) {
      const $button = $('.micro-jpeg-remove-bg[data-id="' + attachmentId + '"]');
      const originalText = $button.text();
      
      $button.prop('disabled', true).text('Removing...');
      
      $.ajax({
        url: microJpegData.ajaxurl,
        type: 'POST',
        data: {
          action: 'micro_jpeg_remove_background',
          nonce: microJpegData.nonce,
          attachment_id: attachmentId,
          format: format
        },
        success: function(response) {
          if (response.success) {
            alert('Background removed successfully!');
            location.reload();
          } else {
            alert('Failed: ' + response.data.error);
          }
        },
        error: function() {
          alert('Failed to remove background');
        },
        complete: function() {
          $button.prop('disabled', false).text(originalText);
        }
      });
    },

    enhanceImage: function(attachmentId, upscale) {
      const $button = $('.micro-jpeg-enhance[data-id="' + attachmentId + '"]');
      const originalText = $button.text();
      
      $button.prop('disabled', true).text('Enhancing...');
      
      $.ajax({
        url: microJpegData.ajaxurl,
        type: 'POST',
        data: {
          action: 'micro_jpeg_enhance_image',
          nonce: microJpegData.nonce,
          attachment_id: attachmentId,
          upscale: upscale
        },
        success: function(response) {
          if (response.success) {
            alert('Image enhanced successfully! Upscaled to ' + response.data.upscale + 'x');
            location.reload();
          } else {
            alert('Failed: ' + response.data.error);
          }
        },
        error: function() {
          alert('Failed to enhance image');
        },
        complete: function() {
          $button.prop('disabled', false).text(originalText);
        }
      });
    },

    handleUpgrade: function(e) {
      e.preventDefault();
      
      const tier = $(this).data('tier');
      window.open('https://microjpeg.com/pricing?upgrade=' + tier, '_blank');
    }
  };

  // Initialize on document ready
  $(document).ready(function() {
    MicroJPEG.init();
  });

})(jQuery);