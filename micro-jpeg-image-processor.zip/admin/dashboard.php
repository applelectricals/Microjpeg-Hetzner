<?php
/**
 * Dashboard Page Template
 *
 * @package MicroJPEG
 */

if (!defined('ABSPATH')) {
    exit;
}

// Get statistics (use global instances if available, or create new ones)
if (!class_exists('Micro_JPEG_Compressor')) {
    require_once MICRO_JPEG_PLUGIN_DIR . 'includes/class-micro-jpeg-compressor.php';
}
if (!class_exists('Micro_JPEG_API')) {
    require_once MICRO_JPEG_PLUGIN_DIR . 'includes/class-micro-jpeg-api.php';
}
if (!class_exists('Micro_JPEG_Settings')) {
    require_once MICRO_JPEG_PLUGIN_DIR . 'includes/class-micro-jpeg-settings.php';
}
if (!class_exists('Micro_JPEG_AI_Features')) {
    require_once MICRO_JPEG_PLUGIN_DIR . 'includes/class-micro-jpeg-ai-features.php';
}

$compressor = new Micro_JPEG_Compressor();
$api = new Micro_JPEG_API();
$settings_obj = new Micro_JPEG_Settings($api);
$ai_features = new Micro_JPEG_AI_Features($api, $settings_obj);

$compression_stats = $compressor->get_stats();
$ai_stats = $ai_features->get_statistics();
$usage = $settings_obj->get_current_usage();
$ai_usage = $ai_features->get_current_usage();

$settings = get_option('micro_jpeg_settings', array());
$subscription_tier = get_option('micro_jpeg_subscription_tier', 'free');
?>

<div class="wrap micro-jpeg-wrap">
    <h1><?php _e('Micro JPEG Dashboard', 'micro-jpeg'); ?></h1>
    
    <?php if (empty($settings['api_key'])): ?>
        <div class="notice notice-error">
            <p>
                <strong><?php _e('API Key Required', 'micro-jpeg'); ?></strong><br>
                <?php _e('Please configure your API key to start using Micro JPEG.', 'micro-jpeg'); ?>
                <a href="<?php echo admin_url('admin.php?page=micro-jpeg-settings'); ?>" class="button button-primary">
                    <?php _e('Configure Now', 'micro-jpeg'); ?>
                </a>
            </p>
        </div>
    <?php endif; ?>
    
    <!-- Subscription Info -->
    <div class="micro-jpeg-card" style="margin-bottom: 20px;">
        <h3><?php _e('Current Plan', 'micro-jpeg'); ?>: 
            <span style="color: #2271b1;"><?php echo ucfirst($subscription_tier); ?></span>
        </h3>
        <p>
            <a href="<?php echo admin_url('admin.php?page=micro-jpeg-subscription'); ?>" class="button">
                <?php _e('Manage Subscription', 'micro-jpeg'); ?>
            </a>
        </p>
    </div>
    
    <!-- Statistics Dashboard -->
    <div class="micro-jpeg-dashboard">
        <!-- Compression Stats -->
        <div class="micro-jpeg-card">
            <h3><?php _e('Image Compression', 'micro-jpeg'); ?></h3>
            
            <div class="micro-jpeg-stat">
                <span class="micro-jpeg-stat-label"><?php _e('Images Compressed', 'micro-jpeg'); ?></span>
                <span class="micro-jpeg-stat-value"><?php echo number_format($compression_stats['total_compressed']); ?></span>
            </div>
            
            <div class="micro-jpeg-stat">
                <span class="micro-jpeg-stat-label"><?php _e('Total Space Saved', 'micro-jpeg'); ?></span>
                <span class="micro-jpeg-stat-value"><?php echo size_format($compression_stats['total_savings'], 2); ?></span>
            </div>
            
            <div class="micro-jpeg-stat">
                <span class="micro-jpeg-stat-label"><?php _e('Average Savings', 'micro-jpeg'); ?></span>
                <span class="micro-jpeg-stat-value"><?php echo $compression_stats['avg_savings_percent']; ?>%</span>
            </div>
        </div>
        
        <!-- AI Features Stats -->
        <div class="micro-jpeg-card">
            <h3><?php _e('AI Features', 'micro-jpeg'); ?></h3>
            
            <div class="micro-jpeg-stat">
                <span class="micro-jpeg-stat-label"><?php _e('Backgrounds Removed', 'micro-jpeg'); ?></span>
                <span class="micro-jpeg-stat-value"><?php echo number_format($ai_stats['background_removed_total']); ?></span>
            </div>
            
            <div class="micro-jpeg-stat">
                <span class="micro-jpeg-stat-label"><?php _e('Images Enhanced', 'micro-jpeg'); ?></span>
                <span class="micro-jpeg-stat-value"><?php echo number_format($ai_stats['images_enhanced_total']); ?></span>
            </div>
            
            <div class="micro-jpeg-stat">
                <span class="micro-jpeg-stat-label"><?php _e('Max Upscale', 'micro-jpeg'); ?></span>
                <span class="micro-jpeg-stat-value"><?php echo $usage['max_upscale']; ?>x</span>
            </div>
        </div>
        
        <!-- Monthly Usage -->
        <div class="micro-jpeg-card">
            <h3><?php _e('Monthly Usage', 'micro-jpeg'); ?></h3>
            
            <div class="micro-jpeg-stat">
                <span class="micro-jpeg-stat-label"><?php _e('BG Removals', 'micro-jpeg'); ?></span>
                <span class="micro-jpeg-stat-value">
                    <?php echo $ai_usage['bg_removals']['used']; ?> / <?php echo $ai_usage['bg_removals']['limit']; ?>
                </span>
            </div>
            
            <?php if ($ai_usage['bg_removals']['percentage'] > 0): ?>
            <div class="micro-jpeg-progress">
                <div class="micro-jpeg-progress-bar <?php echo $ai_usage['bg_removals']['percentage'] > 80 ? 'danger' : ($ai_usage['bg_removals']['percentage'] > 50 ? 'warning' : ''); ?>" 
                     style="width: <?php echo min($ai_usage['bg_removals']['percentage'], 100); ?>%"></div>
            </div>
            <?php endif; ?>
            
            <div class="micro-jpeg-stat" style="margin-top: 15px;">
                <span class="micro-jpeg-stat-label"><?php _e('Enhancements', 'micro-jpeg'); ?></span>
                <span class="micro-jpeg-stat-value">
                    <?php echo $ai_usage['enhancements']['used']; ?> / <?php echo $ai_usage['enhancements']['limit']; ?>
                </span>
            </div>
            
            <?php if ($ai_usage['enhancements']['percentage'] > 0): ?>
            <div class="micro-jpeg-progress">
                <div class="micro-jpeg-progress-bar <?php echo $ai_usage['enhancements']['percentage'] > 80 ? 'danger' : ($ai_usage['enhancements']['percentage'] > 50 ? 'warning' : ''); ?>" 
                     style="width: <?php echo min($ai_usage['enhancements']['percentage'], 100); ?>%"></div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Quick Actions -->
    <div class="micro-jpeg-card" style="margin-top: 20px;">
        <h3><?php _e('Quick Actions', 'micro-jpeg'); ?></h3>
        <p>
            <a href="<?php echo admin_url('admin.php?page=micro-jpeg-bulk'); ?>" class="button button-primary">
                <?php _e('Bulk Compress Images', 'micro-jpeg'); ?>
            </a>
            <a href="<?php echo admin_url('upload.php'); ?>" class="button">
                <?php _e('View Media Library', 'micro-jpeg'); ?>
            </a>
            <a href="<?php echo admin_url('admin.php?page=micro-jpeg-settings'); ?>" class="button">
                <?php _e('Settings', 'micro-jpeg'); ?>
            </a>
        </p>
    </div>
    
    <!-- Upgrade Notice -->
    <?php if ($subscription_tier === 'free' && ($ai_usage['bg_removals']['percentage'] > 70 || $ai_usage['enhancements']['percentage'] > 70)): ?>
    <div class="notice notice-warning" style="margin-top: 20px;">
        <p>
            <strong><?php _e('Approaching Limit', 'micro-jpeg'); ?></strong><br>
            <?php _e("You're approaching your monthly limit. Upgrade for unlimited operations and more features.", 'micro-jpeg'); ?>
            <a href="<?php echo admin_url('admin.php?page=micro-jpeg-subscription'); ?>" class="button button-primary">
                <?php _e('Upgrade Now', 'micro-jpeg'); ?>
            </a>
        </p>
    </div>
    <?php endif; ?>
</div>