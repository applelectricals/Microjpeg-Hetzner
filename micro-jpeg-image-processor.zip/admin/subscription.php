<?php
/**
 * Subscription Page Template
 *
 * @package MicroJPEG
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Micro_JPEG_Settings')) {
    require_once MICRO_JPEG_PLUGIN_DIR . 'includes/class-micro-jpeg-settings.php';
}
if (!class_exists('Micro_JPEG_API')) {
    require_once MICRO_JPEG_PLUGIN_DIR . 'includes/class-micro-jpeg-api.php';
}
if (!class_exists('Micro_JPEG_AI_Features')) {
    require_once MICRO_JPEG_PLUGIN_DIR . 'includes/class-micro-jpeg-ai-features.php';
}

$api = new Micro_JPEG_API();
$settings_obj = new Micro_JPEG_Settings($api);
$current_tier = $settings_obj->get_subscription_tier();
$plans = $settings_obj->get_subscription_plans();
$usage = $settings_obj->get_current_usage();

$ai_features = new Micro_JPEG_AI_Features($api, $settings_obj);
$ai_usage = $ai_features->get_current_usage();
?>

<div class="wrap micro-jpeg-wrap">
    <h1><?php _e('Subscription & Pricing', 'micro-jpeg'); ?></h1>
    
    <!-- Current Usage -->
    <div class="micro-jpeg-card" style="margin-bottom: 30px;">
        <h2><?php _e('Current Usage', 'micro-jpeg'); ?></h2>
        
        <div class="micro-jpeg-limits">
            <div class="micro-jpeg-limit-item">
                <span class="micro-jpeg-limit-label"><?php _e('Plan', 'micro-jpeg'); ?></span>
                <span class="micro-jpeg-limit-value">
                    <strong><?php echo ucfirst($current_tier); ?></strong>
                </span>
            </div>
            
            <div class="micro-jpeg-limit-item">
                <span class="micro-jpeg-limit-label"><?php _e('Operations This Month', 'micro-jpeg'); ?></span>
                <span class="micro-jpeg-limit-value <?php echo $usage['percentage'] > 80 ? 'danger' : ($usage['percentage'] > 50 ? 'warning' : ''); ?>">
                    <?php echo $usage['operations']; ?> / <?php echo $usage['limit']; ?>
                </span>
            </div>
            
            <div class="micro-jpeg-limit-item">
                <span class="micro-jpeg-limit-label"><?php _e('Background Removals', 'micro-jpeg'); ?></span>
                <span class="micro-jpeg-limit-value <?php echo $ai_usage['bg_removals']['percentage'] > 80 ? 'danger' : ''; ?>">
                    <?php echo $ai_usage['bg_removals']['used']; ?> / <?php echo $ai_usage['bg_removals']['limit']; ?>
                </span>
            </div>
            
            <div class="micro-jpeg-limit-item">
                <span class="micro-jpeg-limit-label"><?php _e('Image Enhancements', 'micro-jpeg'); ?></span>
                <span class="micro-jpeg-limit-value <?php echo $ai_usage['enhancements']['percentage'] > 80 ? 'danger' : ''; ?>">
                    <?php echo $ai_usage['enhancements']['used']; ?> / <?php echo $ai_usage['enhancements']['limit']; ?>
                </span>
            </div>
            
            <div class="micro-jpeg-limit-item">
                <span class="micro-jpeg-limit-label"><?php _e('Max Upscale Level', 'micro-jpeg'); ?></span>
                <span class="micro-jpeg-limit-value">
                    <?php echo $ai_usage['max_upscale']; ?>x
                </span>
            </div>
            
            <div class="micro-jpeg-limit-item">
                <span class="micro-jpeg-limit-label"><?php _e('Available BG Formats', 'micro-jpeg'); ?></span>
                <span class="micro-jpeg-limit-value">
                    <?php echo implode(', ', $ai_usage['formats']); ?>
                </span>
            </div>
        </div>
    </div>
    
    <!-- Pricing Plans -->
    <h2><?php _e('Available Plans', 'micro-jpeg'); ?></h2>
    
    <div class="micro-jpeg-plans">
        <?php foreach ($plans as $tier_key => $plan): ?>
        <div class="micro-jpeg-plan <?php echo $tier_key === $current_tier ? 'active' : ''; ?> <?php echo !empty($plan['popular']) ? 'popular' : ''; ?>">
            <div class="micro-jpeg-plan-name"><?php echo esc_html($plan['name']); ?></div>
            
            <div class="micro-jpeg-plan-price">
                $<?php echo $plan['price']; ?>
                <span>/<?php _e('month', 'micro-jpeg'); ?></span>
            </div>
            
            <ul class="micro-jpeg-plan-features">
                <?php foreach ($plan['features'] as $feature): ?>
                <li><?php echo esc_html($feature); ?></li>
                <?php endforeach; ?>
            </ul>
            
            <?php if ($tier_key === $current_tier): ?>
                <button class="micro-jpeg-plan-button secondary" disabled>
                    <?php _e('Current Plan', 'micro-jpeg'); ?>
                </button>
            <?php elseif ($plan['price'] === 0): ?>
                <button class="micro-jpeg-plan-button secondary" disabled>
                    <?php _e('Free Plan', 'micro-jpeg'); ?>
                </button>
            <?php else: ?>
                <a href="https://microjpeg.com/pricing?upgrade=<?php echo $tier_key; ?>" 
                   target="_blank" 
                   class="micro-jpeg-plan-button primary">
                    <?php echo $plan['price'] > $plans[$current_tier]['price'] ? __('Upgrade', 'micro-jpeg') : __('Switch Plan', 'micro-jpeg'); ?>
                </a>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
    
    <!-- Feature Comparison -->
    <div class="micro-jpeg-card" style="margin-top: 40px;">
        <h2><?php _e('Feature Comparison', 'micro-jpeg'); ?></h2>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php _e('Feature', 'micro-jpeg'); ?></th>
                    <th><?php _e('Free', 'micro-jpeg'); ?></th>
                    <th><?php _e('Starter', 'micro-jpeg'); ?></th>
                    <th><?php _e('Pro', 'micro-jpeg'); ?></th>
                    <th><?php _e('Business', 'micro-jpeg'); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong><?php _e('Regular Images', 'micro-jpeg'); ?></strong></td>
                    <td>7MB</td>
                    <td>75MB</td>
                    <td>150MB</td>
                    <td>200MB</td>
                </tr>
                <tr>
                    <td><strong><?php _e('RAW Files', 'micro-jpeg'); ?></strong></td>
                    <td>15MB</td>
                    <td>75MB</td>
                    <td>150MB</td>
                    <td>200MB</td>
                </tr>
                <tr>
                    <td><strong><?php _e('Monthly Operations', 'micro-jpeg'); ?></strong></td>
                    <td>200</td>
                    <td>Unlimited</td>
                    <td>Unlimited</td>
                    <td>Unlimited</td>
                </tr>
                <tr>
                    <td><strong><?php _e('BG Removals/Month', 'micro-jpeg'); ?></strong></td>
                    <td>5</td>
                    <td>200</td>
                    <td>500</td>
                    <td>1,000</td>
                </tr>
                <tr>
                    <td><strong><?php _e('Enhancements/Month', 'micro-jpeg'); ?></strong></td>
                    <td>3</td>
                    <td>200</td>
                    <td>200</td>
                    <td>1,000</td>
                </tr>
                <tr>
                    <td><strong><?php _e('Max Upscale', 'micro-jpeg'); ?></strong></td>
                    <td>2x</td>
                    <td>8x</td>
                    <td>8x</td>
                    <td>8x</td>
                </tr>
                <tr>
                    <td><strong><?php _e('BG Output Formats', 'micro-jpeg'); ?></strong></td>
                    <td>PNG only</td>
                    <td>All formats</td>
                    <td>All formats</td>
                    <td>All formats</td>
                </tr>
                <tr>
                    <td><strong><?php _e('Support', 'micro-jpeg'); ?></strong></td>
                    <td>Email</td>
                    <td>Priority Email</td>
                    <td>Priority Email</td>
                    <td>Dedicated</td>
                </tr>
            </tbody>
        </table>
    </div>
    
    <!-- Manage Subscription -->
    <div class="micro-jpeg-card" style="margin-top: 30px;">
        <h2><?php _e('Manage Subscription', 'micro-jpeg'); ?></h2>
        <p>
            <?php _e('To manage your subscription, billing, or payment methods, please visit your account dashboard.', 'micro-jpeg'); ?>
        </p>
        <p>
            <a href="https://microjpeg.com/account" target="_blank" class="button button-primary">
                <?php _e('Manage Subscription', 'micro-jpeg'); ?>
            </a>
            <a href="https://microjpeg.com/support" target="_blank" class="button">
                <?php _e('Contact Support', 'micro-jpeg'); ?>
            </a>
        </p>
    </div>
</div>