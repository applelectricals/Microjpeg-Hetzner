<?php
/**
 * Bulk Compress Page Template
 *
 * @package MicroJPEG
 */

if (!defined('ABSPATH')) {
    exit;
}

$bulk_processor = new Micro_JPEG_Bulk_Processor();
$uncompressed = $bulk_processor->get_uncompressed_images(100);
$compressed = $bulk_processor->get_compressed_images(20);
?>

<div class="wrap micro-jpeg-wrap">
    <h1><?php _e('Bulk Image Compression', 'micro-jpeg'); ?></h1>
    
    <!-- Uncompressed Images -->
    <div class="micro-jpeg-card">
        <h2><?php _e('Uncompressed Images', 'micro-jpeg'); ?> (<?php echo count($uncompressed); ?>)</h2>
        
        <?php if (empty($uncompressed)): ?>
            <p><?php _e('All images have been compressed!', 'micro-jpeg'); ?> 🎉</p>
        <?php else: ?>
            <div style="margin-bottom: 15px;">
                <button type="button" id="select-all-images" class="button">
                    <?php _e('Select All', 'micro-jpeg'); ?>
                </button>
                <button type="button" id="deselect-all-images" class="button">
                    <?php _e('Deselect All', 'micro-jpeg'); ?>
                </button>
                <button type="button" id="micro-jpeg-bulk-compress-btn" class="button button-primary">
                    <?php _e('Compress Selected', 'micro-jpeg'); ?>
                </button>
            </div>
            
            <div class="micro-jpeg-image-list">
                <?php foreach ($uncompressed as $image): ?>
                <div class="micro-jpeg-image-item" data-id="<?php echo $image['id']; ?>">
                    <input type="checkbox" 
                           class="micro-jpeg-image-checkbox" 
                           value="<?php echo $image['id']; ?>" 
                           id="img-<?php echo $image['id']; ?>">
                    
                    <img src="<?php echo esc_url($image['url']); ?>" 
                         alt="<?php echo esc_attr($image['title']); ?>" 
                         class="micro-jpeg-image-thumb">
                    
                    <div class="micro-jpeg-image-info">
                        <div class="micro-jpeg-image-name">
                            <?php echo esc_html($image['title']); ?>
                        </div>
                        <div class="micro-jpeg-image-size">
                            <?php echo $image['size_formatted']; ?>
                        </div>
                    </div>
                    
                    <span class="micro-jpeg-image-status pending">
                        <?php _e('Pending', 'micro-jpeg'); ?>
                    </span>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Recently Compressed -->
    <?php if (!empty($compressed)): ?>
    <div class="micro-jpeg-card" style="margin-top: 30px;">
        <h2><?php _e('Recently Compressed Images', 'micro-jpeg'); ?></h2>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php _e('Image', 'micro-jpeg'); ?></th>
                    <th><?php _e('Original Size', 'micro-jpeg'); ?></th>
                    <th><?php _e('Compressed Size', 'micro-jpeg'); ?></th>
                    <th><?php _e('Savings', 'micro-jpeg'); ?></th>
                    <th><?php _e('Actions', 'micro-jpeg'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($compressed as $image): ?>
                <tr>
                    <td>
                        <img src="<?php echo esc_url($image['url']); ?>" 
                             alt="<?php echo esc_attr($image['title']); ?>" 
                             style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px; margin-right: 10px;">
                        <?php echo esc_html($image['title']); ?>
                    </td>
                    <td><?php echo size_format($image['original_size'], 2); ?></td>
                    <td><?php echo size_format($image['compressed_size'], 2); ?></td>
                    <td>
                        <strong style="color: #00a32a;">
                            <?php echo $image['savings_percent']; ?>%
                        </strong>
                    </td>
                    <td>
                        <a href="#" 
                           class="button button-small micro-jpeg-restore" 
                           data-id="<?php echo $image['id']; ?>">
                            <?php _e('Restore', 'micro-jpeg'); ?>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<script>
jQuery(document).ready(function($) {
    // Select/Deselect All
    $('#select-all-images').on('click', function() {
        $('.micro-jpeg-image-checkbox').prop('checked', true);
    });
    
    $('#deselect-all-images').on('click', function() {
        $('.micro-jpeg-image-checkbox').prop('checked', false);
    });
    
    // Bulk Compress
    $('#micro-jpeg-bulk-compress-btn').on('click', function() {
        var selectedImages = $('.micro-jpeg-image-checkbox:checked').map(function() {
            return $(this).val();
        }).get();
        
        if (selectedImages.length === 0) {
            alert('<?php _e('Please select at least one image', 'micro-jpeg'); ?>');
            return;
        }
        
        if (!confirm('<?php _e('Compress', 'micro-jpeg'); ?> ' + selectedImages.length + ' <?php _e('image(s)?', 'micro-jpeg'); ?>')) {
            return;
        }
        
        processBulkCompress(selectedImages);
    });
    
    function processBulkCompress(imageIds) {
        var total = imageIds.length;
        var completed = 0;
        var failed = 0;
        
        function processNext() {
            if (imageIds.length === 0) {
                alert('<?php _e('Bulk compression complete!', 'micro-jpeg'); ?>\n<?php _e('Success:', 'micro-jpeg'); ?> ' + completed + '\n<?php _e('Failed:', 'micro-jpeg'); ?> ' + failed);
                location.reload();
                return;
            }
            
            var imageId = imageIds.shift();
            var $item = $('.micro-jpeg-image-item[data-id="' + imageId + '"]');
            
            $item.find('.micro-jpeg-image-status')
                .removeClass('pending')
                .addClass('processing')
                .text('<?php _e('Processing...', 'micro-jpeg'); ?>');
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'micro_jpeg_compress_image',
                    nonce: '<?php echo wp_create_nonce('micro_jpeg_nonce'); ?>',
                    attachment_id: imageId
                },
                success: function(response) {
                    if (response.success) {
                        completed++;
                        $item.find('.micro-jpeg-image-status')
                            .removeClass('processing')
                            .addClass('success')
                            .text('<?php _e('Compressed', 'micro-jpeg'); ?>');
                    } else {
                        failed++;
                        $item.find('.micro-jpeg-image-status')
                            .removeClass('processing')
                            .addClass('error')
                            .text('<?php _e('Failed', 'micro-jpeg'); ?>');
                    }
                },
                error: function() {
                    failed++;
                    $item.find('.micro-jpeg-image-status')
                        .removeClass('processing')
                        .addClass('error')
                        .text('<?php _e('Error', 'micro-jpeg'); ?>');
                },
                complete: function() {
                    processNext();
                }
            });
        }
        
        processNext();
    }
});
</script>