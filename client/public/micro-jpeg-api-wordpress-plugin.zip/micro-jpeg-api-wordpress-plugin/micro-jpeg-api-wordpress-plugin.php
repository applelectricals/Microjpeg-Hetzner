<?php
/**
 * Plugin Name: Micro JPEG API Compressor
 * Plugin URI: https://microjpeg.com
 * Description: WordPress plugin for advanced image compression supporting JPEG, PNG, WebP, AVIF, SVG, TIFF, and RAW files. NOTE: You must have a valid MicroJPEG API key from microjpeg.com/api-dashboard
 * Version: 2.1.0
 * Author: Micro JPEG Team
 * License: GPL v2 or later
 * Text Domain: micro-jpeg-api-compressor
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('MICRO_JPEG_API_VERSION', '2.1.0');
define('MICRO_JPEG_API_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MICRO_JPEG_API_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('MICRO_JPEG_API_ENDPOINT', 'https://microjpeg.com/api/v1/compress');

class MicroJpegApiCompressor {
    
    private static $instance = null;
    private $api_key = null;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Set PHP limits for large files
        @ini_set('upload_max_filesize', '150M');
        @ini_set('post_max_size', '150M');
        @ini_set('memory_limit', '512M');
        @ini_set('max_execution_time', '300');
        
        add_action('init', array($this, 'init'));
        add_action('admin_init', array($this, 'admin_init'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // AJAX handlers
        add_action('wp_ajax_micro_jpeg_api_test_key', array($this, 'test_api_key'));
        add_action('wp_ajax_micro_jpeg_api_compress_single', array($this, 'compress_single_image'));
        
        // WordPress media hooks - CRITICAL for auto-compress
        add_filter('wp_handle_upload', array($this, 'auto_compress_upload'), 999, 2);
        
        // Increase upload limits
        add_filter('upload_size_limit', array($this, 'increase_upload_limit'));
        add_filter('wp_check_filetype_and_ext', array($this, 'allow_raw_uploads'), 10, 4);
        
        // Media library column
        add_filter('manage_media_columns', array($this, 'add_media_column'));
        add_action('manage_media_custom_column', array($this, 'display_media_column'), 10, 2);
        
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    public function init() {
        $this->api_key = get_option('micro_jpeg_api_key', '');
        load_plugin_textdomain('micro-jpeg-api-compressor', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        // Debug: Log plugin initialization
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('MicroJPEG Plugin Initialized - API Key: ' . (empty($this->api_key) ? 'NOT SET' : 'SET'));
        }
    }
    
    public function increase_upload_limit($size) {
        return 150 * 1024 * 1024; // 150MB
    }
    
    public function allow_raw_uploads($data, $file, $filename, $mimes) {
        // Allow RAW file uploads
        $raw_extensions = array('cr2', 'arw', 'dng', 'nef', 'orf', 'raf', 'rw2');
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        
        if (in_array(strtolower($ext), $raw_extensions)) {
            $data['ext'] = $ext;
            $data['type'] = 'image/' . $ext;
            $data['proper_filename'] = $filename;
        }
        
        return $data;
    }
    
    public function admin_init() {
        register_setting('micro_jpeg_api_settings', 'micro_jpeg_api_key', array(
            'sanitize_callback' => 'sanitize_text_field'
        ));
        
        register_setting('micro_jpeg_api_settings', 'micro_jpeg_auto_compress', array(
            'type' => 'boolean',
            'sanitize_callback' => array($this, 'sanitize_checkbox'),
            'default' => 0
        ));
        
        register_setting('micro_jpeg_api_settings', 'micro_jpeg_default_quality', array(
            'type' => 'integer',
            'sanitize_callback' => 'absint',
            'default' => 75
        ));
        
        register_setting('micro_jpeg_api_settings', 'micro_jpeg_backup_originals', array(
            'type' => 'boolean',
            'sanitize_callback' => array($this, 'sanitize_checkbox'),
            'default' => 1
        ));
    }
    
    public function sanitize_checkbox($value) {
        return ($value === '1' || $value === 1 || $value === true) ? 1 : 0;
    }
    
    public function add_admin_menu() {
        add_media_page(
            'Micro JPEG API Settings',
            'Micro JPEG API',
            'manage_options',
            'micro-jpeg-api-settings',
            array($this, 'admin_page')
        );
    }
    
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'micro-jpeg') !== false || $hook === 'upload.php') {
            wp_enqueue_script('micro-jpeg-admin-js', MICRO_JPEG_API_PLUGIN_URL . 'assets/admin.js', array('jquery'), MICRO_JPEG_API_VERSION, true);
            wp_enqueue_style('micro-jpeg-admin-css', MICRO_JPEG_API_PLUGIN_URL . 'assets/admin.css', array(), MICRO_JPEG_API_VERSION);
            
            wp_localize_script('micro-jpeg-admin-js', 'microJpegAdmin', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('micro_jpeg_api_nonce')
            ));
        }
    }
    
    /**
     * CRITICAL: Auto-compress on upload
     * This is the main function that compresses images when they're uploaded
     */
    public function auto_compress_upload($upload, $context) {
        // Comprehensive logging
        error_log('=== MicroJPEG AUTO-COMPRESS TRIGGERED ===');
        error_log('File: ' . ($upload['file'] ?? 'unknown'));
        error_log('Type: ' . ($upload['type'] ?? 'unknown'));
        error_log('Context: ' . $context);
        
        // Check 1: API Key
        if (empty($this->api_key)) {
            error_log('MicroJPEG: SKIPPED - No API key configured');
            return $upload;
        }
        error_log('MicroJPEG: API Key is set');
        
        // Check 2: Auto-compress setting
        $auto_compress = get_option('micro_jpeg_auto_compress', 0);
        error_log('MicroJPEG: Auto-compress setting value: ' . var_export($auto_compress, true));
        
        if ($auto_compress != 1 && $auto_compress !== '1' && $auto_compress !== true) {
            error_log('MicroJPEG: SKIPPED - Auto-compress is disabled');
            return $upload;
        }
        error_log('MicroJPEG: Auto-compress is ENABLED');
        
        // Check 3: Is it an image?
        if (!isset($upload['type']) || strpos($upload['type'], 'image/') !== 0) {
            error_log('MicroJPEG: SKIPPED - Not an image file (type: ' . ($upload['type'] ?? 'none') . ')');
            return $upload;
        }
        error_log('MicroJPEG: File is an image');
        
        // Check 4: File exists?
        if (!isset($upload['file']) || !file_exists($upload['file'])) {
            error_log('MicroJPEG: SKIPPED - File does not exist');
            return $upload;
        }
        error_log('MicroJPEG: File exists at: ' . $upload['file']);
        
        // All checks passed - proceed with compression
        error_log('MicroJPEG: *** ALL CHECKS PASSED - STARTING COMPRESSION ***');
        
        try {
            $original_size = filesize($upload['file']);
            error_log('MicroJPEG: Original file size: ' . $this->format_bytes($original_size));
            
            $result = $this->compress_file($upload['file'], array(
                'quality' => get_option('micro_jpeg_default_quality', 75),
                'format' => 'keep'
            ));
            
            if ($result['success']) {
                error_log('MicroJPEG: Compression successful!');
                error_log('MicroJPEG: New size: ' . $this->format_bytes($result['compressed_size']));
                error_log('MicroJPEG: Saved: ' . $result['savings'] . '%');
                
                // Update upload array
                $upload['size'] = $result['compressed_size'];
                
                // Store compression metadata
                add_filter('wp_update_attachment_metadata', function($metadata, $attachment_id) use ($result) {
                    update_post_meta($attachment_id, '_micro_jpeg_compressed', array(
                        'original_size' => $result['original_size'],
                        'compressed_size' => $result['compressed_size'],
                        'savings' => $result['savings'],
                        'date' => current_time('mysql')
                    ));
                    return $metadata;
                }, 10, 2);
                
            } else {
                error_log('MicroJPEG: Compression FAILED - ' . $result['error']);
            }
            
        } catch (Exception $e) {
            error_log('MicroJPEG: Exception during compression - ' . $e->getMessage());
        }
        
        return $upload;
    }
    
    /**
     * Core compression function
     * This handles the actual API call and file replacement
     */
    private function compress_file($file_path, $settings = array()) {
        try {
            $original_size = filesize($file_path);
            
            // Backup original if enabled
            if (get_option('micro_jpeg_backup_originals', 1)) {
                $backup_path = $file_path . '.original';
                if (!copy($file_path, $backup_path)) {
                    error_log('MicroJPEG: WARNING - Failed to create backup');
                }
            }
            
            // Call API
            $compressed_data = $this->call_compression_api($file_path, $settings);
            
            if ($compressed_data === false) {
                throw new Exception('API call failed');
            }
            
            // Save compressed version
            if (file_put_contents($file_path, $compressed_data) === false) {
                throw new Exception('Failed to write compressed file');
            }
            
            clearstatcache(true, $file_path);
            $compressed_size = filesize($file_path);
            
            // Only keep if smaller
            if ($compressed_size >= $original_size) {
                error_log('MicroJPEG: Compressed file is larger, restoring original');
                if (file_exists($file_path . '.original')) {
                    copy($file_path . '.original', $file_path);
                    unlink($file_path . '.original');
                }
                return array(
                    'success' => false,
                    'error' => 'Compressed file was not smaller'
                );
            }
            
            $savings = round((1 - $compressed_size / $original_size) * 100, 2);
            
            return array(
                'success' => true,
                'original_size' => $original_size,
                'compressed_size' => $compressed_size,
                'savings' => $savings
            );
            
        } catch (Exception $e) {
            // Restore backup if it exists
            if (file_exists($file_path . '.original')) {
                copy($file_path . '.original', $file_path);
                unlink($file_path . '.original');
            }
            
            return array(
                'success' => false,
                'error' => $e->getMessage()
            );
        }
    }
    
    /**
     * Make API call to compress image
     * This is where the actual API communication happens
     */
    private function call_compression_api($file_path, $settings) {
        $boundary = wp_generate_password(24, false);
        $body = '';
        
        // Add settings
        $body .= '--' . $boundary . "\r\n";
        $body .= 'Content-Disposition: form-data; name="quality"' . "\r\n\r\n";
        $body .= ($settings['quality'] ?? 75) . "\r\n";
        
        // Add file
        $body .= '--' . $boundary . "\r\n";
        $body .= 'Content-Disposition: form-data; name="image"; filename="' . basename($file_path) . '"' . "\r\n";
        $body .= 'Content-Type: ' . $this->get_mime_type($file_path) . "\r\n\r\n";
        $body .= file_get_contents($file_path) . "\r\n";
        $body .= '--' . $boundary . '--' . "\r\n";
        
        $response = wp_remote_post(MICRO_JPEG_API_ENDPOINT, array(
            'timeout' => 120,
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'multipart/form-data; boundary=' . $boundary
            ),
            'body' => $body
        ));
        
        if (is_wp_error($response)) {
            error_log('MicroJPEG API Error: ' . $response->get_error_message());
            return false;
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        error_log('MicroJPEG API Response Code: ' . $code);
        
        if ($code !== 200) {
            error_log('MicroJPEG API Error Response: ' . substr($body, 0, 500));
            return false;
        }
        
        // Try to decode JSON response
        $data = json_decode($body, true);
        
        if ($data && isset($data['success']) && $data['success'] && isset($data['data'])) {
            // Base64 encoded image
            return base64_decode($data['data']);
        } else if ($data && isset($data['url'])) {
            // URL to download
            $download = wp_remote_get($data['url']);
            if (!is_wp_error($download)) {
                return wp_remote_retrieve_body($download);
            }
        } else {
            // Assume raw binary response
            return $body;
        }
        
        return false;
    }
    
    private function get_mime_type($file_path) {
        $ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        $types = array(
            'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg',
            'png' => 'image/png', 'webp' => 'image/webp',
            'avif' => 'image/avif', 'svg' => 'image/svg+xml',
            'tiff' => 'image/tiff', 'tif' => 'image/tiff',
            'cr2' => 'image/x-canon-cr2', 'arw' => 'image/x-sony-arw',
            'dng' => 'image/x-adobe-dng', 'nef' => 'image/x-nikon-nef',
            'orf' => 'image/x-olympus-orf', 'raf' => 'image/x-fuji-raf',
            'rw2' => 'image/x-panasonic-rw2'
        );
        return $types[$ext] ?? 'application/octet-stream';
    }
    
    private function format_bytes($bytes) {
        $units = array('B', 'KB', 'MB', 'GB');
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        return round($bytes / pow(1024, $pow), 2) . ' ' . $units[$pow];
    }
    
    /**
     * Media library column
     */
    public function add_media_column($columns) {
        $columns['micro_jpeg'] = 'Compression';
        return $columns;
    }
    
    public function display_media_column($column_name, $attachment_id) {
        if ($column_name === 'micro_jpeg') {
            $data = get_post_meta($attachment_id, '_micro_jpeg_compressed', true);
            
            if ($data && isset($data['savings'])) {
                echo '<span style="color: green;">✓ Saved ' . esc_html($data['savings']) . '%</span>';
            } else {
                echo '<span style="color: #999;">Not compressed</span>';
            }
        }
    }
    
    /**
     * AJAX: Test API key
     */
    public function test_api_key() {
        check_ajax_referer('micro_jpeg_api_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permission denied');
        }
        
        $api_key = sanitize_text_field($_POST['api_key'] ?? '');
        
        if (empty($api_key)) {
            wp_send_json_error('API key is required');
        }
        
        // Test API with a simple status check
        $response = wp_remote_get('https://microjpeg.com/api/v1/status', array(
            'timeout' => 30,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key
            )
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error('Connection failed: ' . $response->get_error_message());
        }
        
        $code = wp_remote_retrieve_response_code($response);
        
        if ($code === 200) {
            wp_send_json_success('API key is valid and working!');
        } else if ($code === 401 || $code === 403) {
            wp_send_json_error('Invalid API key - Access denied');
        } else {
            wp_send_json_error('API returned error code: ' . $code);
        }
    }
    
    /**
     * AJAX: Compress single image from media library
     */
    public function compress_single_image() {
        check_ajax_referer('micro_jpeg_api_nonce', 'nonce');
        
        if (!current_user_can('upload_files')) {
            wp_send_json_error('Permission denied');
        }
        
        $attachment_id = intval($_POST['attachment_id'] ?? 0);
        
        if (!$attachment_id) {
            wp_send_json_error('Invalid attachment ID');
        }
        
        $file_path = get_attached_file($attachment_id);
        
        if (!$file_path || !file_exists($file_path)) {
            wp_send_json_error('File not found');
        }
        
        $result = $this->compress_file($file_path, array(
            'quality' => get_option('micro_jpeg_default_quality', 75)
        ));
        
        if ($result['success']) {
            update_post_meta($attachment_id, '_micro_jpeg_compressed', array(
                'original_size' => $result['original_size'],
                'compressed_size' => $result['compressed_size'],
                'savings' => $result['savings'],
                'date' => current_time('mysql')
            ));
            
            wp_send_json_success(array(
                'message' => 'Compressed successfully! Saved ' . $result['savings'] . '%',
                'savings' => $result['savings']
            ));
        } else {
            wp_send_json_error($result['error']);
        }
    }
    
    /**
     * Admin settings page
     */
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>Micro JPEG API Settings</h1>
            
            <div class="notice notice-info">
                <p><strong>Important:</strong> This plugin requires a valid MicroJPEG API key. Get your free API key at <a href="https://microjpeg.com/api-dashboard" target="_blank">microjpeg.com/api-dashboard</a></p>
            </div>
            
            <form method="post" action="options.php">
                <?php settings_fields('micro_jpeg_api_settings'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">API Key</th>
                        <td>
                            <input type="password" name="micro_jpeg_api_key" value="<?php echo esc_attr(get_option('micro_jpeg_api_key')); ?>" class="regular-text" id="api-key-input" />
                            <button type="button" id="test-api-key" class="button">Test API Key</button>
                            <p class="description">
                                <a href="https://microjpeg.com/api-dashboard" target="_blank" class="button button-secondary">Get Free API Key (200/month)</a>
                            </p>
                            <div id="api-test-result" style="margin-top: 10px;"></div>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Auto-compress Uploads</th>
                        <td>
                            <label>
                                <input type="checkbox" name="micro_jpeg_auto_compress" value="1" <?php checked(get_option('micro_jpeg_auto_compress', 0), 1); ?> />
                                Automatically compress images when uploaded to media library
                            </label>
                            <p class="description">
                                <strong>Current status:</strong> <?php echo get_option('micro_jpeg_auto_compress', 0) == 1 ? '<span style="color: green;">ENABLED</span>' : '<span style="color: red;">DISABLED</span>'; ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Default Quality</th>
                        <td>
                            <input type="range" name="micro_jpeg_default_quality" min="10" max="100" value="<?php echo esc_attr(get_option('micro_jpeg_default_quality', 75)); ?>" id="quality-slider" />
                            <span id="quality-value"><?php echo get_option('micro_jpeg_default_quality', 75); ?>%</span>
                            <p class="description">Higher quality = larger file size, lower quality = smaller file size</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Backup Originals</th>
                        <td>
                            <label>
                                <input type="checkbox" name="micro_jpeg_backup_originals" value="1" <?php checked(get_option('micro_jpeg_backup_originals', 1), 1); ?> />
                                Keep backup copies of original images (.original files)
                            </label>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(); ?>
            </form>
            
            <hr>
            
            <h2>Debug Information</h2>
            <table class="widefat">
                <tr>
                    <td><strong>API Key Status:</strong></td>
                    <td><?php echo empty(get_option('micro_jpeg_api_key')) ? '<span style="color: red;">NOT SET</span>' : '<span style="color: green;">SET</span>'; ?></td>
                </tr>
                <tr>
                    <td><strong>Auto-compress:</strong></td>
                    <td><?php echo get_option('micro_jpeg_auto_compress', 0) == 1 ? '<span style="color: green;">ENABLED</span>' : '<span style="color: red;">DISABLED</span>'; ?></td>
                </tr>
                <tr>
                    <td><strong>PHP Memory Limit:</strong></td>
                    <td><?php echo ini_get('memory_limit'); ?></td>
                </tr>
                <tr>
                    <td><strong>Max Upload Size:</strong></td>
                    <td><?php echo size_format(wp_max_upload_size()); ?></td>
                </tr>
                <tr>
                    <td><strong>WP Debug:</strong></td>
                    <td><?php echo defined('WP_DEBUG') && WP_DEBUG ? '<span style="color: green;">ENABLED</span>' : '<span style="color: #999;">DISABLED</span>'; ?></td>
                </tr>
            </table>
            
            <p class="description">Check your wp-content/debug.log file for compression activity logs.</p>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Quality slider
            $('#quality-slider').on('input', function() {
                $('#quality-value').text($(this).val() + '%');
            });
            
            // Test API key
            $('#test-api-key').on('click', function() {
                var $btn = $(this);
                var $result = $('#api-test-result');
                var apiKey = $('#api-key-input').val();
                
                if (!apiKey) {
                    $result.html('<div class="notice notice-warning inline"><p>Please enter an API key first.</p></div>');
                    return;
                }
                
                $btn.prop('disabled', true).text('Testing...');
                $result.html('');
                
                $.post(ajaxurl, {
                    action: 'micro_jpeg_api_test_key',
                    api_key: apiKey,
                    nonce: '<?php echo wp_create_nonce('micro_jpeg_api_nonce'); ?>'
                }).done(function(response) {
                    if (response.success) {
                        $result.html('<div class="notice notice-success inline"><p><strong>Success!</strong> ' + response.data + '</p></div>');
                    } else {
                        $result.html('<div class="notice notice-error inline"><p><strong>Error:</strong> ' + response.data + '</p></div>');
                    }
                }).fail(function() {
                    $result.html('<div class="notice notice-error inline"><p>Connection failed. Please check your internet connection.</p></div>');
                }).always(function() {
                    $btn.prop('disabled', false).text('Test API Key');
                });
            });
        });
        </script>
        
        <style>
        .notice.inline {
            display: inline-block;
            margin: 0;
            padding: 5px 10px;
        }
        #api-test-result .notice {
            margin: 0;
        }
        </style>
        <?php
    }
    
    public function activate() {
        add_option('micro_jpeg_auto_compress', 0);
        add_option('micro_jpeg_default_quality', 75);
        add_option('micro_jpeg_backup_originals', 1);
    }
    
    public function deactivate() {
        // Cleanup temporary files
        $upload_dir = wp_upload_dir();
        $files = glob($upload_dir['basedir'] . '/**/*.original');
        foreach ($files as $file) {
            if (is_file($file)) {
                @unlink($file);
            }
        }
    }
}

// Initialize plugin
MicroJpegApiCompressor::getInstance();

// Create assets directory with placeholder files if they don't exist
register_activation_hook(__FILE__, function() {
    $assets_dir = plugin_dir_path(__FILE__) . 'assets';
    if (!file_exists($assets_dir)) {
        wp_mkdir_p($assets_dir);
        
        // Create placeholder JS file
        file_put_contents($assets_dir . '/admin.js', '// MicroJPEG Admin JS');
        
        // Create placeholder CSS file
        file_put_contents($assets_dir . '/admin.css', '/* MicroJPEG Admin CSS */');
    }
});